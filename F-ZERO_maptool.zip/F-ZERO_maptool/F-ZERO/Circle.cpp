#include "Circle.h"
#include "DxLib.h"
#include "KeyMng.h"
#include "MouseMng.h"
#include <cmath>

#define PI 3.14159265

int Circle::_selectCnt = 0;

Circle::Circle()
{
}

Circle::Circle(VECTOR2 p): _pos(p)
{
	SetHitCheck();
}

Circle::Circle(VECTOR2 p, VECTOR2 startPos, VECTOR2 endPos): _pos(p), _startPos(startPos), _endPos(endPos)
{
	SetHitCheck();
}

void Circle::SetHitCheck()
{
	_hitCheck.left = _pos.x - _size * 2;
	_hitCheck.right = _pos.x + _size * 2;
	_hitCheck.top = _pos.y - _size * 2;
	_hitCheck.bottom = _pos.y + _size * 2;
}

void Circle::SetHitCheck(VECTOR2 pos)
{
	_hitCheck.left = pos.x - _size * 2;
	_hitCheck.right = pos.x + _size * 2;
	_hitCheck.top = pos.y - _size * 2;
	_hitCheck.bottom = pos.y + _size * 2;
}

void Circle::SetCheckFlag(bool flag)
{
	_checkFlag = flag;
}

const bool& Circle::GetCheckFlag()
{
	return _checkFlag;
}

void Circle::SetNextCenter(VECTOR2 pos)
{
	_nextCenter = pos;
}

const std::vector<VECTOR2>& Circle::GetVectors()
{
	return _vec;
}

const std::vector<VECTOR2>& Circle::GetVectorsEnd()
{
	return _vecEnd;
}

const int& Circle::GetSelectCnt()
{
	return _selectCnt;
}

void Circle::SelectAddCnt(int cnt)
{
	_selectCnt += cnt;
}

void Circle::SelectSetCnt(int cnt)
{
	_selectCnt = cnt;
}

void Circle::SetCourceSize(int size)
{
	_couseSize += size;
}

const bool& Circle::GetEndFlag()
{
	return _endFlag;
}

void Circle::SetEndFlag(bool flag)
{
	_endFlag = flag;
}

VECTOR2 Circle::lerp(VECTOR2 lerp, VECTOR2 start, VECTOR2 end, float t)
{
	VECTOR2 s, e;
	s = start.Normalize();
	e = end.Normalize();

	auto cos = s.VectorDot(s, e);
	float angle = acos(cos);

	float sinT = sin(angle);

	float t0 = sin(angle * (1 - t));
	float t1 = sin(angle * t);

	lerp = (t0 * s + t1 * e) / sinT;

	lerp.Normalize();

	return lerp;
}

Circle::~Circle()
{
}

const VECTOR2& Circle::GetPos()
{
	return _pos;
}

const VECTOR2& Circle::GetCenterPos()
{
	return _centerPos;
}

void Circle::Update()
{
	_centerPos = VECTOR2((_startPos.x + _endPos.x) / 2, (_startPos.y + _endPos.y) / 2);

	auto p = (_centerPos - _nextCenter).Normalize();
	float t = 0.0f;
	//�i�s����
	while (!_check/*_nextCenter + (p * ++_timeCnt) != _centerPos*/)//(++_timeCnt < _timeMax)
	{
		if (_nextCenter.x < -10000 || _nextCenter.y < - 10000)
		{
			_check = true;
			break;
		}

		_vec.emplace_back(p * _timeCnt);
		auto t = _nextCenter + (p * ++_timeCnt);
		if (t == _centerPos)
		{
			_check = true;
			break;
		}

		if (_nextCenter + (p * _timeCnt) != _centerPos)
		{

		}
		else
		{
			_check = true;
			break;
		}
	}
	_timeCnt = 0;
	if (_startPos.x != 0 && _startPos.y != 0)
	{
		if (_vec.size() > 0)
		{
			for (auto& vec : _vec)
			{
				//DrawCircle(_startPos.x + vec.x, _startPos.y + vec.y, 5, 0xffffff);
			}
		}
	}
}


void Circle::UpdatePush(VECTOR2 nextPos)
{
	if (_endFlag)
	{
		return;
	}

	_check = false;
	
	_centerPos = VECTOR2((_startPos.x + _endPos.x) / 2, (_startPos.y + _endPos.y) / 2);

	auto p = (nextPos - _centerPos).Normalize();
	float t = 0.0f;
	//�i�s����
	while (!_check)
	{
		if (_centerPos.x < -10000 || _centerPos.y < -10000)
		{
			_check = true;
			break;
		}

		_vecEnd.emplace_back(p * _timeCnt);
		auto t = _centerPos + (p * ++_timeCnt);
		if (t == nextPos)
		{
			_check = true;
			break;
		}

		if (_centerPos + (p * _timeCnt) != nextPos)
		{

		}
		else
		{
			_check = true;
			break;
		}
	}
	_timeCnt = 0;
}

void Circle::CenterDraw(unsigned int color)
{
	VECTOR2 lot = VECTOR2(1, 0).Normalize();

	auto p = 90 * PI / 180;
	auto angle = atan2(_endPos.y - _centerPos.y, _endPos.x - _centerPos.x) + 1.5f;

	_cource._rightPos.x = _centerPos.x + (_couseSize * cos(angle));
	_cource._rightPos.y = _centerPos.y + (_couseSize * sin(angle));

	_cource._leftPos.x = _centerPos.x + (_couseSize * cos(angle)) * -1;
	_cource._leftPos.y = _centerPos.y + (_couseSize * sin(angle)) * -1;

	/*DrawCircle(_cource._rightPos.x, _cource._rightPos.y, _size, 0xff0000);
	DrawCircle(_cource._leftPos.x, _cource._leftPos.y, _size, 0xff0000);*/

	_center._rightPos.x = _pos.x + (_couseSize * cos(angle));
	_center._rightPos.y = _pos.y + (_couseSize * sin(angle));

	_center._leftPos.x = _pos.x + (_couseSize * cos(angle)) * -1;
	_center._leftPos.y = _pos.y + (_couseSize * sin(angle)) * -1;

	/*DrawCircle(_center._rightPos.x, _center._rightPos.y, _size, color);
	DrawCircle(_center._leftPos.x, _center._leftPos.y, _size, color);*/

	//DrawCircle(_centerPos.x, _centerPos.y, _size, color);
}

void Circle::Draw(unsigned int color)
{

	//DrawCircle(_pos.x, _pos.y, _size, color);

	if (_startPos.x != 0 && _startPos.y != 0)
	{
		CenterDraw(0xffff00);
	}
}

void Circle::DrawHitBox(unsigned int color)
{
	//DrawBox(_hitCheck.left, _hitCheck.top, _hitCheck.right, _hitCheck.bottom, color, true);
}

void Circle::LineDraw(VECTOR2 nextPos)
{
	//DrawLine(_pos.x, _pos.y, nextPos.x, nextPos.y, 0xff0000);
}

void Circle::LineCenterDraw(VECTOR2 nextPos)
{
	//DrawLine(_centerPos.x, _centerPos.y, nextPos.x, nextPos.y, 0xff0000);
}

void Circle::LineCourceDraw(Cource cource, Cource backCource)
{
	if (_startPos.x == 0 && _startPos.y == 0)
	{
		return;
	}

	if ((cource._leftPos.x == 0 && cource._leftPos.y == 0) && (cource._rightPos.x == 0 && cource._rightPos.y == 0))
	{
		return;
	}


	auto getPoint = [&](float t, VECTOR2 v1, VECTOR2 v2, VECTOR2 v3)
	{
		float tp = 1 - t;
		VECTOR2 vec;
		vec.x = t * t*v3.x + 2 * t*tp*v2.x + tp * tp*v1.x;
		vec.y = t * t*v3.y + 2 * t*tp*v2.y + tp * tp*v1.y;
		return vec;
	};

	auto circleCheck = [&](VECTOR2 a, VECTOR2 b, float r)
	{
		float xdiff = b.x - a.x;
		float ydiff = b.y - a.y;

		bool ret = false;
		if (hypot(xdiff, ydiff) < (r + r))
		{
			ret = true;
		}

		return ret;
	};
	auto lp = (cource._leftPos - _cource._leftPos) / _timeMax;
	auto rp = (cource._rightPos - _cource._rightPos) / _timeMax;

	auto lpAbs = (cource._leftPos - _cource._leftPos);
	auto rpAbs = (cource._rightPos - _cource._rightPos);

	auto absL = abs(lpAbs.x + lpAbs.y);
	auto absR = abs(rpAbs.x + rpAbs.y);

	float lt = 0.0f;
	float rt = 0.0f;

	//�i�s����Left
	while (++Lcnt < _timeMax)
	{
		lt = (float)Lcnt / (float)_timeMax;

		auto leftv = getPoint(lt, _cource._leftPos, _center._leftPos, cource._leftPos);
		
		_vecL.emplace_back(leftv);
	}

	//�i�s����Right
	while (++Rcnt < _timeMax)
	{
		rt = (float)Rcnt / (float)_timeMax;
		
		auto rightv = getPoint(rt, _cource._rightPos, _center._rightPos, cource._rightPos);

		_vecR.emplace_back(rightv);
	}

	//�`��1
	if (_selectCnt == 0 || _selectCnt == 2)
	{
		if ((_cource._leftPos.x != 0 && _cource._leftPos.y != 0) && (_cource._rightPos.x != 0 && _cource._rightPos.y != 0))
		{

			for (int j = 0; j < _vecL.size(); ++j)
			{
				if (j % 60 <= 15)
				{
					DrawLine(_vecL[j].x, _vecL[j].y,_vecR[j].x,_vecR[j].y, GetColor(125, 120, 125), 5);
				}
				else
				{
					DrawLine(_vecL[j].x,_vecL[j].y,_vecR[j].x,_vecR[j].y, GetColor(130, 125, 130), 5);
				}
			}
		}
	}

	if (_selectCnt == 1 || _selectCnt == 2)
	{
		if (_cource._leftPos.x != 0 && _cource._leftPos.y != 0)
		{
			if (_vec.size() > 0)
			{
				for (auto& vec : _vecL)
				{
					DrawCircle(vec.x,vec.y, 6, 0xaaaaaa);
				}
			}
		}

		if (_cource._rightPos.x != 0 && _cource._rightPos.y != 0)
		{
			if (_vec.size() > 0)
			{
				for (auto& vec : _vecR)
				{
					DrawCircle(vec.x,vec.y, 5, 0xaaaaaa);
				}
			}
		}
	}

	if (_selectCnt == 3)
	{
		if (_cource._leftPos.x != 0 && _cource._leftPos.y != 0)
		{
			if (_vec.size() > 0)
			{
				VECTOR2 setCircle = { 0,0 };

				for (int j = 0; j < _vecL.size(); ++j)
				{
					if ((j - 1) > 0)
					{
						if (!circleCheck(setCircle, _vecL[j], 8))
						{
							DrawCircle(_vecL[j].x, _vecL[j].y, 8, GetColor(180, 200, 160));
							DrawCircle(_vecL[j].x, _vecL[j].y, 5, GetColor(240, 100, 100));
							setCircle = _vecL[j];

						}
					}
					else
					{
						setCircle = _cource._leftPos;

						if (!circleCheck(setCircle, _vecL[j], 8))
						{
							DrawCircle(_vecL[j].x, _vecL[j].y, 8, GetColor(180, 200, 160));
							DrawCircle(_vecL[j].x, _vecL[j].y, 5, GetColor(240, 100, 100));

							setCircle = _vecL[j];
						}
					}
				}
			}
		}

		if (_cource._rightPos.x != 0 && _cource._rightPos.y != 0)
		{
			if (_vec.size() > 0)
			{

				VECTOR2 setCircle = { 0,0 };
				for (int j = 0; j < _vecR.size(); ++j)
				{
					if((j - 1) > 0)
					{
						if (!circleCheck(setCircle, _vecR[j], 8))
						{
							DrawCircle(_vecR[j].x, _vecR[j].y, 8, GetColor(180, 200, 160));
							DrawCircle(_vecR[j].x, _vecR[j].y, 5, GetColor(240, 100, 100));

							setCircle = _vecR[j];
						}
					}
					else
					{
						setCircle = _cource._rightPos;

						if (!circleCheck(setCircle, _vecR[j], 8))
						{
							DrawCircle(_vecR[j].x, _vecR[j].y, 8, GetColor(180, 200, 160));
							DrawCircle(_vecR[j].x, _vecR[j].y, 5, GetColor(240, 100, 100));

							setCircle = _vecR[j];
						}
					}
					
				}
			}
		}
	}

}

void Circle::SetPos(VECTOR2 pos)
{
	_pos = pos;
}

void Circle::SetStartPos(VECTOR2 pos)
{
	_startPos = pos;
}

void Circle::SetEndPos(VECTOR2 pos)
{
	_endPos = pos;
}

void Circle::SetCoursePos(VECTOR2 right, VECTOR2 left)
{
	_cource._rightPos = right;
	_cource._leftPos = left;
}

const Cource& Circle::GetCource()
{
	return _cource;
}

const Cource & Circle::GetCenter()
{
	return _center;
}

bool Circle::GetHitCheck(VECTOR2 pos)
{
	if (pos.x > _hitCheck.left&& pos.x < _hitCheck.right)
	{
		if (pos.y > _hitCheck.top&& pos.y < _hitCheck.bottom)
		{
			return true;
		}
	}

	return false;
}

