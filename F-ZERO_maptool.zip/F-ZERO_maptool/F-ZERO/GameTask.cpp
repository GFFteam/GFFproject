#include "DxLib.h"
#include "GameTask.h"
#include "ImageMng.h"
#include <iostream>
#include <vector>
#include <algorithm>
#include "MouseMng.h"
#include "KeyMng.h"
#include "Circle.h"
#include "Enemy.h"
#include "Button.h"
#include "MeterBox.h"

GameTask *GameTask::s_Instance = nullptr;

std::shared_ptr<Enemy> _enemy;
vector<std::shared_ptr<Circle>> vectors;
vector<std::shared_ptr<Circle>> center;
std::vector<Cource> _cource;
vector<std::shared_ptr<Button>> _button;
vector<std::shared_ptr<MeterBox>> _meter;


VECTOR2 vec = VECTOR2(0, 0);
VECTOR2 pos = VECTOR2(0, 0);


struct Data
{
	int size;
	std::vector<Cource> cource;
};



#define BBM_ID_NAME "BBM_MAP_DATA"	// ̧�َ��
#define BBM_VER_ID 0x01				// ̧���ް�ޮ�


void GameTask::Create(void)
{
	if (!s_Instance)
	{
		s_Instance = new GameTask();
	}
}

int GameTask::SystemInit()
{
	SetWindowText("Template");
	SetGraphMode(SCREEN_SIZE_X, SCREEN_SIZE_Y, 16);
	ChangeWindowMode(true);
	if (DxLib_Init() == -1) {
		return -1;
	}
	SetDrawScreen(DX_SCREEN_BACK);

}

void GameTask::GameUpdate()
{
	// ���݂̃��[�h�ŉ�
	(this->*gMode[currentMode])();
}

void GameTask::GameInit()
{
	DrawString(10, 10, "INIT", 0xffffff);

	_enemy = std::make_shared<Enemy>();
	_button.emplace_back(std::make_shared<Button>("���",VECTOR2(GAME_SIZE_X + 50,100), VECTOR2(128,64)));
	_button.emplace_back(std::make_shared<Button>("�o��", VECTOR2(GAME_SIZE_X + 50, 200), VECTOR2(128, 64)));

	_button.emplace_back(std::make_shared<Button>("�g��o��", VECTOR2(GAME_SIZE_X + 50, 300), VECTOR2(128, 64)));

	_meter.emplace_back(std::make_shared <MeterBox>(VECTOR2(GAME_SIZE_X + 50, 400), VECTOR2(128, 64), 100));
	//lineVec.push_back(reset);
	handle = LoadGraph("image/screen.png");

	//DrawExtendGraph(0, 0, GAME_SIZE_X * 2, GAME_SIZE_Y * 2, handle, true);
	//auto SaveGameMain = SaveDrawScreenToPNG(0, 0, GAME_SIZE_X * 2, GAME_SIZE_Y * 2, "image/screen2.png");

	//--------------------------------------------------
	// ������
	//--------------------------------------------------
	currentMode = G_INIT;

	currentMode = G_MAIN;

}

void GameTask::GameMain()
{
	int _getMeterCnt = 0;

	//DrawString(10, 10, "MAIN", 0xffffff);
	DrawBox(GAME_SIZE_X, 0, SCREEN_SIZE_X, SCREEN_SIZE_Y, GetColor(100, 150, 50), true);
	if (_popFlag)
	{
		//DrawString(10, 30, "�ړ�", 0xffffff);
		if (_checkFlag)
		{
			//DrawString(10, 50, "Hold:On", 0xffffff);
		}
		else
		{
			//DrawString(10, 50, "Hold:Off", 0xffffff);
		}
	}
	else
	{
		//DrawString(10, 30, "�`��", 0xffffff);

		//DrawString(10, 50, "Hold:Off", 0xffffff);
	}

	MouseMng::GetInstance().Update();
	KeyMng::GetInstance().Update();

	int Mx, My;
	bool uploadFlag = false;

	GetMousePoint(&Mx, &My);

	for (auto& b : _button)
	{
		b->Draw();

		if (MouseMng::GetInstance().trgKey[P1_PUSH] && b->GetHitCheck(VECTOR2(Mx,My)))
		{
			if (b->GetString() == "���")
			{
				if (!_finishFlag)
				{
					_finishFlag = true;
				}
				else
				{
					_finishFlag = false;
				}
			}
			if (b->GetString() == "�o��")
			{
				uploadFlag = true;
			}
			if (b->GetString() == "�g��o��")
			{
				extendFlag = true;
			}
		}
	}

	for (auto& m : _meter)
	{
		m->Update(VECTOR2(Mx,My));
		m->Draw();
		_getMeterCnt = m->GetCnt();
	}


	if (!_checkFlag && !_finishFlag && !_UICheckFlag)
	{
		if (MouseMng::GetInstance().trgKey[P1_PUSH])
		{
			for (auto& p : vectors)
			{
				if (_popFlag && p->GetHitCheck(VECTOR2(Mx, My)))
				{
					_checkFlag = true;
					p->SetCheckFlag(_checkFlag);
					break;
				}
			}

			if (_checkFlag)
			{

			}
			else
			{
				//�د�������ǉ�
				_popFlag = false;
				int x, y;
				GetMousePoint(&x, &y);
				if (vectors.size() <= 0)
				{
					//CPU�̃X�^�[�g���̍��W�ݒ�
					_startPos = VECTOR2(x,y);

				}
				vectors.push_back(std::make_shared<Circle>(VECTOR2(x, y), vec, VECTOR2(x, y)));
				auto centerPos = VECTOR2((vec.x + x) / 2, (vec.y + y) / 2);
				if (vectors.size() == 2)
				{
					_enemy->SetPos(centerPos);
				}
				if (vectors.size() > 1)
				{
					_enemy->PushLineStart(centerPos);
				}
				std::vector<VECTOR2> vx;
				_enemyVec.emplace_back(vx);
				vec.x = x;
				vec.y = y;
			}
		}
		else if (MouseMng::GetInstance().trgKey[P1_POP])
		{
			_popFlag = true;
		}
	}
	else
	{
		if (_checkFlag && MouseMng::GetInstance().newKey[P1_PUSH])
		{
			for (auto& p : vectors)
			{
				if (_popFlag && p->GetCheckFlag())
				{
					p->SetPos(VECTOR2(Mx, My));
					break;
				}
			}


			for (int i = 0; i + 1 <= vectors.size(); ++i)
			{
				if (vectors[i]->GetCheckFlag())
				{
					if (i + 1 < vectors.size())
					{
						vectors[i + 1]->SetStartPos(vectors[i]->GetPos());
					}
					vectors[i]->SetEndPos(vectors[i]->GetPos());
				}
			}

		}
		else if (MouseMng::GetInstance().trgKey[P1_POP])
		{
			_checkFlag = false;
			for (auto& p : vectors)
			{
				p->SetCheckFlag(_checkFlag);
			}
		}
	}
	for (int j = 0; j < vectors.size(); ++j)
	{
		if ((j + 1) >= vectors.size() && j != 0)
		{
			if (j != 1 && _finishFlag)
			{
				vectors[j]->LineCourceDraw(vectors[1]->GetCource(), vectors[j - 1]->GetCource());
				vectors[j]->UpdatePush(vectors[1]->GetCenterPos());

				if (vectors[j]->GetEndFlag() == false)
				{
					_enemyVec.emplace_back(vectors[j]->GetVectorsEnd());
					vectors[j]->SetEndFlag(true);
				}
				break;
			}
		}
		if ((j + 1) < vectors.size())
		{

			vectors[j]->LineDraw(vectors[j + 1]->GetPos());
			if ((j - 1) >= 0)
			{
				vectors[j]->LineCourceDraw(vectors[j + 1]->GetCource(), vectors[j - 1]->GetCource());
			}
		}

		if (j != 0)
		{
			vectors[j]->SetNextCenter(vectors[j - 1]->GetCenterPos());
		}

		_enemyVec[j] = vectors[j]->GetVectors();

		if ((j + 1) >= vectors.size() && j != 0)
		{
			if (j != 1 && _finishFlag)
			{
				
			}
		}
	}

	if (vec.x != 0 && vec.y != 0 && !_popFlag)
	{
		DrawLine(vec.x, vec.y, Mx, My, 0xff0000);
	}

	auto end = VECTOR2(0, 0);

	if (vectors.size() > 0)
	{
		if (KeyMng::GetInstance().trgKey[P1_ENTER] && vectors[0]->GetSelectCnt() < 3)
		{
			vectors[0]->SelectAddCnt(1);
		}
		else if (KeyMng::GetInstance().trgKey[P1_ENTER] && vectors[0]->GetSelectCnt() >= 3)
		{
			vectors[0]->SelectSetCnt(0);
		}
	}

	for (auto& p : vectors)
	{
		//p->SetCourceSize(_getMeterCnt);
		p->SetHitCheck();
		p->DrawHitBox(0xff00ff);
		p->Update();
		p->Draw();

		if (_popFlag && p->GetHitCheck(vec))
		{
			auto p = 0;
		}
	}

	_UICheckFlag = (Mx > GAME_SIZE_X);

	_enemy->SetStartPos(_startPos);
	_enemy->SetVector(_enemyVec);

	_enemy->Update();
	_enemy->Draw();

	_enemyStart = _enemy->GetStartPos();

	if (extendFlag)
	{
		ExternUpload();
	}

	if (uploadFlag)
	{
		Upload();
	}

	if (CheckHitKey(KEY_INPUT_F2))
	{
		Data data;
		FILE* file;
		fopen_s(&file, "data/mapdata.map", "rb");
		fread(&data, sizeof(Data), sizeof(Data), file);


		fclose(file);

	}
}

void GameTask::Upload()
{
	auto size = 0;
	for (auto& p : vectors)
	{
		if ((_cource.size() < vectors.size()) && p->GetCource()._leftPos.x != 0)
		{
			_cource.emplace_back(p->GetCource());
			
		}
	}
	auto SaveGameMain = SaveDrawScreenToPNG(0, 0, GAME_SIZE_X, GAME_SIZE_Y, "image/screen.png");

	Data data;
	data.size = _cource.size();
	data.cource = _cource;


	FILE* file;
	fopen_s(&file, "data/data.map", "wb+");
	auto Csize = sizeof(Cource);
	int Not = 0;
	fwrite(&data.size, sizeof(int), 1, file);
	fwrite(&Not, sizeof(int), 1, file);
	fwrite(&_enemyStart, sizeof(VECTOR2), 1, file);

	for (int j = 0; j < data.size; ++j)
	{
		Cource cour;
		cour = _cource[j];
		fwrite(&cour, sizeof(Cource), 1, file);
	}

	//fwrite(&data, sizeof(Data), sizeof(Data), file);
	fclose(file);

}

void GameTask::ExternUpload()
{
	Data data;
	FILE* file;
	fopen_s(&file, "data/data.map", "rb");
	if (!file)
	{
		return;
	}
	fread(&data.size, sizeof(int), 1, file);

	int dummy = 0;
	for (int i = 0; i < 3; ++i)
	{
		fread(&dummy, sizeof(int), 1, file);
	}
	data.cource.resize(data.size);

	for (int j = 0; j < data.cource.size(); ++j)
	{
		fread(&data.cource[j], sizeof(Cource), 1, file);
	}


	fclose(file);

	//ScreenFlip();
	//ClearDrawScreen();
	//DrawExtendGraph(0, 0, GAME_SIZE_X * 2, GAME_SIZE_Y * 2, handle, true);
	//auto SaveGameMain = SaveDrawScreenToPNG(0, 0, GAME_SIZE_X*2, GAME_SIZE_Y*2, "image/screen2.png");

}


