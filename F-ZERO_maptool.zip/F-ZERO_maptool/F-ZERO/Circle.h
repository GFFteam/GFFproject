#pragma once
#include "VECTOR2.h"
#include <Windows.h>
//�R�[�X���p�̘g
struct Cource
{
	VECTOR2 _rightPos = { 0,0 };
	VECTOR2 _leftPos = { 0,0 };
};

class Circle
{
public:


	Circle();
	Circle(VECTOR2 p);
	Circle(VECTOR2 p, VECTOR2 startPos, VECTOR2 endPos);

	~Circle();

	const VECTOR2& GetPos();
	const VECTOR2& GetCenterPos();
	void Update();
	void UpdatePush(VECTOR2 nextPos);
	void CenterDraw(unsigned int color = 0xffffff);
	void Draw(unsigned int color = 0xffffff);
	void DrawHitBox(unsigned int color = 0xffffff);
	void LineDraw(VECTOR2 nextPos);
	void LineCenterDraw(VECTOR2 nextPos);
	void LineCourceDraw(Cource cource, Cource center);

	void SetPos(VECTOR2 pos);
	void SetStartPos(VECTOR2 pos);
	void SetEndPos(VECTOR2 pos);

	void SetCoursePos(VECTOR2 right, VECTOR2 left);
	const Cource& GetCource();
	const Cource& GetCenter();

	bool GetHitCheck(VECTOR2 pos);
	void SetHitCheck();
	void SetHitCheck(VECTOR2 pos);

	void SetCheckFlag(bool flag);
	const bool& GetCheckFlag();

	void SetNextCenter(VECTOR2 pos);

	const std::vector<VECTOR2>& GetVectors();
	const std::vector<VECTOR2>& GetVectorsEnd();

	const int& GetSelectCnt();
	void SelectAddCnt(int cnt);
	void SelectSetCnt(int cnt);

	void SetCourceSize(int size);

	const bool& GetEndFlag();
	void SetEndFlag(bool flag);

private:

	VECTOR2 lerp(VECTOR2 lerp, VECTOR2 start, VECTOR2 end, float t);
	//���S�_
	VECTOR2 _pos;
	VECTOR2 _centerPos;
	VECTOR2 _nextCenter;
	VECTOR2 _startPos;
	VECTOR2 _endPos;

	Cource _cource;
	Cource _center;
	RECT _hitCheck;

	bool _check = false;
	bool _checkFlag = false;
	unsigned int _size = 6;
	int _couseSize = 50;
	unsigned int _timeMax = 50;
	int _timeCnt = 0;
	int Lcnt = 0,Rcnt = 0;
	static int _selectCnt;
	std::vector<VECTOR2> _vec;
	std::vector<VECTOR2> _vecEnd;
	bool _endFlag = false;

	std::vector<VECTOR2> _vecL;
	std::vector<VECTOR2> _vecR;

};

