#include "UI.h"
#include "DxLib.h"
#include "ResourceMng.h"
#include "KeyMng.h"
#include "Share.h"
#include <iostream>

UI::UI()
{
	Init();
}

UI::~UI()
{
}

void UI::Init()
{
	_lap.lap1_1 = _lap.lap1_10 = _lap.lap10_1 = _lap.lap10_10 = _lap.lap100_1 = _lap.lap100_10 = 0;
	DIV_IMAGE_ID("data/images/Number/number.png", 10, 10, 1, 0, 0, 50, 50, num);
	DIV_IMAGE_ID("data/images/speedNumR.png", 5, 2, 3, 0, 0, 110, 50, tacho.speedNum);

	//RankingInit();

	FILE* file;

	fopen_s(&file, "data/CircuitData/RankingData.map", "rb");

	if (!file)
	{
		return;
	}
	fread(&_getData.setCntm1, sizeof(float), 1, file);
	fread(&_getData.setCntm10, sizeof(float), 1, file);
	fread(&_getData.setCnts1, sizeof(float), 1, file);
	fread(&_getData.setCnts10, sizeof(float), 1, file);
	fread(&_getData.setCntM1, sizeof(float), 1, file);
	fread(&_getData.setCntM10, sizeof(float), 1, file);

	fread(&_getData._lapTimeValue, sizeof(float), 1, file);

	for (int j = 0; j < 5; ++j)
	{
		float dataf;
		fread(&dataf, sizeof(float), 1, file);
		_getData._lapValue.emplace_back(dataf);
	}
	fclose(file);


}

void UI::RankingInit()
{
	FILE* file;

	fopen_s(&file, "data/CircuitData/RankingTime.map", "rb");

	if (!file)
	{
		return;
	}
	fread(&_rankingO.size, sizeof(int), 1, file);

	_rankingO._ranking.resize(_rankingO.size);

	for (int j = 0; j < _rankingO.size; ++j)
	{
		fread(&_rankingO._ranking[j].setCntm1, sizeof(float), 1, file);
		fread(&_rankingO._ranking[j].setCntm10, sizeof(float), 1, file);
		fread(&_rankingO._ranking[j].setCnts1, sizeof(float), 1, file);
		fread(&_rankingO._ranking[j].setCnts10, sizeof(float), 1, file);
		fread(&_rankingO._ranking[j].setCntM1, sizeof(float), 1, file);
		fread(&_rankingO._ranking[j].setCntM10, sizeof(float), 1, file);

		fread(&_rankingO._ranking[j]._lapTimeValue, sizeof(float), 1, file);


		for (int i = 0; i < 5; ++i)
		{
			float dataf;
			fread(&dataf, sizeof(float), 1, file);
			_rankingO._ranking[j]._lapValue.emplace_back(dataf);
		}

	}
	fclose(file);

}

void UI::Update()
{
	if (lpGameTask.GetRaceStart()._startFlag)
	{
		LapTimeUpdate();
	}
	else
	{
	}

	tacho.speed = Share::GetInstance().GetSpeed() * 100;
	tacho.circleSpeed = Share::GetInstance().GetSpeed() * SPEED_CIRCLE_SCALE;

	tacho.throttlePct = Share::GetInstance().GetThrottleParcent() * 50;
	tacho.brakePct = Share::GetInstance().GetBrakeParcent() * 50;

	tacho.fuel = Share::GetInstance().GetFuel();

	tacho.lrFlag = Share::GetInstance().GetLRFlag();


	tacho.sp1 = (int)tacho.speed % 10;
	tacho.sp10 = ((int)tacho.speed / 10) % 10;
	tacho.sp100 = (int)tacho.speed / 100;

	if (KeyMng::GetInstance().newKey[P1_UP])
	{
		tacho.gReturnCount -= 0.15;
		if (tacho.gReturnCount < -50.0f)
		{
			tacho.gReturnCount = -50.0f;
		}
	}
	else if (KeyMng::GetInstance().newKey[P1_DOWN] && tacho.speed != 0.0f)
	{
		tacho.gReturnCount += 0.8f;
		if (tacho.gReturnCount > 50.0f)
		{
			tacho.gReturnCount = 50.0f;
		}
	}
	else
	{
		tacho.gReturnCount = 0.0f;
	}

	tacho.gSensor.x = -(Share::GetInstance().GetYawPercent() * tacho.gOffset) + tacho.gRand.x;

	tacho.gRand.x = GetRand(abs(tacho.lrFlag) * 2);
	tacho.gRand.y = GetRand(tacho.sp100 + abs(tacho.lrFlag)) - (tacho.sp100 + abs(tacho.lrFlag));

	if (tacho.speed != 0.0f)
	{
		tacho.gBrake = tacho.brakePct;
	}
	else
	{
		tacho.gBrake = 0.0f;
	}

	tacho.gSensor.y = ((tacho.throttlePct - tacho.gBrake + tacho.gReturnCount) * tacho.gOffset) + tacho.gRand.y;


	// ����
	if (Share::GetInstance().GetEnemyLapCnt() > Share::GetInstance().GetLapCnt())
	{
		position = 2;
	}
	else if (Share::GetInstance().GetEnemyLapCnt() < Share::GetInstance().GetLapCnt())
	{
		position = 1;
	}
	else
	{
		if (Share::GetInstance().GetRotDistanceVec().y < 0)
		{
			position = 2;
		}
		else
		{
			position = 1;
		}
	}
	if (!lpGameTask.GetRaceStart()._startFlag)
	{
		position = 1;
	}

	if (lpGameTask.GetRaceMode() == RACE_MODE::TIME_ATTACK)
	{
		position = 1;
	}

	Share::GetInstance().SetPosition(position);

}

void UI::LapTimeUpdate()
{
	_lap.lap1 += (100.0f / 60.0f);

	_lap.lap1_1 = _lap.lap1;


	if (_lap.lap1_1 >= 10)
	{
		_lap.lap1 = 0.0f;
		_lap.lap1_1 = 0;
		_lap.lap1_10++;
		if (_lap.lap1_10 >= 10)
		{
			_lap.lap1_10 = 0;
			_lap.lap10_1++;

			if (_lap.lap10_1 >= 10)
			{
				_lap.lap10_1 = 0;
				_lap.lap10_10++;

				if (_lap.lap10_10 >= 6)
				{
					_lap.lap10_10 = 0;
					_lap.lap100_1++;
					if (_lap.lap100_1 >= 10)
					{
						_lap.lap100_1 = 0;
						_lap.lap100_10++;

						if (_lap.lap100_10 >= 10)
						{
							_lap.lap100_10 = 0;
						}
					}
				}

			}
		}
	}
}

void UI::Draw()
{
	/*SetDrawBlendMode(DX_BLENDMODE_ALPHA, 200);
	DrawBox(SCREEN_SIZE_X / 2 + SCREEN_SIZE_X / 4, 0, SCREEN_SIZE_X, SCREEN_SIZE_Y, GetColor(50, 50, 50), true);
	SetDrawBlendMode(DX_BLENDMODE_NOBLEND, 0);*/

	// �^�R���[�^�[�x�[�X
	DrawRotaGraph(LEFT_TACHO_CENTER_X, LEFT_TACHO_CENTER_Y, 1.0f, 0, IMAGE_ID("data/images/tachoCircleWsc1.2.png"), true);
	DrawRotaGraph(SCREEN_SIZE_X / 2 + 110, SCREEN_SIZE_Y - 55, 1.0f, 0, IMAGE_ID("data/images/tachoCircleW2.png"), true);
	DrawRotaGraph(SCREEN_SIZE_X / 2 - 70, SCREEN_SIZE_Y - 15, 0.5f, 0, IMAGE_ID("data/images/tachoUnitW.png"), true);

	// �X�s�[�h��
	// �G���W���X�s�[�h
	DrawRotaGraph(LEFT_TACHO_CENTER_X + 35, LEFT_TACHO_CENTER_Y, 1, 0, num[tacho.sp1], true);
	DrawRotaGraph(LEFT_TACHO_CENTER_X, LEFT_TACHO_CENTER_Y, 1, 0, num[tacho.sp10], true);
	DrawRotaGraph(LEFT_TACHO_CENTER_X - 35, LEFT_TACHO_CENTER_Y, 1, 0, num[tacho.sp100], true);

	DrawRotaGraph(LEFT_TACHO_CENTER_X, LEFT_TACHO_CENTER_Y - 40, 0.25f, 0, IMAGE_ID("data/images/speed.png"), true);
	DrawCircleGauge(LEFT_TACHO_CENTER_X - 1, LEFT_TACHO_CENTER_Y + 1, 61.0f + tacho.circleSpeed, IMAGE_ID("data/images/greenCircle2.png"),61.0f);
	
	DrawRotaGraph(LEFT_TACHO_CENTER_X - 70, LEFT_TACHO_CENTER_Y, 0.2f, -90 * (PI / 180), tacho.speedNum[0], true);
	DrawRotaGraph(LEFT_TACHO_CENTER_X - 50, LEFT_TACHO_CENTER_Y - 45, 0.2f, -45 * (PI / 180), tacho.speedNum[1], true);
	DrawRotaGraph(LEFT_TACHO_CENTER_X, LEFT_TACHO_CENTER_Y - 70, 0.2f, 0, tacho.speedNum[2], true);
	DrawRotaGraph(LEFT_TACHO_CENTER_X + 50, LEFT_TACHO_CENTER_Y - 45, 0.2f, 45 * (PI / 180), tacho.speedNum[3], true);
	DrawRotaGraph(LEFT_TACHO_CENTER_X + 70, LEFT_TACHO_CENTER_Y, 0.2f, 90 * (PI / 180), tacho.speedNum[4], true);


	// �X���b�g���ƃu���[�L
	DrawRotaGraph(RIGHT_L_TACHO_CENTER_X - 50, RIGHT_L_TACHO_CENTER_Y, 0.20f, -90 * (PI / 180), IMAGE_ID("data/images/brake.png"), true);
	DrawRotaGraph(RIGHT_L_TACHO_CENTER_X + 50, RIGHT_L_TACHO_CENTER_Y, 0.3f, 90 * (PI / 180), IMAGE_ID("data/images/throttle.png"), true);

	DrawCircleGauge(RIGHT_L_TACHO_CENTER_X, RIGHT_L_TACHO_CENTER_Y - 1,100 + tacho.throttlePct, IMAGE_ID("data/images/gCircle2_L.png"),50.0f,1.0f, 0,50);
	DrawCircleGauge(RIGHT_L_TACHO_CENTER_X, RIGHT_L_TACHO_CENTER_Y, 50.0f + tacho.brakePct, IMAGE_ID("data/images/rCircle2_L.png"), 50.0f,1.0f);

	// ���̑�����
	DrawRotaGraph(RIGHT_L_TACHO_CENTER_X, RIGHT_L_TACHO_CENTER_Y, 0.15f, 0, IMAGE_ID("data/images/g.png"), true);
	DrawLine(RIGHT_L_TACHO_CENTER_X, RIGHT_L_TACHO_CENTER_Y - 40, RIGHT_L_TACHO_CENTER_X, RIGHT_L_TACHO_CENTER_Y + 40, 0xffffff, 2);
	DrawLine(RIGHT_L_TACHO_CENTER_X - 40, RIGHT_L_TACHO_CENTER_Y, RIGHT_L_TACHO_CENTER_X + 40, RIGHT_L_TACHO_CENTER_Y, 0xffffff, 2);

	DrawRotaGraph(RIGHT_S_TACHO_CENTER_X + 25, RIGHT_S_TACHO_CENTER_Y - 10, 0.07f, 0, IMAGE_ID("data/images/fuelLight.png"), true);
	DrawRotaGraph(RIGHT_S_TACHO_CENTER_X, RIGHT_S_TACHO_CENTER_Y - 35, 1.5f, 0, IMAGE_ID("data/images/fuelFull.png"), true);
	DrawRotaGraph(RIGHT_S_TACHO_CENTER_X + 35, RIGHT_S_TACHO_CENTER_Y + 15, 1.5f, 0, IMAGE_ID("data/images/fuelEmpty.png"), true);
	DrawRotaGraph(RIGHT_S_TACHO_CENTER_X, RIGHT_S_TACHO_CENTER_Y, 1.0f, (115 - (tacho.fuel * 1.15)) * (PI / 180), IMAGE_ID("data/images/fuelIndicator2.png"), true);

	DrawCircle(tacho.gPos.x + tacho.gSensor.x, tacho.gPos.y + tacho.gSensor.y, 4, 0xff0000, true);

	// ���b�v�n
	DrawRotaGraph(SCREEN_SIZE_X - 125, 25, 0.45f, 0, IMAGE_ID("data/images/position.png"), true);

	if (lpGameTask.GetRaceMode() == RACE_MODE::TIME_ATTACK)
	{
		DrawRotaGraph(SCREEN_SIZE_X - 145, 250 + 100, 0.45f, 0, IMAGE_ID("data/images/Number/high.png"), true);
		DrawRotaGraph(SCREEN_SIZE_X - 60, 250 + 100, 0.45f, 0, IMAGE_ID("data/images/Number/score.png"), true);
	}


	DrawRotaGraph(SCREEN_SIZE_X - 125, 70, 0.7f, 0.0f, num[position], true);

	if (position == 2)
	{
		DrawRotaGraph(SCREEN_SIZE_X - 80, 73, 0.4f, 0.0f, IMAGE_ID("data/images/nd.png"), true);
	}
	else
	{
		DrawRotaGraph(SCREEN_SIZE_X - 80, 73, 0.4f, 0.0f, IMAGE_ID("data/images/st.png"), true);
	}
	DrawRotaGraph(SCREEN_SIZE_X - 125, ((SCREEN_SIZE_Y / 2.5f) + 25) / 2, 0.3f, 0, IMAGE_ID("data/images/lap.png"), true);
	DrawRotaGraph(SCREEN_SIZE_X - 125, (((SCREEN_SIZE_Y / 2.5f) + 25) / 2) + 45, 0.5f, 0.0f, IMAGE_ID("data/images/per.png"), true);
	DrawRotaGraph(SCREEN_SIZE_X - 175, (((SCREEN_SIZE_Y / 2.5f) + 25) / 2) + 45, 0.6f, 0.0f, num[(Share::GetInstance().GetLapCnt() == 0 ? 1 : Share::GetInstance().GetLapCnt())], true);
	DrawRotaGraph(SCREEN_SIZE_X - 75, (((SCREEN_SIZE_Y / 2.5f) + 25) / 2) + 45, 0.6f, 0.0f, num[6], true);

	DrawRotaGraph(SCREEN_SIZE_X - 125, SCREEN_SIZE_Y / 2.5f , 0.3f, 0, IMAGE_ID("data/images/lapTime.png"), true);


	LapTimeDraw();
}

void UI::LapTimeDraw()
{
	_setValueFlag = false;
	//�_�P��
	DrawRotaGraph(SCREEN_SIZE_X - 125 + _numberSize * 4, 160 + 100, 0.5, 0, num[_lap.lap1_1], true);
	DrawRotaGraph(SCREEN_SIZE_X - 125 + _numberSize * 3, 160 + 100, 0.5, 0, num[_lap.lap1_10], true);

	//�b
	DrawRotaGraph(SCREEN_SIZE_X - 125 + _numberSize * 2 - 10, 160 + 100, 0.5, 0, num[_lap.lap10_1], true);
	DrawRotaGraph(SCREEN_SIZE_X - 125 + _numberSize * 1 - 10, 160 + 100, 0.5, 0, num[_lap.lap10_10], true);

	//��
	DrawRotaGraph(SCREEN_SIZE_X - 125 - 20, 160 + 100, 0.5, 0, num[_lap.lap100_1], true);
	DrawRotaGraph(SCREEN_SIZE_X - 125 - _numberSize - 20, 160 + 100, 0.5, 0, num[_lap.lap100_10], true);

	//:
	DrawRotaGraph(SCREEN_SIZE_X - 125 + _numberSize * 3 - 17, 160 + 100, 0.5, 0, IMAGE_ID("data/images/Number/numberT.png"), true);
	DrawRotaGraph(SCREEN_SIZE_X - 125 + _numberSize * 1 - 10 - 17, 160 + 100, 0.5, 0, IMAGE_ID("data/images/Number/numberT.png"), true);

	
	//laptime�o�͕`��
	OutPutDraw();

	if (lpGameTask.GetRaceMode() == RACE_MODE::TIME_ATTACK)
	{
		//�n�C�X�R�A�`��
		HighScoreDraw();
	}

	if (_lap._setLapCnt != 0 && (_lap._setLapCnt < Share::GetInstance().GetLapCnt()))
	{
		SetLapValue();
	}

	_lap._setLapCnt = Share::GetInstance().GetLapCnt();

}


void UI::OutPutDraw()
{
	//�o��
	//�_�P��
	DrawRotaGraph(SCREEN_SIZE_X - 125 + _numberSize * 4, 200 + 100, 0.4, 0, num[(int)_output.setCntm1], true);
	DrawRotaGraph(SCREEN_SIZE_X - 125 + _numberSize * 3 + 5, 200 + 100, 0.4, 0, num[(int)_output.setCntm10], true);


	//�b
	DrawRotaGraph(SCREEN_SIZE_X - 125 + _numberSize * 2 - 5, 200 + 100, 0.4, 0, num[(int)_output.setCnts1], true);
	DrawRotaGraph(SCREEN_SIZE_X - 125 + _numberSize * 1, 200 + 100, 0.4, 0, num[(int)_output.setCnts10], true);

	//��
	DrawRotaGraph(SCREEN_SIZE_X - 125 - 10, 200 + 100, 0.4, 0, num[(int)_output.setCntM1], true);
	DrawRotaGraph(SCREEN_SIZE_X - 125 - _numberSize - 5, 200 + 100, 0.4, 0, num[(int)_output.setCntM10], true);

	//:
	DrawRotaGraph(SCREEN_SIZE_X - 125 + _numberSize * 3 + 5 - 18, 200 + 100, 0.4, 0, IMAGE_ID("data/images/Number/numberT.png"), true);
	DrawRotaGraph(SCREEN_SIZE_X - 125 + _numberSize * 1 - 18, 200 + 100, 0.4, 0, IMAGE_ID("data/images/Number/numberT.png"), true);
}

void UI::HighScoreDraw()
{
	//�n�C�X�R�A
	//�_�P��
	DrawRotaGraph(SCREEN_SIZE_X - 125 + _numberSize * 4, 280 + 100, 0.5, 0, num[(int)_getData.setCntm1], true);
	DrawRotaGraph(SCREEN_SIZE_X - 125 + _numberSize * 3, 280 + 100, 0.5, 0, num[(int)_getData.setCntm10], true);

	//�b
	DrawRotaGraph(SCREEN_SIZE_X - 125 + _numberSize * 2 - 10, 280 + 100, 0.5, 0, num[(int)_getData.setCnts1], true);
	DrawRotaGraph(SCREEN_SIZE_X - 125 + _numberSize * 1 - 10, 280 + 100, 0.5, 0, num[(int)_getData.setCnts10], true);

	//��
	DrawRotaGraph(SCREEN_SIZE_X - 125 - 20, 280 + 100, 0.5, 0, num[(int)_getData.setCntM1], true);
	DrawRotaGraph(SCREEN_SIZE_X - 125 - _numberSize - 20, 280 + 100, 0.5, 0, num[(int)_getData.setCntM10], true);

	//:
	DrawRotaGraph(SCREEN_SIZE_X - 125 + _numberSize * 3 - 17, 280 + 100, 0.5, 0, IMAGE_ID("data/images/Number/numberT.png"), true);
	DrawRotaGraph(SCREEN_SIZE_X - 125 + _numberSize * 1 - 10 - 17, 280 + 100, 0.5, 0, IMAGE_ID("data/images/Number/numberT.png"), true);
}

void UI::SetLapValue()
{
	OutPutTime o;

	//�~��
	o.setCntm1 = _lap.lap1_1;
	o.setCntm10 = _lap.lap1_10;
	//�b
	o.setCnts1 = _lap.lap10_1;
	o.setCnts10 = _lap.lap10_10;
	//��
	o.setCntM1 = _lap.lap100_1;// *100;
	o.setCntM10 = _lap.lap100_10;// *1000;

	float OsetCntm1 = o.setCntm1 * 0.01f;
	float OsetCntm10 = o.setCntm10 * 0.1f;
	float OsetCnts1 = o.setCnts1;
	float OsetCnts10 = o.setCnts10 * 10;
	float OsetCntM1 = o.setCntM1 * 100;
	float OsetCntM10 = o.setCntM10 * 1000;

	//���v
	o._lapTimeValue = OsetCntm1 + OsetCntm10 + OsetCnts1 + OsetCnts10 + OsetCntM1 + OsetCntM10;
	o._lapValue.emplace_back(o._lapTimeValue);
	if (o._lapTimeValue < _output._lapTimeValue)
	{
		_fastLap.emplace_back(o);
	}
	else if(_output._lapTimeValue > 0)
	{
		_setValueFlag = true;

		//�~��
		_lap.lap1_1 = 0;
		_lap.lap1_10 = 0;
		//�b
		_lap.lap10_1 = 0;
		_lap.lap10_10 = 0;
		//��
		_lap.lap100_1 = 0;// *100;
		_lap.lap100_10 = 0;// *1000;

		return;
	}
	//�ۑ�
	//�~��
	_output.setCntm1 = _lap.lap1_1;
	_output.setCntm10 = _lap.lap1_10;
	//�b
	_output.setCnts1 = _lap.lap10_1;
	_output.setCnts10 = _lap.lap10_10;
	//��
	_output.setCntM1 = _lap.lap100_1;// *100;
	_output.setCntM10 = _lap.lap100_10;// *1000;

									   //�o�͗p�Ɍv�Z
	float setCntm1 = _output.setCntm1 * 0.01f;
	float setCntm10 = _output.setCntm10 * 0.1f;
	float setCnts1 = _output.setCnts1;
	float setCnts10 = _output.setCnts10 * 10;
	float setCntM1 = _output.setCntM1 * 100;
	float setCntM10 = _output.setCntM10 * 1000;


	//���v
	_output._lapTimeValue = setCntm1 + setCntm10 + setCnts1 + setCnts10 + setCntM1 + setCntM10;
	_output._lapValue.emplace_back(_output._lapTimeValue);
	_setValueFlag = true;

	//�~��
	_lap.lap1_1 = 0;
	_lap.lap1_10 = 0;
	//�b
	_lap.lap10_1 = 0;
	_lap.lap10_10 = 0;
	//��
	_lap.lap100_1 = 0;// *100;
	_lap.lap100_10 = 0;// *1000;

}

void UI::StartUIDraw()
{
	auto cnt = lpGameTask.GetRaceStart()._startCnt;
	auto efectCnt = lpGameTask.GetRaceStart()._efectCnt;
	SetDrawBlendMode(DX_BLENDMODE_ALPHA, efectCnt);
	DrawRotaGraph(SCREEN_SIZE_X / 2, SCREEN_SIZE_Y / 2 - SCREEN_SIZE_Y / 4, 1, 0, num[cnt], true);
	SetDrawBlendMode(DX_BLENDMODE_NOBLEND, 0);
}

void UI::ResultUIDraw()
{
	if (lpGameTask.GetRaceMode() == RACE_MODE::TIME_ATTACK)
	{
		OutPutTime o;
		if (_fastLap.empty())
		{
			return;
		}
		auto lap = _fastLap.end();
		--lap;
		o = GetOutPutTime(*lap);
		//�o��
		//�_�P��
		DrawRotaGraph(SCREEN_SIZE_X / 2 + _numberSize * 5 + 20, 190, 1.0f, 0, num[(int)(*lap).setCntm1], true);
		DrawRotaGraph(SCREEN_SIZE_X / 2 + _numberSize * 3 + 25, 190, 1.0f, 0, num[(int)(*lap).setCntm10], true);


		//�b
		DrawRotaGraph(SCREEN_SIZE_X / 2 + _numberSize, 190, 1.0f, 0, num[(int)(*lap).setCnts1], true);
		DrawRotaGraph(SCREEN_SIZE_X / 2 + _numberSize - 50, 190, 1.0f, 0, num[(int)(*lap).setCnts10], true);

		//��
		DrawRotaGraph(SCREEN_SIZE_X / 2 + _numberSize - 120, 190, 1.0f, 0, num[(int)(*lap).setCntM1], true);
		DrawRotaGraph(SCREEN_SIZE_X / 2 + _numberSize - 170, 190, 1.0f, 0, num[(int)(*lap).setCntM10], true);

		//:
		DrawRotaGraph(SCREEN_SIZE_X / 2 + _numberSize + 35, 190, 1.0f, 0, IMAGE_ID("data/images/Number/numberT.png"), true);
		DrawRotaGraph(SCREEN_SIZE_X / 2 + _numberSize - 86, 190, 1.0f, 0, IMAGE_ID("data/images/Number/numberT.png"), true);
	}
	else if (lpGameTask.GetRaceMode() == RACE_MODE::RACE)
	{
		DrawRotaGraph(SCREEN_SIZE_X / 2 - _numberSize, 220, 1.1f, 0.0f, num[position], true);
		if (position == 2)
		{
			DrawRotaGraph(SCREEN_SIZE_X / 2 + _numberSize + 20, 220, 0.6f, 0.0f, IMAGE_ID("data/images/nd.png"), true);
		}
		else
		{
			DrawRotaGraph(SCREEN_SIZE_X / 2 + _numberSize + 20, 220, 0.6f, 0.0f, IMAGE_ID("data/images/st.png"), true);
		}
	}
	//ResultRankingDraw();
}

void UI::ResultRankingDraw()
{
	for (int i = 0; i < _rankingO.size; ++i)
	{
		if (i > 5)
		{
			break;
		}
		//�_�P��
		DrawRotaGraph(SCREEN_SIZE_X / 2 + _numberSize * 5, 250 + (40 * i), 0.7f, 0, num[(int)_rankingO._ranking[i].setCntm1], true);
		DrawRotaGraph(SCREEN_SIZE_X / 2 + _numberSize * 4 - 10, 250 + (40 * i), 0.7f, 0, num[(int)_rankingO._ranking[i].setCntm10], true);


		//�b
		DrawRotaGraph(SCREEN_SIZE_X / 2 + _numberSize * 2 - 8, 250 + (40 * i), 0.7f, 0, num[(int)_rankingO._ranking[i].setCnts1], true);
		DrawRotaGraph(SCREEN_SIZE_X / 2 + _numberSize - 17, 250 + (40 * i), 0.7f, 0, num[(int)_rankingO._ranking[i].setCnts10], true);

		//��
		DrawRotaGraph(SCREEN_SIZE_X / 2 + _numberSize - 65, 250 + (40 * i), 0.7f, 0, num[(int)_rankingO._ranking[i].setCntM1], true);
		DrawRotaGraph(SCREEN_SIZE_X / 2 + _numberSize - 100, 250 + (40 * i), 0.7f, 0, num[(int)_rankingO._ranking[i].setCntM10], true);

		//:
		DrawRotaGraph(SCREEN_SIZE_X / 2 + _numberSize + 40, 250 + (40 * i), 0.7f, 0, IMAGE_ID("data/images/Number/numberT.png"), true);
		DrawRotaGraph(SCREEN_SIZE_X / 2 + _numberSize - 42, 250 + (40 * i), 0.7f, 0, IMAGE_ID("data/images/Number/numberT.png"), true);
	}
}

void UI::Upload()
{
	auto size = 0;

	//RankingUpload();

	if (_output._lapTimeValue > _getData._lapTimeValue)
	{
		return;
	}

	OutPutTime data;
	data = _output;

	FILE* file;
	fopen_s(&file, "data/CircuitData/RankingData.map", "wb+");
	auto Csize = sizeof(OutPutTime);
	int Not = 0;
	fwrite(&data.setCntm1, sizeof(float), 1, file);
	fwrite(&data.setCntm10, sizeof(float), 1, file);
	fwrite(&data.setCnts1, sizeof(float), 1, file);
	fwrite(&data.setCnts10, sizeof(float), 1, file);
	fwrite(&data.setCntM1, sizeof(float), 1, file);
	fwrite(&data.setCntM10, sizeof(float), 1, file);

	fwrite(&data._lapTimeValue, sizeof(float), 1, file);

	for (int j = 0; j < _getData._lapValue.size(); ++j)
	{
		float dataf;
		dataf = _getData._lapValue[j];
		fwrite(&dataf, sizeof(float), 1, file);
	}

	fclose(file);


}

void UI::RankingUpload()
{
	//for (int i = 0; i < _rankingO._ranking.size(); ++i)
	//{
	//	if (_rankingO._ranking[i]._lapTimeValue > _output._lapTimeValue)
	//	{
	//		int j = (_rankingO._ranking.size() - 1);
	//		for (j; j >= i; --j)
	//		{
	//			if (j - 1 < 0)
	//			{
	//				break;
	//			}

	//			_rankingO._ranking.emplace_back(_rankingO._ranking[j]);
	//			_rankingO._ranking[j] = _rankingO._ranking[j - 1];
	//		}

	//		_rankingO._ranking[i] = _output;
	//		break;
	//	}
	//}

	//int j = (_rankingO._ranking.size() - 1);
	//if (_rankingO._ranking[j]._lapTimeValue < _output._lapTimeValue)
	//{
		_rankingO._ranking.emplace_back(_output);
//	}

	_rankingO.size = _rankingO._ranking.size();

	FILE* file;
	fopen_s(&file, "data/CircuitData/RankingTime.map", "wb+");
	fwrite(&_rankingO.size, sizeof(int), 1, file);

	//fwrite(&_rankingO._ranking, sizeof(OutPutTime), 1, file);

	for (int j = 0; j < _rankingO.size; ++j)
	{
		fwrite(&_rankingO._ranking[j].setCntm1, sizeof(float), 1, file);
		fwrite(&_rankingO._ranking[j].setCntm10, sizeof(float), 1, file);
		fwrite(&_rankingO._ranking[j].setCnts1, sizeof(float), 1, file);
		fwrite(&_rankingO._ranking[j].setCnts10, sizeof(float), 1, file);
		fwrite(&_rankingO._ranking[j].setCntM1, sizeof(float), 1, file);
		fwrite(&_rankingO._ranking[j].setCntM10, sizeof(float), 1, file);

		fwrite(&_rankingO._ranking[j]._lapTimeValue, sizeof(float), 1, file);

		for (int i = 0; i < _rankingO._ranking[j]._lapValue.size(); ++i)
		{
			fwrite(&_rankingO._ranking[j]._lapValue[i], sizeof(float), 1, file);
		}

	}
	fclose(file);



}

const OutPutTime& UI::GetOutPutTime(OutPutTime in)
{
	OutPutTime o;

	//�~��
	o.setCntm1 = in.setCntm1;
	o.setCntm10 = in.setCntm10;
	//�b
	o.setCnts1 = in.setCnts1;
	o.setCnts10 = in.setCnts10;
	//��
	o.setCntM1 = in.setCntM1;// *100;
	o.setCntM10 = in.setCntM10;// *1000;

	float OsetCntm1 = o.setCntm1 * 0.01f;
	float OsetCntm10 = o.setCntm10 * 0.1f;
	float OsetCnts1 = o.setCnts1;
	float OsetCnts10 = o.setCnts10 * 10;
	float OsetCntM1 = o.setCntM1 * 100;
	float OsetCntM10 = o.setCntM10 * 1000;

	//���v
	o._lapTimeValue = OsetCntm1 + OsetCntm10 + OsetCnts1 + OsetCnts10 + OsetCntM1 + OsetCntM10;
	o._lapValue.emplace_back(o._lapTimeValue);

	return o;
}

