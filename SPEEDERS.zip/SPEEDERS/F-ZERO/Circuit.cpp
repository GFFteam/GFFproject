#include "Dxlib.h"
#include "Circuit.h"
#include "ResourceMng.h"
#include "Share.h"

constexpr float PI = 3.14159265;

float Dot(VECTOR2 vec1, VECTOR2 vec2)
{
	float s = 0.0;
	s = vec1.x * vec2.x - vec1.y * vec2.y;
	return s;
}

Circuit::Circuit()
{
	Init();
}


Circuit::~Circuit()
{
}

void Circuit::Init()
{
	fopen_s(&file, "data/CircuitData/data.map", "rb");

	if (!file)
	{
		return;
	}
	fread(&data.size, sizeof(int), 1, file);

	int dummy = 0;
	fread(&dummy, sizeof(int), 1, file);

	fread(&_startPos, sizeof(VECTOR2), 1, file);
	Share::GetInstance().SetStartPos(_startPos / cutCnt);

	data.receivePos.resize(data.size);

	for (int i = 0; i < data.receivePos.size(); ++i)
	{
		fread(&data.receivePos[i], sizeof(ReceiveCircuitPos), 1, file);

		data.receivePos[i]._leftPos = data.receivePos[i]._leftPos + Share::GetInstance().GetMapCenter();
		data.receivePos[i]._rightPos = data.receivePos[i]._rightPos + Share::GetInstance().GetMapCenter();
	}

	auto changeAngle = [&](VECTOR2 a, VECTOR2 b)
	{
		auto r = atan2(b.y - a.y, b.x - a.x);

		if (r < 0)
		{
			r = r + 2 * PI;
		}
		return floor(r * 360 / (2 * PI));
	};

	auto playerStart = (_startPos + Share::GetInstance().GetMapCenter()) / cutCnt;
	auto fa = VECTOR2(data.receivePos[0]._leftPos / cutCnt);
	auto fb = VECTOR2(data.receivePos[0]._rightPos / cutCnt);

	auto offset = VECTOR2(800 / cutCnt, 800 / cutCnt);
	auto block = VECTOR2(80 / cutCnt, 150 / cutCnt);
	auto circuitOfst = VECTOR2(100, 160);
	auto _start = VECTOR2((fa.x + fb.x) / 2, (fa.y + fb.y) / 2);

	auto pA = changeAngle(_start, playerStart);
	Share::GetInstance().SetAngle(pA*cutCnt);
	fclose(file);
}

void Circuit::Update()
{
	VECTOR2 vec1, vec2, vec3, vec4;
	VECTOR2 vecToPl1, vecToPl2, vecToPl3, vecToPl4;
	float Cross1, Cross2, Cross3, Cross4;

	auto playerPos = Share::GetInstance().GetPlayerPos();

	auto check = false;

	// data.receivePos.size()�̈�ԍŌ�̗v�f�͈�ԍŏ��̗v�f�Ɠ����Ȃ̂�-1����
	for (int i = 0; i < data.receivePos.size() - 1; ++i)
	{
		// �x�N�g�������
		vec1 = data.receivePos[i]._leftPos - data.receivePos[i]._rightPos;
		vec2 = data.receivePos[i + 1]._leftPos - data.receivePos[i]._leftPos;
		vec3 = data.receivePos[i + 1]._rightPos - data.receivePos[i + 1]._leftPos;
		vec4 = data.receivePos[i]._rightPos - data.receivePos[i + 1]._rightPos;

		// �e���_����v���C���[���W�ւ̃x�N�g�������߂�
		vecToPl1 = playerPos - data.receivePos[i]._rightPos;
		vecToPl2 = playerPos - data.receivePos[i]._leftPos;
		vecToPl3 = playerPos - data.receivePos[i + 1]._leftPos;
		vecToPl4 = playerPos - data.receivePos[i + 1]._rightPos;

		// �O�ς����߂�
		// vec1�~vecToPl1
		Cross1 = (vec1.x * vecToPl1.y) - (vec1.y * vecToPl1.x);

		// vec2�~vecToPl2
		Cross2 = (vec2.x * vecToPl2.y) - (vec2.y * vecToPl2.x);

		// vec3�~vecToPl3
		Cross3 = (vec3.x * vecToPl3.y) - (vec3.y * vecToPl3.x);

		// vec4�~vecToPl4
		Cross4 = (vec4.x * vecToPl4.y) - (vec4.y * vecToPl4.x);

		if (Cross1 > 0 && Cross2 > 0 && Cross3 > 0 && Cross4 > 0)
		{
			check = true;
		}

		auto offset = Share::GetInstance().GetMapOffset();

		if (playerPos.x > data.receivePos[i]._leftPos.x + offset.x && playerPos.x <= data.receivePos[i]._rightPos.x - offset.x)
		{
			check = true;
		}

		Share::GetInstance().SetHitCheck(check);
	}	

	PlayerVecSet();
	EnemyVecSet();
}

void Circuit::Draw()
{

}

void Circuit::PlayerVecSet()
{
	auto t1 = data.receivePos[0]._leftPos / cutCnt;
	auto t2 = data.receivePos[0]._rightPos / cutCnt;
	auto t3 = data.receivePos[1]._leftPos / cutCnt;

	auto s1 = data.receivePos[1]._leftPos / cutCnt;
	auto s2 = data.receivePos[1]._rightPos / cutCnt;
	auto s3 = data.receivePos[0]._leftPos / cutCnt;

	auto offset = Share::GetInstance().GetMapMove();
	auto block = VECTOR2(80 / cutCnt, 150 / cutCnt);
	auto circuitOfst = VECTOR2(100, 160);

	auto plPos = Share::GetInstance().GetMiniPos();
	bool check = false;
	auto vel = VECTOR2(0, 0);

	auto wall = VECTOR2(0, 0);



	auto color = 0xff0000;


	if (CourceCheck(plPos, _playerCheck))
	{
		check = true;

	}

	if (check)
	{
		color = 0xffff00;

		_playerCircuit._pos = plPos;

	}
	else
	{
		auto pVec = WallHit(plPos, _playerCircuit._pos, _playerCheck);

		if (!CheckSoundMem(SOUND_ID("data/sounds/se_maoudamashii_retro22.mp3")))
		{
			ChangeVolumeSoundMem(255 * 120 / 100, SOUND_ID("data/sounds/se_maoudamashii_retro22.mp3"));
			PlaySoundMem(SOUND_ID("data/sounds/se_maoudamashii_retro22.mp3"), DX_PLAYTYPE_BACK);
		}

		Share::GetInstance().SetReflect(pVec);
	}
	Share::GetInstance().SetHitCheck(check);

	auto sPos = _startPos / cutCnt;

	DrawCircle(plPos.x, plPos.y, 2, color, true);

	auto qa = VECTOR2(t1.x - offset.x - block.x - circuitOfst.x, t1.y - offset.y + block.y - circuitOfst.y);
	auto qd = VECTOR2(t2.x - offset.x - block.x - circuitOfst.x, t2.y - offset.y + block.y - circuitOfst.y);
	auto qc = VECTOR2(s2.x - offset.x - block.x - circuitOfst.x, s2.y - offset.y + block.y - circuitOfst.y);
	auto qb = VECTOR2(s1.x - offset.x - block.x - circuitOfst.x, s1.y - offset.y + block.y - circuitOfst.y);

	auto cq1 = VECTOR2((qa.x + qb.x) / 2, (qa.y + qb.y) / 2);
	auto cq2 = VECTOR2((qc.x + qd.x) / 2, (qc.y + qd.y) / 2);

	DrawLine(cq1.x, cq1.y, cq2.x, cq2.y, 0xffffff, 4);

	int Mx, My;

	GetMousePoint(&Mx, &My);

	bool lcheck = false;

	if (CollisionCheck(cq1, qb, qc, cq2, plPos))
	{
		lcheck = true;
		lrcheck = (!lrcheck ? true : false);
	}
	if (CollisionCheck(qa, qb, qc, qd, plPos))
	{
		if (!pointCheck)
		{
			pointCheck = true;
			auto cCut = VECTOR2((qb.x + qd.x) / 2, (qb.y + qd.y) / 2);

			auto cqCut = VECTOR2((cq1.x + cq2.x) / 2, (cq1.y + cq2.y) / 2);

			auto sVec = (cqCut - plPos).Normalize();

			if (sVec.y < 0)
			{
				if (!rFlag)
				{
					Share::GetInstance().SetLapCnt(++_lapCnt);
					ChangeVolumeSoundMem(255 * 120 / 100, SOUND_ID("data/sounds/button66.mp3"));
					PlaySoundMem(SOUND_ID("data/sounds/button66.mp3"), DX_PLAYTYPE_BACK);
				}
				rFlag = false;
			}
			else
			{
				rFlag = true;
			}
		}
	}
	else
	{
		pointCheck = false;
	}

	auto ePos = Share::GetInstance().GetEnemyPos();
	if (CollisionCheck(qa, qb, qc, qd, ePos))
	{
		if (!erFlag)
		{
			_eLapCnt++;
			erFlag = true;
		}
	}
	else
	{
		erFlag = false;
	}
	Share::GetInstance().SetEnemyLapCnt(_eLapCnt);

}

void Circuit::EnemyVecSet()
{
	auto p1 = data.receivePos[0]._leftPos / cutCnt;
	auto p2 = data.receivePos[1]._leftPos / cutCnt;
	auto p3 = data.receivePos[1]._rightPos / cutCnt;
	auto p4 = data.receivePos[0]._rightPos / cutCnt;

	auto offset = Share::GetInstance().GetMapMove();
	auto block = VECTOR2(80 / cutCnt, 150 / cutCnt);
	auto circuitOfst = VECTOR2(100, 160);

	auto ePos = Share::GetInstance().GetEnemyPos();
	auto plPos = Share::GetInstance().GetMiniPos();

	bool check = false;

	auto distanceCheck = [&](VECTOR2 p, VECTOR2 e, float& distance)
	{
		float diffuse1 = e.x - p.x;
		float diffuse2 = e.y - p.y;

		// �ύX
		VECTOR2 vec = { diffuse1,diffuse2 };
		Share::GetInstance().SetDistanceXY(vec);

		bool check = false;
		if (hypot(diffuse1, diffuse2) < 35)
		{
			check = true;
			distance = diffuse1 + diffuse2;
		}

		return check;
	};

	if (CourceCheck(ePos, _enemyCheck))
	{
		check = true;

		//�R�[�X�̐^��
		_enemy.normal = VECTOR2((_enemyCheck._outUp.x + _enemyCheck._inUp.x) / 2, (_enemyCheck._outUp.y + _enemyCheck._inUp.y) / 2);
		//��ɃR�[�X�����
		_enemy.week = VECTOR2((_enemy.normal.x + _enemyCheck._outUp.x) / 2, (_enemy.normal.y + _enemyCheck._outUp.y) / 2);
		//�C�����U�߂�
		_enemy.strong = VECTOR2((_enemy.normal.x + _enemyCheck._inUp.x) / 2, (_enemy.normal.y + _enemyCheck._inUp.y) / 2);

	}
	if (check)
	{
		auto random = GetRand(3);
		auto aiRandom = GetRand(2);
		if (_enemyAICheck != _enemy.normal)
		{
			if (random == 1)
			{
				if (Share::GetInstance().GetAICheck() == AI::NORMAL)
				{
					Share::GetInstance().SetAICheck(aiRandom == 0 ? AI::STRONG : AI::WEEK);
				}
				else if (Share::GetInstance().GetAICheck() != AI::NON)
				{
					Share::GetInstance().SetAICheck(AI::NORMAL);

				}
			}
		}

		_enemyCircuit._pos = ePos;

		AICheckSet(ePos, _enemyCheck, _enemy);
	}
	else
	{
		auto nVec = WallHit(ePos, _enemyCircuit._pos, _enemyCheck);
		Share::GetInstance().SetEReflect(nVec);

	}

	float distance = 0.0f;
	bool imageCheck = false;
	if (distanceCheck(plPos, ePos, distance))
	{
		imageCheck = true;
		Share::GetInstance().SetDistance(distance);
	}


	Share::GetInstance().SetEnemyImageCheck(imageCheck);
	Share::GetInstance().SetEnemyHitCheck(check);

	_enemyAICheck = _enemy.normal;
}

bool Circuit::CourceCheck(const VECTOR2 & pos, CourceC & cource)
{
	auto p1 = data.receivePos[0]._leftPos / cutCnt;
	auto p2 = data.receivePos[1]._leftPos / cutCnt;
	auto p3 = data.receivePos[1]._rightPos / cutCnt;
	auto p4 = data.receivePos[0]._rightPos / cutCnt;


	auto offset = Share::GetInstance().GetMapMove();
	auto block = VECTOR2(80 / cutCnt, 150 / cutCnt);
	auto circuitOfst = VECTOR2(100, 160);

	bool returnCheck = false;

	for (int i = 0; i < data.size; ++i)
	{
		if ((i + 1) >= data.size)
		{

		}
		else
		{
			p1 = data.receivePos[i]._leftPos / cutCnt;

			p2 = data.receivePos[i + 1]._leftPos / cutCnt;
			p3 = data.receivePos[i + 1]._rightPos / cutCnt;
			p4 = data.receivePos[i]._rightPos / cutCnt;

		}
		auto color = 0x00ff00;
		auto a = VECTOR2(p1.x - offset.x - block.x - circuitOfst.x, p1.y - offset.y + block.y - circuitOfst.y);
		auto b = VECTOR2(p2.x - offset.x - block.x - circuitOfst.x, p2.y - offset.y + block.y - circuitOfst.y);
		auto c = VECTOR2(p3.x - offset.x - block.x - circuitOfst.x, p3.y - offset.y + block.y - circuitOfst.y);
		auto d = VECTOR2(p4.x - offset.x - block.x - circuitOfst.x, p4.y - offset.y + block.y - circuitOfst.y);

		if (CollisionCheck(a, b, c, d, pos))
		{
			returnCheck = true;
			_enemyCircuit._circuitL = d;
			_enemyCircuit._circuitLNext = a;

			_enemyCircuit._left = VECTOR2(p1.x - offset.x - block.x - circuitOfst.x, p1.y - offset.y + block.y - circuitOfst.y);
			_enemyCircuit._left_next = VECTOR2(p2.x - offset.x - block.x - circuitOfst.x, p2.y - offset.y + block.y - circuitOfst.y);


			cource._outDown = VECTOR2(p1.x - offset.x - block.x - circuitOfst.x, p1.y - offset.y + block.y - circuitOfst.y);
			cource._outUp = VECTOR2(p2.x - offset.x - block.x - circuitOfst.x, p2.y - offset.y + block.y - circuitOfst.y);
			cource._inUp = VECTOR2(p3.x - offset.x - block.x - circuitOfst.x, p3.y - offset.y + block.y - circuitOfst.y);
			cource._inDown = VECTOR2(p4.x - offset.x - block.x - circuitOfst.x, p4.y - offset.y + block.y - circuitOfst.y);

		}

	}
	return returnCheck;
}

const VECTOR2& Circuit::WallHit(const VECTOR2& pos, const VECTOR2& oldPos, CourceC & cource)
{
	auto vec = (cource._outDown - cource._outUp).Normalize();
	VECTOR2 wallVec = { 0,0 };

	auto pVel = Share::GetInstance().GetVelocity().Normalize() * Share::GetInstance().GetSpeed();
	auto bVel = VECTOR2(0, 0);

	VECTOR2 normal = (pos - oldPos).Normalize();

	float diff = normal.Magnitude();

	normal.Normalize();

	auto callWallVec = [&](const VECTOR2& wall, const VECTOR2& front, VECTOR2& normal)
	{
		VECTOR2 wall_v;
		wall_v = wall.Normalize();

		normal = (front - Dot(front, wall_v) * wall_v);
	};

	auto cqCut = VECTOR2((cource._inDown.x + cource._outDown.x) / 2, (cource._inDown.y + cource._outDown.y) / 2);

	auto sVec = (cqCut - pos).Normalize();

	if (sVec.y < 0)
	{
		vec = (pos - cource._outDown).Normalize();
	}
	else
	{
		vec = (pos - cource._outUp).Normalize();
	}
	VECTOR2 n_V = { 0,0 };
	callWallVec(vec, normal, n_V);

	return n_V;
}

void Circuit::AICheckSet(VECTOR2& pos, const CourceC & cource, const EnemyAI & ai)
{
	auto getPoint = [&](float t, VECTOR2 v1, VECTOR2 v2, VECTOR2 v3)
	{
		float tp = 1 - t;
		VECTOR2 vec;
		vec.x = t * t * v3.x + 2 * t * tp * v2.x + tp * tp * v1.x;
		vec.y = t * t * v3.y + 2 * t * tp * v2.y + tp * tp * v1.y;
		return vec;
	};

	auto leftPoint = VECTOR2(cource._outUp.x, cource._outUp.y);
	auto rightPoint = VECTOR2(cource._inUp.x, cource._inUp.y);

	auto startPoint = VECTOR2((cource._inDown.x + cource._outDown.x) / 2, (cource._inDown.y + cource._outDown.y) / 2);

	auto p1 = cource._outDown - cource._outDown;
	auto p2 = cource._outUp - cource._outDown;

	auto value1 = p1.x + p2.x + p1.y + p2.y;

	auto p3 = cource._inUp - cource._inUp;
	auto p4 = cource._inDown - cource._inUp;

	auto value2 = p3.x + p4.x + p3.y + p4.y;

	auto nvP = (ai.normal - pos);
	auto nvS = (ai.normal - startPoint);

	float tP = nvP.Magnitude();
	float tS = nvS.Magnitude();

	float t = (tS - tP) / tS;

	auto enemyVec = (ai.normal - pos).Normalize();

	if (abs(value1) > abs(value2))
	{
		//����
		auto rPP = (cource._inDown - rightPoint);

		auto lp = (leftPoint + rPP);

		auto leftP = ai.week.Normalize() + ai.normal;

		//AI�̏�Ԃɂ���Ēʂ�o�H��ς���
		if (Share::GetInstance().GetAICheck() == AI::NORMAL)
		{
			auto leftvec = getPoint(t, startPoint, leftP, ai.normal);
			pos = leftvec;
			enemyVec = (ai.normal - pos).Normalize();
		}
		else if (Share::GetInstance().GetAICheck() == AI::WEEK)
		{
			leftP = ai.normal.Normalize() + ai.week;
			auto leftvec = getPoint(t, startPoint, leftP, ai.week);
			pos = leftvec;
			enemyVec = (ai.week - pos).Normalize();
		}
		else if (Share::GetInstance().GetAICheck() == AI::STRONG)
		{
			leftP = ai.normal.Normalize() + ai.strong;
			auto leftvec = getPoint(t, startPoint, leftP, ai.strong);
			pos = leftvec;
			enemyVec = (ai.strong - pos).Normalize();
		}
		else
		{
			enemyVec = (ai.normal - pos).Normalize();
		}
		Share::GetInstance().SetCurveCheck(Curve::Curve_Left);

	}
	else if (abs(value1) < abs(value2))
	{
		//�E��
		auto lPP = (cource._outDown - leftPoint);

		auto rp = (rightPoint + lPP);

		auto rightP = ai.strong.Normalize() + ai.normal;



		if (Share::GetInstance().GetAICheck() == AI::NORMAL)
		{
			auto rightvec = getPoint(t, startPoint, rightP, ai.normal);
			pos = rightvec;
			enemyVec = (ai.normal - pos).Normalize();
		}
		else if (Share::GetInstance().GetAICheck() == AI::WEEK)
		{
			rightP = ai.normal.Normalize() + ai.week;

			auto rightvec = getPoint(t, startPoint, rightP, ai.week);
			pos = rightvec;
			enemyVec = (ai.week - pos).Normalize();
		}
		else if (Share::GetInstance().GetAICheck() == AI::STRONG)
		{
			rightP = ai.normal.Normalize() + ai.strong;
			auto rightvec = getPoint(t, startPoint, rightP, ai.strong);
			pos = rightvec;
			enemyVec = (ai.strong - pos).Normalize();
		}
		else
		{
			enemyVec = (ai.normal - pos).Normalize();
		}

		Share::GetInstance().SetCurveCheck(Curve::Curve_Right);
	}
	else
	{
		Share::GetInstance().SetCurveCheck(Curve::Straight);
	}


	Share::GetInstance().SetEnemyVec(enemyVec);

}


bool Circuit::CollisionCheck(VECTOR2 p1, VECTOR2 p2, VECTOR2 p3, VECTOR2 p4, VECTOR2 player)
{
	//�O�ς�p���ċ��߂�
	auto leftCheck = CallCrossCheck(p1, p2, player);
	auto upCheck = CallCrossCheck(p2, p3, player);
	auto rightCheck = CallCrossCheck(p3, p4, player);
	auto downCheck = CallCrossCheck(p4, p1, player);

	return leftCheck > 0 && upCheck > 0 && rightCheck > 0 && downCheck > 0;
}

float Circuit::CallCrossCheck(VECTOR2 a, VECTOR2 b, VECTOR2 p)
{
	auto vecAB = a - b;
	auto vecAP = VECTOR2(a.x - p.x, a.y - p.y);

	return vecAB.x * vecAP.y - vecAP.x * vecAB.y;
}
