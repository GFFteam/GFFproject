#include "Enemy.h"
#include "Share.h"
#include "Circuit.h"
#include "ResourceMng.h"
#include "GameTask.h"
#include <cmath>
#include <DxLib.h>

constexpr int nonCnt = -100;

Enemy::Enemy()
{
}

Enemy::Enemy(VECTOR2 pos)
{
	en._pos = pos;
}


Enemy::~Enemy()
{
}

void Enemy::Init()
{
}

void Enemy::Update()
{
	if (!lpGameTask.GetRaceStart()._startFlag)
	{
		return;
	}


	auto vec = Share::GetInstance().GetEnemyVec();

	// �Ǔ����蔻�肱������ //
	if (en._hitFlag)
	{
		en._hitTime++;

		if (en._hitTime / 3 > 3)
		{
			en._hitTime = 0;
			en._hitFlag = false;
		}
	}
	else
	{
		en._hitNonTime++;

		if (en._hitNonTime / 6 > 6)
		{
			en._hitNonTime = 0;

		}
	}

	if (vec.x > nonCnt && vec.y > nonCnt)
	{

		if (Share::GetInstance().GetPosition() == 1)
		{
			en.speedCnt++;
			Share::GetInstance().SetAICheck(AI::NON);

			if (en.speedCnt % 30 == 0)
			{
				(en.speed < 1.42f ? en.speed += 0.01f : 0);
			}
		}
		else
		{
			(en.speed > 1.2f ? en.speed -= 0.01f : 0);
		}

		if (!Share::GetInstance().GetEnemyHitCheck())
		{
			en._hitFlag = true;
			(en.speed > 1.2f ? en.speed *= 0.95f : 0);

			if (Share::GetInstance().GetAICheck() != en._aiCheck)
			{
				en.speed = 0.3f;
			}

			auto ref = Share::GetInstance().GetEReflect();

			en._pos.x -= ref.x * en.speed;
			en._pos.y -= ref.y * en.speed;

			en._aiCheck = Share::GetInstance().GetAICheck();
		}
		else
		{
			(en.speed < 0.88f ? en.speed += 0.01f : 0);

			en._pos.x += vec.x * en.speed;
			en._pos.y += vec.y * en.speed;
		}

		Share::GetInstance().SetEnemyPos(en._pos.x, en._pos.y);

	}
	Share::GetInstance().SetEnemyPos(en._pos.x, en._pos.y);
}

void Enemy::Draw()
{
	if (lpGameTask.GetRaceMode() == RACE_MODE::RACE)
	{
		DrawCircle(en._pos.x, en._pos.y, 3, 0xff0000, true);
	}
}

void Enemy::MiniMapDraw()
{
	if (lpGameTask.GetRaceMode() == RACE_MODE::TIME_ATTACK)
	{
		return;
	}

	auto Clamp = [&](float value, float inDataMax, float inDataMin, float max, float min)
	{
		if (value < inDataMax && value > inDataMin)
		{
			auto clmp = ((value - inDataMin) / (inDataMax - inDataMin)) * (max - min) + min;
			return clmp;
		}
		return -2.0f;
	};

	auto rotAngle = Share::GetInstance().GetMapRotAngle();
	auto theta = rotAngle * (PI / 180);

	auto distanceVec = Share::GetInstance().GetDistanceXY();
	auto distanceVecNorm = distanceVec.Normalize();

	VECTOR2 rotDistanceVec = { distanceVec.x * cos(theta) - distanceVec.y * sin(theta) ,
								distanceVec.x * sin(theta) + distanceVec.y * cos(theta) };

	auto rotDistanceVecNorm = rotDistanceVec.Normalize();

	Share::GetInstance().SetRotDistanceVec(rotDistanceVecNorm);

	auto distance = hypot(distanceVec.x, distanceVec.y);

	if (rotDistanceVecNorm.y > 0)
	{
		distance = -distance;
	}

	// �N�����v(-1~1)
	auto clmpDist = Clamp(distance,25.0f,-25.0f,1.0f, -1.0f);

	auto screenPlayerPos = Share::GetInstance().GetScreenPlayerPos();

	if (clmpDist <= 1.0f && clmpDist >= -1.0f)
	{
		Share::GetInstance().SetAICheck(AI::NON);

		clmpDist = 1.0f - abs(clmpDist);

		auto size = 0.25f * clmpDist;
		auto backSize = 0.27f * clmpDist;

		if (distance < 0)
		{
			if (size < 0.24f)
			{
				size = 0.24f;
			}
		}

		float angle = 0.0f;
		if (rotDistanceVecNorm.x < 0.8f && rotDistanceVecNorm.x > -0.8f)
		{
			angle = 0.0f;
		}
		else
		{
			angle = (rotDistanceVecNorm.x * 10) * (PI / 180);
		}

		int cycle = 80;
		en.count++;
		auto removeLimitPosY = Share::GetInstance().GetBackGroundYPos();
		auto posX = screenPlayerPos.x + (rotDistanceVec.x * 12);
		auto posY = screenPlayerPos.y + (rotDistanceVec.y * 20) + sin(PI * 2 / cycle * en.count);
		VECTOR2 screenPos = { posX,posY };
		Share::GetInstance().SetScreenEnemyPos(screenPos);

		if (SCREEN_SIZE_Y / 2 <= posY)
		{	
			SetDrawBlendMode(DX_BLENDMODE_ALPHA, 150);
			DrawRotaGraph(posX, posY + 20, size, 0, IMAGE_ID("data/images/p_shadow01.png"), true);
			SetDrawBlendMode(DX_BLENDMODE_NOBLEND, 0);
			DrawRotaGraph(posX, posY, size, angle, IMAGE_ID("data/images/enemy01.png"), true);
		}
		else if (SCREEN_SIZE_Y / 2 > posY && removeLimitPosY < posY)
		{
			SetDrawBlendMode(DX_BLENDMODE_ALPHA, 150);
			DrawRotaGraph(posX, posY + 20, backSize, 0, IMAGE_ID("data/images/p_shadow01.png"), true);
			SetDrawBlendMode(DX_BLENDMODE_NOBLEND, 0);
			DrawRotaGraph(posX, posY, backSize, angle, IMAGE_ID("data/images/enemy01_back1.png"), true);
		}
		else
		{
			DrawRotaGraph(posX, removeLimitPosY, backSize, angle, IMAGE_ID("data/images/enemy01_back2.png"), true);
		}
	}
}

void Enemy::Key()
{
}
