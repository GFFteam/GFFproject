#pragma once
#include "Actor.h"
#include "GameTask.h"
#include "Share.h"

class Enemy :
	public Actor
{
public:
	Enemy();
	Enemy(VECTOR2 pos);

	~Enemy();
	void Init()override;
	void Update()override;
	void Draw()override;
	void MiniMapDraw()override;
	void Key()override;

private:

	// �G�l�~�[�Ɋւ���ϐ�
	struct enemy {
		bool _hitFlag = false;
		int _hitTime = 0;
		int _hitNonTime = 0;
		int speedCnt = 0;
		int count = 0;
		float speed = 1.2f;
		VECTOR2 _pos;
		AI _aiCheck;

	};

	enemy en;
};

