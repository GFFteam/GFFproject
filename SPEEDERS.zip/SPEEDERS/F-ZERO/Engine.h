#pragma once
#include "VECTOR2.h"
#include "GameTask.h"

enum class engine
{
	straight,
	left,
	right,
};

class Engine
{
public:
	Engine();
	Engine(VECTOR2 pos, engine e);

	~Engine();

	void Draw();
	void Update();

	void StraightUpdate();
	void SideUpdate();

	const bool& GetDeleteFlag()
	{
		return _deleteFlag;
	}

private:
	VECTOR2 _pos = { SCREEN_SIZE_X / 2,SCREEN_SIZE_Y / 2 + 90 };

	int _timeCnt = 0;
	float _sizeCnt = 0.0f;
	bool _deleteFlag = false;

	engine _engine;
	
};

