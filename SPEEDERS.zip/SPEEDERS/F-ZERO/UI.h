#pragma once
#include "VECTOR2.h"
#include "GameTask.h"


constexpr int SPEED_CIRCLE_SCALE = 13;
constexpr int LEFT_TACHO_CENTER_X = SCREEN_SIZE_X / 2 - 95;
constexpr int LEFT_TACHO_CENTER_Y = SCREEN_SIZE_Y - 60;
constexpr int RIGHT_L_TACHO_CENTER_X = SCREEN_SIZE_X / 2 + 82;
constexpr int RIGHT_L_TACHO_CENTER_Y = SCREEN_SIZE_Y - 70;
constexpr int RIGHT_S_TACHO_CENTER_X = SCREEN_SIZE_X / 2 + 160;
constexpr int RIGHT_S_TACHO_CENTER_Y = SCREEN_SIZE_Y - 20;

// �^�C���̊O���o�͗p
struct OutPutTime
{
	//�~��
	float setCntm1 = 0.0f;
	float setCntm10 = 0.0f;
	//�b
	float setCnts1 = 0.0f;
	float setCnts10 = 0.0f;
	//��
	float setCntM1 = 0.0f;
	float setCntM10 = 0.0f;
	float _lapTimeValue = 0.0f; //���v�l

	std::vector<float> _lapValue;//�^�C���i�[
};

class UI
{
public:
	UI();
	~UI();
	void Init();
	void RankingInit();
	void Update();
	void LapTimeUpdate();
	void Draw();
	void LapTimeDraw();
	void OutPutDraw();
	void HighScoreDraw();
	void SetLapValue();
	void StartUIDraw();
	void ResultUIDraw();
	void ResultRankingDraw();
	void Upload();
	void RankingUpload();
	const bool& GetSetValueFlag()
	{
		return _setValueFlag;
	}

private:
	const OutPutTime& GetOutPutTime(OutPutTime in);

	// �^�R���[�^�[���Ŏg�p������̕ϐ�
	struct Tachometer
	{
		int speedNum[5];
		int sp1, sp10, sp100;
		int lrFlag = 0;
		float speed;
		float circleSpeed = 0.0f;
		float throttlePct = 0.0f;
		float brakePct = 0.0f;
		float gBrake = 0.0f;
		float fuel;
		float gOffset = 0.7f;
		float gReturnCount = 0.0f;
		VECTOR2 gRand = { 0.0f,0.0f };
		VECTOR2 gSensor = { 0.0f ,0.0f };
		VECTOR2 gPos = { RIGHT_L_TACHO_CENTER_X ,RIGHT_L_TACHO_CENTER_Y };
	};

	// ���b�v�^�C���Ɋւ���ϐ�
	struct LapTime
	{
		int lap1_1, lap1_10;
		int lap10_1, lap10_10;
		int lap100_1, lap100_10;
		float lap1 = 0.0f;
		int _lapTime = 0;
		int _setLapCnt = 1;
	};

	// �����L���O�̊O���o�͗p
	struct OutPutRanking
	{
		int size;
		std::vector<OutPutTime> _ranking;
	};


	bool _setValueFlag = false;
	unsigned int _numberSize = 25;
	int num[10];		// 1����10�̐����摜�̔z��
	int position = 0;	// ����

	std::vector<OutPutTime> _fastLap;

	Tachometer tacho;
	OutPutTime _output;
	OutPutTime _getData;
	OutPutRanking _rankingO;
	LapTime _lap;
};

