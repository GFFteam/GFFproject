#include "MapControl.h"
#include "DxLib.h"
#include "GameTask.h"
#include "ResourceMng.h"
#include "KeyMng.h"
#include "Player.h"
#include "Enemy.h"
#include "UI.h"
#include "Circuit.h"
#include "Share.h"
#include "VECTOR2.h"
#include <string>

constexpr unsigned int startDivY = 35;
constexpr unsigned int startBack = 108;
constexpr unsigned int changeDiv = 80;
constexpr unsigned int changeBack = -33;


MapControl::MapControl()
{
	Init();
}


MapControl::~MapControl()
{
}

void MapControl::Init()
{
	GetScreenState(&map.sw, &map.sh, &map.dep);
	mapId.push_back(IMAGE_ID("data/images/underMap.png"));
	mapId.push_back(IMAGE_ID("data/CircuitData/screen00.png"));
	mapId.push_back(IMAGE_ID("data/CircuitData/screen02.png"));
	GetGraphSize(mapId[1], &map.gwCir, &map.ghCir);
	GetGraphSize(mapId[0], &map.gwUnder, &map.ghUnder);
	map.screen1 = MakeScreen(map.gwUnder, map.ghUnder);
	map.screen2 = MakeScreen(map.gwUnder, map.ghUnder);

	pers.x = map.gwUnder / 2;
	pers.z = map.ghUnder / 2;
	Share::GetInstance().SetMapCenter(pers.x, pers.z);
	map.theta = 0;
	pers.angle = 0.0f;

	if (cir.empty())
	{
		cir.push_back(std::make_shared<Circuit>());
	}
	if (pl.empty())
	{
		pl.push_back(std::make_shared<Player>());
		auto a = Share::GetInstance().GetStartPos().x;
		auto b = Share::GetInstance().GetStartPos().y;
		pl.push_back(std::make_shared<Enemy>(Share::GetInstance().GetStartPos()));
	}
	if (ui.empty())
	{
		ui.push_back(std::make_shared<UI>());
	}

	auto startPos = Share::GetInstance().GetStartPos();
	auto offset = VECTOR2(map.gwCir / cutCnt, map.ghCir / cutCnt);
	auto block = VECTOR2(80 / cutCnt, 150 / cutCnt);
	auto circuitOfst = VECTOR2(70, 160);

	map.ax = startPos.x - offset.x - block.x - circuitOfst.x;
	map.az = startPos.y - offset.y + block.y - circuitOfst.y;
	pers.angle = Share::GetInstance().GetAngle();

}

void MapControl::Update()
{
	pers.speed = Share::GetInstance().GetSpeed();
	Share::GetInstance().SetMapOffset(VECTOR2(map.ax, map.az + ROT_OFFSET));
	gm.shadowOffsetLR = (Share::GetInstance().GetPlayerRollAngle() * 10);

}

void MapControl::Draw()
{
	DrawBox(0, 0, map.sw, map.sh, GetColor(0,0,0), true);
}

float Dot(const VECTOR2& va, const VECTOR2& vb)
{
	return va.x*vb.x + va.y*vb.y;
}

void MapControl::Key()
{
	gm._pushButtom = false;
	auto reflectVec = [&](VECTOR2 n, VECTOR2& normal)
	{
		return n - normal * 2 * Dot(n, normal);
	};

	if (KeyMng::GetInstance().newKey[P1_LEFT])
	{
		if (gm.pushCnt % 6 == 0)
		{
			SideEnginePush(VECTOR2(SCREEN_SIZE_X / 2 + 30, SCREEN_SIZE_Y / 2 + 90), engine::left);
		}
		pers.angle += 1.5f;
	}
	if (KeyMng::GetInstance().newKey[P1_RIGHT])
	{
		if (gm.pushCnt % 6 == 0)
		{
			SideEnginePush(VECTOR2(SCREEN_SIZE_X / 2 - 30, SCREEN_SIZE_Y / 2 + 90), engine::right);
		}
		pers.angle -= 1.5f;
	}

	Share::GetInstance().SetMapRotAngle(pers.angle);

	//�J�����̎��_�؂�ւ�
	if (KeyMng::GetInstance().newKey[P1_Z])
	{
		gm._div = changeDiv;
		gm._backY = changeBack;
		Share::GetInstance().SetChangeFlag(true);
	}
	else
	{
		gm._div = startDivY;
		gm._backY = startBack;
		Share::GetInstance().SetChangeFlag(false);
	}

	gm.pushCnt++;
	auto speedF = Share::GetInstance().GetSpeed();

	if (KeyMng::GetInstance().newKey[P1_UP])
	{
		auto theta = pers.angle * (PI / 180);
		gm._pushButtom = true;

		if (gm.pushCnt % 6 == 0)
		{
			EnginePush(VECTOR2(SCREEN_SIZE_X / 2, SCREEN_SIZE_Y / 2 + 90), engine::straight);
		}

		if (gm.pushCnt % 10 == 0 && lpGameTask.GetRaceStart()._startFlag)
		{
			(gm.push < 0.5f ? gm.push = speedF * 0.1f : gm.push);
		}
	}
	else
	{
		if (gm.pushCnt % 10 == 0 && lpGameTask.GetRaceStart()._startFlag)
		{
			(gm.push > 0.0f ? gm.push = speedF * 0.1f : gm.push);
		}
	}


	if (Share::GetInstance().GetHitCheck())
	{
		map.ax -= sin(map.theta) * pers.speed;
		map.az -= cos(map.theta) * pers.speed;

	}
	else
	{
		auto ref = Share::GetInstance().GetReflect();

		map.ax -= ref.x * pers.speed;
		map.az -= ref.y * pers.speed;

	}
	gm._pPos = Share::GetInstance().GetPlayerPos();
}

void MapControl::ResultDraw()
{
	for (auto& _ui : ui)
	{
		(*_ui).ResultUIDraw();
	}
}

void MapControl::ResultUpload()
{
	auto _ui = ui.begin();
	(*_ui)->Upload();
}

void MapControl::EnginePush(VECTOR2 p, engine e)
{
	_engine.emplace_back(std::make_shared<Engine>(p, e));
}

void MapControl::SideEnginePush(VECTOR2 p, engine e)
{
	_sideEngine.emplace_back(std::make_shared<Engine>(p, e));
}

void MapControl::OtherControl()
{
	for (auto i : pl)
	{
		(*i).Key();
		(*i).Update();
		(*i).Draw();
		(*i).MiniMapDraw();
	}

	for (auto i : ui)
	{
		(*i).Update();
		(*i).Draw();
	}

	for (auto i : cir)
	{
		(*i).Update();
		(*i).Draw();
	}


	for (auto& e : _engine)
	{
		e->Update();
		e->Draw();
	}
	for (auto& e : _sideEngine)
	{
		e->Update();
		e->Draw();
	}

	for (int i = 0; i < _engine.size(); ++i)
	{
		if (_engine[i]->GetDeleteFlag())
		{
			_engine.erase(_engine.begin());
		}
	}

	for (int i = 0; i < _sideEngine.size(); ++i)
	{
		if (_sideEngine[i]->GetDeleteFlag())
		{
			_sideEngine.erase(_sideEngine.begin());
		}
	}
}

void MapControl::Perspective()
{
	float y = gm._backY;
	Share::GetInstance().SetBackGroundYpos(y);
	float h = 1;
	int sy = 0;
	int alpha = 150;					// �}�b�v�̃A���t�@�l
	int shadowY = startDivY - gm._div;		//�e�̈ʒu�␳


	gm.hitReactionMove = Share::GetInstance().GetHitReactionMove();
	// �ُ�Ȓl�������Ă��Ȃ����H
	if (gm.hitReactionMove.x > 100 || gm.hitReactionMove.x < -100)
	{
		gm.hitReactionMove = VECTOR2(0.0f, 0.0f);
	}

	gm.shadowOffsetLR += gm.hitReactionMove.x;
	shadowY += gm.hitReactionMove.y;
	
	map.theta = pers.angle * (PI / 180);

	SetDrawScreen(map.screen1);
	// �u�e�̒��S�v�𒆐S�ɉ�]
	DrawRotaGraph2(pers.x, pers.z + ROT_OFFSET - (MAP_MINIMIZE_Y - 300), pers.x + map.ax, pers.z + ROT_OFFSET + map.az,
		2.0f, map.theta, mapId[0], false);
	DrawRotaGraph2(pers.x, pers.z + ROT_OFFSET - (MAP_MINIMIZE_Y - 300), map.ax + (map.gwCir / 2), map.az + (map.gwCir / 2) + ROT_OFFSET,
		2.0f, map.theta, mapId[1], true);
	DrawRotaGraph2(pers.x, pers.z + ROT_OFFSET - (MAP_MINIMIZE_Y - 300), map.ax + (map.gwCir / 2), map.az + (map.gwCir / 2) + ROT_OFFSET,
		2.0f, map.theta, mapId[2], true);

	// screen2�ŉ�]��摜(screen1)��Y���̂ݏk��
	SetDrawScreen(map.screen2);
	DrawExtendGraph(0, MAP_MINIMIZE_Y, map.gwUnder, map.ghUnder, map.screen1, true);

	gm._playerPos.x = pers.x + map.ax;
	gm._playerPos.y = pers.z + map.az;
	Share::GetInstance().SetPlayerPos(gm._playerPos.x, gm._playerPos.y);
	DrawCircle(pers.x, 0, 20, 0x0000ff, true);

	SetDrawScreen(DX_SCREEN_BACK);

	while (y < map.sh)
	{
		float rate = ((gm._div - static_cast<float>(h)) / gm._div) * 1.0f;
		auto perspectiveX = map.sw / 2;
		auto perspectiveZ = sy;
		perspectiveX *= rate;
		// �����ɂ���ĈÂ�����
		SetDrawBlendMode(DX_BLENDMODE_ALPHA, alpha);
		// �摜�𕪊��A�k��
		DrawRectExtendGraph(0, y, map.sw, y + h, pers.x - perspectiveX, pers.z + perspectiveZ , map.sw * rate, 10, map.screen2, true);
		SetDrawBlendMode(DX_BLENDMODE_NOBLEND, alpha);
		alpha += 10;
		y += h;

		if (h < 20)
		{
			h++;
		}
		else
		{
			h += 0.5f + gm.push;
		}

		sy += 10;
	}

	// �����Ƀv���C���[��UI���̕`��
	int BaseGw, BaseGh;
	GetGraphSize(IMAGE_ID("data/images/cockpitBase.png"), &BaseGw, &BaseGh);

	SetDrawBlendMode(DX_BLENDMODE_ALPHA, 150);
	DrawRotaGraph(SCREEN_SIZE_X / 2 - gm.shadowOffsetLR, SCREEN_SIZE_Y / 2 + 100, 0.23f, 0, IMAGE_ID("data/images/p_shadow01.png"), true);
	SetDrawBlendMode(DX_BLENDMODE_NOBLEND, 0);

	// DB�p
	//DrawRotaGraph(0.1f * (gw1 / 2), 0.1f * (gh1 / 2), 0.1f, 0.0, screen2, true);
	// �������ϯ��
	DrawExtendGraph(0, 0, map.gwCir / cutCnt, map.ghCir / cutCnt, mapId[1], true);

	Share::GetInstance().SetMapMove((map.gwCir / cutCnt),(map.ghCir / cutCnt));

	OtherControl();

	auto uiM = ui.begin();
	if ((Share::GetInstance().GetLapCnt() > 5 && (*uiM)->GetSetValueFlag()) || KeyMng::GetInstance().trgKey[P1_ENTER])
	{
		auto SaveGameResult = SaveDrawScreenToPNG(0, 0, SCREEN_SIZE_X, SCREEN_SIZE_Y, "data/images/Result/result.png");

		GameTask::GetInstance().SetResultHandle(SaveGameResult);
		gm._clearCheck = true;
	}

	ScreenFlip();
	ClearDrawScreen();
}
