#pragma once

constexpr int SEP_NUM = 20;

class BgControl
{
public:
	BgControl();
	~BgControl();

	void Update();
	void Draw();

private:
	int gw, gh;
	float sclX = 0.0f;
};

