#include "Engine.h"
#include "DxLib.h"
#include "ResourceMng.h"


Engine::Engine()
{
}

Engine::Engine(VECTOR2 pos, engine e): _pos(pos), _engine(e)
{
}


Engine::~Engine()
{
}

void Engine::Draw()
{
	SetDrawBlendMode(DX_BLENDMODE_ALPHA, _timeCnt * 4);

	DrawRotaGraph(_pos.x, _pos.y + _timeCnt, _sizeCnt, 0.0, IMAGE_ID("data/images/Engine/engine.png"), true);

	SetDrawBlendMode(DX_BLENDMODE_NOBLEND, 0);

}

void Engine::Update()
{
	_timeCnt++;

	if (_engine == engine::straight)
	{
		StraightUpdate();
	}
	else
	{
		SideUpdate();
	}
}

void Engine::StraightUpdate()
{
	(_sizeCnt < 1.0f ? _sizeCnt += 0.02f : 0);

	if (_sizeCnt >= 1.0f)
	{
		_deleteFlag = true;
	}
}

void Engine::SideUpdate()
{
	(_sizeCnt < 0.6f ? _sizeCnt += 0.02f : 0);

	if (_sizeCnt >= 0.6f)
	{
		_deleteFlag = true;
	}
}
