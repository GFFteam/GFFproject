#pragma once
#include "DxLib.h"
#include "Actor.h"
#include "VECTOR2.h"
#include "GameTask.h"
class Player :
	public Actor
{
public:
	Player();
	~Player();
	void Init();
	void Update();
	void Draw();
	void PositionDraw();
	void Key();

	bool IsHitEnemy();
	VECTOR2 HitReaction();

private:

	struct player {
		float angle = 0.0f;
		float theta = 0.0f;
		float size = 0.25f;
		float speed = 0.0f;
		VECTOR2 pos = { SCREEN_SIZE_X / 2,SCREEN_SIZE_Y / 2 + 70 };
		const VECTOR2 initialPos = { pos.x,pos.y };
		VECTOR2 hitReactionVec = { 0.0f,0.0f };
		VECTOR2 hitReactionMove = { 0.0f,0.0f };
		float fuel = 100.0f;
		int cycle = 100;
		int swing = 3;
		int lrFlag = 0;		// -1:�� 0:�����l 1:�E
		float throttleParcent = 0.0f;
		float brakeParcent = 0.0f;
		float yawPercent = 0.0f;
	};
	player pl;

	struct control {
		float accel = 0.0f;
		float brake = 0.0f;
		float rotate = 0.0f;
	};

	control ctl;
	XINPUT_STATE input;

	struct playerBox
	{
		float L, R, U, D;
	};
	struct enemyBox
	{
		float L, R, U, D;
	};

	playerBox pBox;
	enemyBox eBox;

	int base;
	int gw, gh;
	int count = 0;
	VECTOR2 vel = { 0,0 };
	VECTOR2 velOld = { 0,0 };

	VECTOR2 enemyPos = { 0.0f,0.0f };

	VECTOR2 back_vec = { 0.0f,0.0f };
	VECTOR2 back_vecNorm = { 0.0f,0.0f };
};

