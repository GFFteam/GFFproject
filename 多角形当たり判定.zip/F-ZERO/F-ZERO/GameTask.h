#pragma once
#include <memory>
#include <vector>
#include "VECTOR2.h"

#define lpGameTask GameTask::GetInstance();
constexpr int SCREEN_SIZE_X = 960;
constexpr int SCREEN_SIZE_Y = 540;
constexpr float PI = 3.14159265;

enum GAME_MODE {
	G_INIT,
	G_TITLE,
	G_MENU,
	G_MAIN,
	G_RESULT,
	G_MAX
};

struct pos
{
	VECTOR2 point;
};

struct Data
{
	std::vector<pos>v;
};

class GameTask
{
public:
	GameTask();
	~GameTask();
	static void Create();
	static GameTask& GetInstance()
	{
		Create();
		return *s_Instance;
	}
	int SystemInit();
	void Init();
	void Update();

private:
	static GameTask* s_Instance;
	int mx, my;
	VECTOR2 m;
	Data dt;
	int count = 0;
};

