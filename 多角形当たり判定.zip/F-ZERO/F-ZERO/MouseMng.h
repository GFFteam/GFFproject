#pragma once

enum MOUSE_CODE {
	P1_PUSH = 0,
	P1_HOLD,
	P1_POP,
	P1_NON,

	MOUSE_MAX
};

class MouseMng
{
	MouseMng() {

		Init();
	}
	MouseMng(const MouseMng&) {}
	MouseMng& operator=(const MouseMng& k) {}
	~MouseMng() {}

public:
	static MouseMng& GetInstance() {
		static MouseMng keyInst;
		return keyInst;
	}
	void Init(void);
	bool Update();	//�L�[���X�V

	int newKey[MOUSE_MAX] = { 0 };
	int trgKey[MOUSE_MAX] = { 0 };
	int oldKey[MOUSE_MAX] = { 0 };
};

