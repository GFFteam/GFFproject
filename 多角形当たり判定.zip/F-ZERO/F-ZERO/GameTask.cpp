#include <future>
#include "GameTask.h"
#include "DxLib.h"
#include "VECTOR2.h"
#include "MouseMng.h"
#include "KeyMng.h"

GameTask* GameTask::s_Instance = nullptr;

GameTask::GameTask()
{
}

GameTask::~GameTask()
{
}

void GameTask::Create()
{
	if (!s_Instance)
	{
		s_Instance = new GameTask();
	}
}

int GameTask::SystemInit()
{
	SetWindowText("F-ZERO");
	SetGraphMode(SCREEN_SIZE_X, SCREEN_SIZE_Y, 16);
	ChangeWindowMode(true);
	if (DxLib_Init() == -1) {
		return -1;
	}
	SetDrawScreen(DX_SCREEN_BACK);
	return 0;
}

void GameTask::Init()
{
}

void GameTask::Update()
{
	//KeyMng::GetInstance().Update();
	MouseMng::GetInstance().Update();

	DrawBox(0, 0, SCREEN_SIZE_X, SCREEN_SIZE_Y, 0xffffff, true);
	GetMousePoint(&mx, &my);
	m.x = mx;
	m.y = my;
	DrawCircle(m.x, m.y, 3, 0xff0000, true);
	if (MouseMng::GetInstance().trgKey[P1_PUSH])
	{
		count++;
		dt.v.resize(count);
		dt.v[count - 1].point.x = m.x;
		dt.v[count - 1].point.y = m.y;
	}

	if(dt.v.size() != 0)
	{
		for (int i = 0; i < count; i++)
		{
			DrawCircle(dt.v[i].point.x, dt.v[i].point.y, 5, 0x0000ff, true);
		}

		DrawLine(dt.v[count - 1].point.x, dt.v[count - 1].point.y, m.x, m.y, 0x00ff00, 2);
		for (int i = 0; i < count; i++)
		{
			if (i >= 2)
			{
				DrawLine(dt.v[i].point.x, dt.v[i].point.y, dt.v[i - 1].point.x, dt.v[i - 1].point.y, 0x00ff00, 2);
			}
		}
	}
}
