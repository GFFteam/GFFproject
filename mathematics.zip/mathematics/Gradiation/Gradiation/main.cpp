#include<DxLib.h>
#include"Rock.h"
#include"World.h"

int WINAPI WinMain(HINSTANCE,HINSTANCE,LPSTR,int){
	DxLib::SetWindowSize(World::GetWidth() , World::GetHeight());
	DxLib::ChangeWindowMode(true);
	
	if(DxLib::DxLib_Init()){
		return -1;
	}
	DxLib::SetDrawScreen(DX_SCREEN_BACK);
	DxLib::SetWindowText("1701331_�D���x");
	int bgH = LoadGraph("img/background.png");

	Rock rock("img/rock.png",1,1);
	rock.SetPosition(World::GetWidth()/2,World::GetGroundLineY());
	rock.AddAnimInfo(0,0);
	
	World w(rock);
	
	while(DxLib::ProcessMessage()==0){
		DxLib::ClearDrawScreen();
		DrawGraph(0,0,bgH,false);
		rock.Update();
		w.Update();
		w.Draw();
		DxLib::ScreenFlip();
	}
	return 0;
}