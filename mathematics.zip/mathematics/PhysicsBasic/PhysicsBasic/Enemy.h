#pragma once

#include"Character.h"

class Player;
class Enemy : public Character
{
private:
	Vector2 _vel;
	Position _initpos;
	Player& _player;
public:
	Enemy(Player& player,Position pos,Vector2 vel);
	~Enemy();
	void Update();
};

