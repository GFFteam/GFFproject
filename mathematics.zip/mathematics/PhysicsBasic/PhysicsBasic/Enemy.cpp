#include "Enemy.h"
#include<DxLib.h>
#include"Player.h"


int a;
int b;
int c;
int DF;
 
Enemy::Enemy(Player& player, Position pos, Vector2 vel) : Character("img/eyeball_REN.png"), _player(player)
{
	/*_pos = pos;
	_initpos = pos;
	_vel = vel;
	if (vel.x != 0){
		_pos.y = _player.GetPosition().y;
	}*/
	a = LoadGraph("img/eyeball_REN.png");
	b = 0;
}

Enemy::~Enemy()
{
}

void 
Enemy::Update(){

	_pos.x += _vel.x;
	_pos.y += _vel.y;
	Draw();
	if (_pos.x < -48&&_vel.x<0){
		_pos = _initpos;
	}
	if (_pos.x > 640&&_vel.x>0){
		_pos = _initpos;
	}
	if (_pos.y < -32&&_vel.y<0){
		_pos = _initpos; 
		if (_vel.y != 0){
			_pos.x = _player.GetPosition().x;
		}
	}
	if (_pos.y > 480 && _vel.y>0){
		_pos = _initpos;
		if (_vel.y != 0){
			_pos.x = _player.GetPosition().x;
		}
	}
	b += 2;
	c = 640 - b;
	DrawGraph(c, 0, a, true);

	if (c < _pos.x + 32 && c + 32 > _pos.x && 0 < _pos.x + 32 && 0 + 320 > 0)
	{
		DF = 1;
	}
}
