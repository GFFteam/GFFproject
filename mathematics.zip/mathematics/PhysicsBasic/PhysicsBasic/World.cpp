#include "World.h"
#include<DxLib.h>

World::World(void)
{
}


World::~World(void)
{
}
