#include<DxLib.h>
#include<math.h>
#include<vector>
#include"Player.h"
#include"Enemy.h"
#include"resource.h"


using namespace std;
int WINAPI WinMain(HINSTANCE,HINSTANCE,LPSTR,int){
	DxLib::SetWindowText("1701331_�D���x");
	DxLib::ChangeWindowMode(true);
	
	if(DxLib::DxLib_Init()){
		return -1;
	}
	DxLib::SetDrawScreen(DX_SCREEN_BACK);
	int w, h, b;
	DxLib::GetScreenState(&w, &h, &b);
	DxLib::SetWindowIconID(IDI_ICON1);
	int bgH = LoadGraph("img/background.png");
	Player player("img/character.png",3,1);
	player.AddAnimInfo(0,5,1);
	player.AddAnimInfo(1,5,2);
	player.AddAnimInfo(2,5,3);
	player.AddAnimInfo(1,5,0);
	player.SetPosition(50,428);

	
	vector<Enemy> enemies;
	//���̃v���O������Vector2(-4,0)��-4�̕�����ύX����ƃX�s�[�h���ς���H
	enemies.push_back(Enemy(player,Position(640, 428), Vector2(-4, 0)));
	enemies.push_back(Enemy(player,Position(0, 0), Vector2(0, 8)));

	for (auto& enemy : enemies){
		enemy.AddAnimInfo(0, 0);
	}
	
	while(DxLib::ProcessMessage()==0){
		DxLib::ClearDrawScreen();
		DrawGraph(0,0,bgH,false);
		
		for (auto& enemy : enemies){
			enemy.Update();
			if (player.IsAvailable()){
				if ((enemy.GetPosition() - player.GetPosition()).Length() < 48){
					player.OnDamage();
					break;
				}
			}
		}
		player.Update();
		DxLib::ScreenFlip();
	}
	return 0;
}