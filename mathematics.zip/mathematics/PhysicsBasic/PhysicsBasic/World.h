#pragma once
class World
{
public:
	World(void);
	~World(void);
};

