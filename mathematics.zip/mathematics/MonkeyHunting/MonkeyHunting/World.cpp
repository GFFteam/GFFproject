#include "World.h"
#include<DxLib.h>

World::World(void)
{
	_bgH = LoadGraph("img/background.png");
}


World::~World(void)
{
}


void 
World::Update() {
	DxLib::DrawGraph(0, 0, _bgH, false);
}