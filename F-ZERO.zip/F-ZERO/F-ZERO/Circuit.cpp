#include "Dxlib.h"
#include "Circuit.h"
#include "ResourceMng.h"
#include "Share.h"

constexpr float PI = 3.14159265;

float Dot(VECTOR2 vec1, VECTOR2 vec2)
{
	float s = 0.0;
	s = vec1.x * vec2.x - vec1.y * vec2.y;
	return s;
}

Circuit::Circuit()
{
	Init();
}


Circuit::~Circuit()
{
}

void Circuit::Init()
{
	fopen_s(&file, "data/CircuitData/data.map", "rb");

	if (!file)
	{
		return;
	}
	fread(&data.size, sizeof(int), 1, file);

	int dummy = 0;
	fread(&dummy, sizeof(int), 1, file);

	fread(&_startPos, sizeof(VECTOR2), 1, file);
	Share::GetInstance().SetStartPos(_startPos / cutCnt);

	data.receivePos.resize(data.size);

	for (int i = 0; i < data.receivePos.size(); ++i)
	{
		fread(&data.receivePos[i], sizeof(ReceiveCircuitPos), 1, file);

		data.receivePos[i]._leftPos = data.receivePos[i]._leftPos + Share::GetInstance().GetMapCenter();
		data.receivePos[i]._rightPos = data.receivePos[i]._rightPos + Share::GetInstance().GetMapCenter();
	}

	auto changeAngle = [&](VECTOR2 a, VECTOR2 b)
	{
		auto r = atan2(b.y - a.y, b.x - a.x);

		if (r < 0)
		{
			r = r + 2 * PI;
		}
		return floor(r * 360 / (2 * PI));
	};

	auto playerStart = (_startPos + Share::GetInstance().GetMapCenter()) / cutCnt;
	auto fa = VECTOR2(data.receivePos[0]._leftPos / cutCnt);
	auto fb = VECTOR2(data.receivePos[0]._rightPos / cutCnt);

	auto offset = VECTOR2(800 / cutCnt, 800 / cutCnt);
	auto block = VECTOR2(80 / cutCnt, 150 / cutCnt);
	auto circuitOfst = VECTOR2(100, 160);
	auto _start = VECTOR2((fa.x + fb.x) / 2, (fa.y + fb.y) / 2);

	auto pA = changeAngle(_start, playerStart);
	Share::GetInstance().SetAngle(pA*cutCnt);
	fclose(file);
}

void Circuit::Update()
{
	VECTOR2 vec1, vec2, vec3, vec4;
	VECTOR2 vecToPl1, vecToPl2, vecToPl3, vecToPl4;
	float Cross1, Cross2, Cross3, Cross4;

	auto playerPos = Share::GetInstance().GetPlayerPos();

	auto check = false;

	// data.receivePos.size()�̈�ԍŌ�̗v�f�͈�ԍŏ��̗v�f�Ɠ����Ȃ̂�-1����
	for (int i = 0; i < data.receivePos.size() - 1; ++i)
	{
		// �x�N�g�������
		vec1 = data.receivePos[i]._leftPos - data.receivePos[i]._rightPos;
		vec2 = data.receivePos[i + 1]._leftPos - data.receivePos[i]._leftPos;
		vec3 = data.receivePos[i + 1]._rightPos - data.receivePos[i + 1]._leftPos;
		vec4 = data.receivePos[i]._rightPos - data.receivePos[i + 1]._rightPos;

		// �e���_����v���C���[���W�ւ̃x�N�g�������߂�
		vecToPl1 = playerPos - data.receivePos[i]._rightPos;
		vecToPl2 = playerPos - data.receivePos[i]._leftPos;
		vecToPl3 = playerPos - data.receivePos[i + 1]._leftPos;
		vecToPl4 = playerPos - data.receivePos[i + 1]._rightPos;

		// �O�ς����߂�
		// vec1�~vecToPl1
		Cross1 = (vec1.x * vecToPl1.y) - (vec1.y * vecToPl1.x);

		// vec2�~vecToPl2
		Cross2 = (vec2.x * vecToPl2.y) - (vec2.y * vecToPl2.x);

		// vec3�~vecToPl3
		Cross3 = (vec3.x * vecToPl3.y) - (vec3.y * vecToPl3.x);

		// vec4�~vecToPl4
		Cross4 = (vec4.x * vecToPl4.y) - (vec4.y * vecToPl4.x);

		if (Cross1 > 0 && Cross2 > 0 && Cross3 > 0 && Cross4 > 0)
		{
			check = true;
		}

		auto offset = Share::GetInstance().GetMapOffset();

		if (playerPos.x > data.receivePos[i]._leftPos.x + offset.x && playerPos.x <= data.receivePos[i]._rightPos.x - offset.x)
		{
			check = true;
		}

		Share::GetInstance().SetHitCheck(check);
	}	

	EnemyVecSet();
}

void Circuit::Draw()
{
	auto t1 = data.receivePos[0]._leftPos / cutCnt;
	auto t2 = data.receivePos[0]._rightPos / cutCnt;
	auto t3 = data.receivePos[1]._leftPos / cutCnt;

	auto s1 = data.receivePos[1]._leftPos / cutCnt;
	auto s2 = data.receivePos[1]._rightPos / cutCnt;
	auto s3 = data.receivePos[0]._leftPos / cutCnt;

	auto offset = Share::GetInstance().GetMapMove();
	auto block = VECTOR2(80 / cutCnt, 150 / cutCnt);
	auto circuitOfst = VECTOR2(100, 160);

	auto plPos = Share::GetInstance().GetMiniPos();
	bool check = false;
	auto vel = VECTOR2(0,0);

	auto wall = VECTOR2(0, 0);


	for (int i = 0; i + 1 < data.size; ++i)
	{

		if((i + 1) >= data.size)
		{ 

		}
		else
		{
			t1 = data.receivePos[i]._leftPos / cutCnt;
			t2 = data.receivePos[i]._rightPos / cutCnt;
			t3 = data.receivePos[i + 1]._leftPos / cutCnt;

			s1 = data.receivePos[i + 1]._leftPos / cutCnt;
			s2 = data.receivePos[i + 1]._rightPos / cutCnt;
			s3 = data.receivePos[i]._rightPos / cutCnt;

		}

		auto a = VECTOR2(t1.x - offset.x - block.x - circuitOfst.x, t1.y - offset.y + block.y - circuitOfst.y);
		auto d = VECTOR2(t2.x - offset.x - block.x - circuitOfst.x, t2.y - offset.y + block.y - circuitOfst.y);
		auto c = VECTOR2(s2.x - offset.x - block.x - circuitOfst.x, s2.y - offset.y + block.y - circuitOfst.y);
		auto b = VECTOR2(s1.x - offset.x - block.x - circuitOfst.x, s1.y - offset.y + block.y - circuitOfst.y);

		int l_color = 0x00ff00;

		if (CollisionCheck(a, b, c, d, plPos))
		{
			check = true;
			l_color = 0xffff00;
		
			checkPos = plPos;

			aa = VECTOR2(t1.x - offset.x - block.x - circuitOfst.x, t1.y - offset.y + block.y - circuitOfst.y);
			bb = VECTOR2(s1.x - offset.x - block.x - circuitOfst.x, s1.y - offset.y + block.y - circuitOfst.y);
			cc = VECTOR2(s2.x - offset.x - block.x - circuitOfst.x, s2.y - offset.y + block.y - circuitOfst.y);
			dd = VECTOR2(t2.x - offset.x - block.x - circuitOfst.x, t2.y - offset.y + block.y - circuitOfst.y);

		}

	}

	auto color = 0x0000ff;

	if (check)
	{
		color = 0xffff00;

		checkPos = plPos;

	}
	else
	{
		auto vec = (aa - bb).Normalize();
		VECTOR2 wallVec = { 0,0 };
		auto pVel = Share::GetInstance().GetVelocity().Normalize() * Share::GetInstance().GetSpeed();
		auto bVel = VECTOR2(0, 0);

		VECTOR2 normal = (plPos - checkPos).Normalize();

		float diff = normal.Magnitude();

		normal.Normalize();

		auto callWallVec = [&](const VECTOR2& wall, const VECTOR2& front, VECTOR2& normal) 
		{
			VECTOR2 wall_v;
			wall_v = wall.Normalize();

			normal = (front - Dot(front, wall_v) * wall_v);
		};

		Share::GetInstance().SetReflect(normal);

		auto cqCut = VECTOR2((dd.x + aa.x) / 2, (dd.y + aa.y) / 2);

		auto sVec = (cqCut - plPos).Normalize();

		if (sVec.y < 0)
		{
			vec = (plPos - aa).Normalize();
		}
		else
		{
			vec = (plPos - bb).Normalize();
		}
		VECTOR2 n_V = { 0,0 };
		callWallVec(vec, normal, n_V);
		Share::GetInstance().SetReflect(n_V);

	}
	Share::GetInstance().SetHitCheck(check);

	auto sPos = _startPos / cutCnt;

	DrawCircle(plPos.x, plPos.y, 2, color, true);

	auto qa = VECTOR2(t1.x - offset.x - block.x - circuitOfst.x, t1.y - offset.y + block.y - circuitOfst.y);
	auto qd = VECTOR2(t2.x - offset.x - block.x - circuitOfst.x, t2.y - offset.y + block.y - circuitOfst.y);
	auto qc = VECTOR2(s2.x - offset.x - block.x - circuitOfst.x, s2.y - offset.y + block.y - circuitOfst.y);
	auto qb = VECTOR2(s1.x - offset.x - block.x - circuitOfst.x, s1.y - offset.y + block.y - circuitOfst.y);

	auto cq1 = VECTOR2((qa.x + qb.x) / 2, (qa.y + qb.y) / 2);
	auto cq2 = VECTOR2((qc.x + qd.x) / 2, (qc.y + qd.y) / 2);

	DrawLine(cq1.x, cq1.y, cq2.x, cq2.y, 0xffffff,4);

	int Mx, My;

	GetMousePoint(&Mx, &My);


	bool lcheck = false;

	if (CollisionCheck(cq1, qb, qc, cq2, plPos))
	{
		lcheck = true;
		lrcheck = (!lrcheck ? true : false);
	}
	if (CollisionCheck(qa, qb, qc, qd, plPos))
	{

		if (!pointCheck)
		{
			pointCheck = true;
			auto cCut = VECTOR2((qb.x + qd.x) / 2, (qb.y + qd.y) / 2);

			auto cqCut = VECTOR2((cq1.x + cq2.x) / 2, (cq1.y + cq2.y) / 2);

			auto sVec = (cqCut - plPos).Normalize();

			if (sVec.y < 0)
			{
				if (!rFlag)
				{
					Share::GetInstance().SetRapCnt(++_rapCnt);
				}
				rFlag = false;

			}
			else
			{
				rFlag = true;
			}
		}
	}
	else
	{
		pointCheck = false;
	}

}


bool Circuit::CollisionCheck(VECTOR2 s1, VECTOR2 s2, VECTOR2 s3, VECTOR2 s4, VECTOR2 p)
{
	auto a = CallCrossCheck(s1, s2, p);
	auto b = CallCrossCheck(s2, s3, p);

	auto c = CallCrossCheck(s3, s4, p);
	auto d = CallCrossCheck(s4, s1, p);

	if (a > 0)
	{
		if (b > 0)
		{
			if (c > 0)
			{
				if (d > 0)
				{
					return true;
				}
			}
		}
	}
	return a > 0 && b > 0 && c > 0 && d > 0;
}

bool Circuit::PointCheck(VECTOR2 p, VECTOR2 l1, VECTOR2 l2)
{
	int d;
	if (l1.x > l2.x) {
		d = l1.x;
		l1.x = l2.x;
		l2.x = d;
		d = l1.y;
		l1.y = l2.y;
		l2.y = d;
	}
	auto check1 = l1.x <= p.x && p.x <= l2.x;
	auto check2 = ((l1.y <= l2.y && l1.y <= p.y && p.y <= l2.y) || (l1.y > l2.y && l2.y <= p.y && p.y <= l1.y));
	auto check3 = (int)(p.y - l1.y)*(l2.x - l1.x) == (int)(l2.y - l1.y)*(p.x - l1.x);
	return check1 && check2 && check3;
}

void Circuit::EnemyVecSet()
{
	auto p1 = data.receivePos[0]._leftPos / cutCnt;
	auto p2 = data.receivePos[1]._leftPos / cutCnt;
	auto p3 = data.receivePos[1]._rightPos / cutCnt;
	auto p4 = data.receivePos[0]._rightPos / cutCnt;

	auto offset = Share::GetInstance().GetMapMove();
	auto block = VECTOR2(80 / cutCnt, 150 / cutCnt);
	auto circuitOfst = VECTOR2(100, 160);

	auto ePos = Share::GetInstance().GetEnemyPos();
	auto plPos = Share::GetInstance().GetMiniPos();

	bool check = false;

	auto getPoint = [&](float t, VECTOR2 v1, VECTOR2 v2, VECTOR2 v3) 
	{
		float tp = 1 - t;
		VECTOR2 vec;
		vec.x = t * t * v3.x + 2 * t * tp * v2.x + tp * tp * v1.x;
		vec.y = t * t * v3.y + 2 * t * tp * v2.y + tp * tp * v1.y;
		return vec;
	};

	auto distanceCheck = [&](VECTOR2 p, VECTOR2 e, float& distance)
	{
		float diffuse1 = e.x - p.x;
		float diffuse2 = e.y - p.y;

		bool check = false;
		if (hypot(diffuse1, diffuse2) < 35)
		{
			check = true;
			distance = diffuse1 + diffuse2;
		}

		return check;
	};


	for (int i = 0; i < data.size; ++i)
	{
		if ((i + 1) >= data.size)
		{

		}
		else
		{
			p1 = data.receivePos[i]._leftPos / cutCnt;

			p2 = data.receivePos[i + 1]._leftPos / cutCnt;
			p3 = data.receivePos[i + 1]._rightPos / cutCnt;
			p4 = data.receivePos[i]._rightPos / cutCnt;

		}
		auto color = 0x00ff00;
		auto a = VECTOR2(p1.x - offset.x - block.x - circuitOfst.x, p1.y - offset.y + block.y - circuitOfst.y);
		auto b = VECTOR2(p2.x - offset.x - block.x - circuitOfst.x, p2.y - offset.y + block.y - circuitOfst.y);
		auto c = VECTOR2(p3.x - offset.x - block.x - circuitOfst.x, p3.y - offset.y + block.y - circuitOfst.y);
		auto d = VECTOR2(p4.x - offset.x - block.x - circuitOfst.x, p4.y - offset.y + block.y - circuitOfst.y);

		bool hitcheck = false;

		if (CollisionCheck(a, b, c, d, ePos))
		{
			color = 0xff0000;
			_eCircuitL = d;
			_eCircuitLNext = a;
			hitcheck = true;
			check = true;

			_eLeft = VECTOR2(p1.x - offset.x - block.x - circuitOfst.x, p1.y - offset.y + block.y - circuitOfst.y);
			_eLeft_next = VECTOR2(p2.x - offset.x - block.x - circuitOfst.x, p2.y - offset.y + block.y - circuitOfst.y);

			_enemyAI.a = VECTOR2(p1.x - offset.x - block.x - circuitOfst.x, p1.y - offset.y + block.y - circuitOfst.y);
			_enemyAI.b = VECTOR2(p2.x - offset.x - block.x - circuitOfst.x, p2.y - offset.y + block.y - circuitOfst.y);
			_enemyAI.c = VECTOR2(p3.x - offset.x - block.x - circuitOfst.x, p3.y - offset.y + block.y - circuitOfst.y);
			_enemyAI.d = VECTOR2(p4.x - offset.x - block.x - circuitOfst.x, p4.y - offset.y + block.y - circuitOfst.y);
			
			//�R�[�X�̐^��
			_enemy.normal = VECTOR2((_enemyAI.b.x + _enemyAI.c.x) / 2, (_enemyAI.b.y + _enemyAI.c.y) / 2);
			//��ɃR�[�X�����
			_enemy.week = VECTOR2((_enemy.normal.x + _enemyAI.b.x) / 2, (_enemy.normal.y + _enemyAI.b.y) / 2);
			//�C�����U�߂�
			_enemy.strong = VECTOR2((_enemy.normal.x + _enemyAI.c.x) / 2, (_enemy.normal.y + _enemyAI.c.y) / 2);


		}

	}
	if (check)
	{
		_enemyCheck = ePos;
		auto leftPoint = VECTOR2((_enemyAI.a.x + _enemyAI.b.x) / 2, (_enemyAI.a.y + _enemyAI.b.y) / 2);
		auto rightPoint = VECTOR2((_enemyAI.c.x + _enemyAI.d.x) / 2, (_enemyAI.c.y + _enemyAI.d.y) / 2);

		auto startPoint = VECTOR2((_enemyAI.d.x + _enemyAI.a.x) / 2, (_enemyAI.d.y + _enemyAI.a.y) / 2);

		auto p1 = _enemyAI.a - _enemyAI.a;
		auto p2 = _enemyAI.b - _enemyAI.a;

		auto value1 = p1.x + p2.x + p1.y + p2.y;

		auto p3 = _enemyAI.c - _enemyAI.c;
		auto p4 = _enemyAI.d - _enemyAI.c;

		auto value2 = p3.x + p4.x + p3.y + p4.y;

		auto nvP = (_enemy.normal - ePos);
		auto nvS = (_enemy.normal - startPoint);

		float tP = nvP.Magnitude();
		float tS = nvS.Magnitude();

		float t = (tS - tP) / tS;

		auto enemyVec = (_enemy.normal - ePos).Normalize();



		if (abs(value1) > abs(value2))
		{
			//����
			auto rPP = (_enemyAI.d - rightPoint);
			leftPoint = (leftPoint + rPP);

			if (Share::GetInstance().GetAICheck() == AI::NORMAL)
			{
				auto leftvec = getPoint(t, startPoint, leftPoint, _enemy.normal);
				ePos = leftvec;
				enemyVec = (_enemy.normal - ePos).Normalize();
			}
			else if (Share::GetInstance().GetAICheck() == AI::WEEK)
			{
				auto leftvec = getPoint(t, startPoint, leftPoint, _enemy.week);
				ePos = leftvec;
				enemyVec = (_enemy.week - ePos).Normalize();
			}
			else if (Share::GetInstance().GetAICheck() == AI::STRONG)
			{
				auto leftvec = getPoint(t, startPoint, leftPoint, _enemy.strong);
				ePos = leftvec;
				enemyVec = (_enemy.strong - ePos).Normalize();
			}

			Share::GetInstance().SetCurveCheck(Curve::Curve_Left);
			//DrawLine(a.x, a.y, b.x, b.y, color);

		}
		else if (abs(value1) < abs(value2))
		{
			//�E��
			auto lPP = (_enemyAI.a - leftPoint);
			rightPoint = (rightPoint + lPP);

			if (Share::GetInstance().GetAICheck() == AI::NORMAL)
			{
				auto rightvec = getPoint(t, startPoint, rightPoint, _enemy.normal);
				ePos = rightvec;
				enemyVec = (_enemy.normal - ePos).Normalize();
			}
			else if (Share::GetInstance().GetAICheck() == AI::WEEK)
			{
				auto rightvec = getPoint(t, startPoint, rightPoint, _enemy.week);
				ePos = rightvec;
				enemyVec = (_enemy.week - ePos).Normalize();
			}
			else if (Share::GetInstance().GetAICheck() == AI::STRONG)
			{
				auto rightvec = getPoint(t, startPoint, rightPoint, _enemy.strong);
				ePos = rightvec;
				enemyVec = (_enemy.strong - ePos).Normalize();
			}

			Share::GetInstance().SetCurveCheck(Curve::Curve_Right);
			//DrawLine(c.x, c.y, d.x, d.y, color);
		}
		else
		{
			Share::GetInstance().SetCurveCheck(Curve::Straight);
			//DrawLine(startPoint.x, startPoint.y, normal.x, normal.y, color);
		}


		Share::GetInstance().SetEnemyVec(enemyVec);
		//DrawCircle(normal.x, normal.y, 3, 0x0000ff, true);
		//DrawCircle(startPoint.x, startPoint.y, 5, 0x00ff00);
	}

	float distance = 0.0f;
	bool imageCheck = false;
	if (distanceCheck(plPos, ePos, distance))
	{
		imageCheck = true;
		Share::GetInstance().SetDistance(distance);
	}
	/*DrawCircle(_enemy.week.x, _enemy.week.y, 3, 0x00ff00);
	DrawCircle(_enemy.normal.x, _enemy.normal.y, 3, 0xff0000);
	DrawCircle(_enemy.strong.x, _enemy.strong.y, 3, 0x0000ff);*/


	Share::GetInstance().SetEnemyImageCheck(imageCheck);
	Share::GetInstance().SetEnemyHitCheck(check);

}

float Circuit::CallCrossCheck(VECTOR2 a, VECTOR2 b, VECTOR2 p)
{
	auto vecAB = VECTOR2(a.x - b.x, a.y - b.y);
	auto vecAP = VECTOR2(a.x - p.x, a.y - p.y);

	return vecAB.x * vecAP.y - vecAP.x * vecAB.y;
}
