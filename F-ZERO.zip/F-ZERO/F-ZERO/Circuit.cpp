#include "Dxlib.h"
#include "Circuit.h"
#include "ResourceMng.h"
#include "Share.h"

Circuit::Circuit()
{
	Init();
}


Circuit::~Circuit()
{
}

void Circuit::Init()
{
	fopen_s(&file, "data/CircuitData/data.map", "rb");

	if (!file)
	{
		return;
	}
	fread(&data.size, sizeof(int), 1, file);

	int dummy = 0;
	for (int i = 0; i < 3; ++i)
	{
		fread(&dummy, sizeof(int), 1, file);
	}
	data.receivePos.resize(data.size);

	for (int i = 0; i < data.receivePos.size(); ++i)
	{
		fread(&data.receivePos[i], sizeof(ReceiveCircuitPos), 1, file);

		data.receivePos[i]._leftPos = data.receivePos[i]._leftPos + Share::GetInstance().GetMapCenter();
		data.receivePos[i]._rightPos = data.receivePos[i]._rightPos + Share::GetInstance().GetMapCenter();
	}

	fclose(file);
}

void Circuit::Update()
{
	VECTOR2 vec1, vec2, vec3, vec4;
	VECTOR2 vecToPl1, vecToPl2, vecToPl3, vecToPl4;
	float Cross1, Cross2, Cross3, Cross4;

	auto playerPos = Share::GetInstance().GetPlayerPos();

	auto check = false;

	// data.receivePos.size()�̈�ԍŌ�̗v�f�͈�ԍŏ��̗v�f�Ɠ����Ȃ̂�-1����
	for (int i = 0; i < data.receivePos.size() - 1; ++i)
	{
		// �x�N�g�������
		vec1 = data.receivePos[i]._leftPos - data.receivePos[i]._rightPos;
		vec2 = data.receivePos[i + 1]._leftPos - data.receivePos[i]._leftPos;
		vec3 = data.receivePos[i + 1]._rightPos - data.receivePos[i + 1]._leftPos;
		vec4 = data.receivePos[i]._rightPos - data.receivePos[i + 1]._rightPos;

		// �e���_����v���C���[���W�ւ̃x�N�g�������߂�
		vecToPl1 = playerPos - data.receivePos[i]._rightPos;
		vecToPl2 = playerPos - data.receivePos[i]._leftPos;
		vecToPl3 = playerPos - data.receivePos[i + 1]._leftPos;
		vecToPl4 = playerPos - data.receivePos[i + 1]._rightPos;

		// �O�ς����߂�
		// vec1�~vecToPl1
		Cross1 = (vec1.x * vecToPl1.y) - (vec1.y * vecToPl1.x);

		// vec2�~vecToPl2
		Cross2 = (vec2.x * vecToPl2.y) - (vec2.y * vecToPl2.x);

		// vec3�~vecToPl3
		Cross3 = (vec3.x * vecToPl3.y) - (vec3.y * vecToPl3.x);

		// vec4�~vecToPl4
		Cross4 = (vec4.x * vecToPl4.y) - (vec4.y * vecToPl4.x);

		if (Cross1 > 0 && Cross2 > 0 && Cross3 > 0 && Cross4 > 0)
		{
			check = true;
		}
		Share::GetInstance().SetHitCheck(check);
	}	
}

void Circuit::Draw()
{
	DrawBox(data.receivePos[0]._leftPos.x, data.receivePos[0]._leftPos.y, data.receivePos[1]._leftPos.x, data.receivePos[1]._leftPos.y,0xff0000,true);
}