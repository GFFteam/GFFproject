#include "Dxlib.h"
#include "GameTask.h"
#include "Circuit.h"
#include "ResourceMng.h"
#include "Share.h"

Circuit::Circuit()
{
	Init();
}


Circuit::~Circuit()
{
}

void Circuit::Init()
{
	fopen_s(&file, "data/CircuitData/data.map", "rb");

	if (!file)
	{
		return;
	}
	fread(&data.size, sizeof(int), 1, file);

	int dummy = 0;
	for (int i = 0; i < 3; ++i)
	{
		fread(&dummy, sizeof(int), 1, file);
	}

	data.receivePos.resize(data.size);

	for (int i = 0; i < data.receivePos.size(); ++i)
	{
		fread(&data.receivePos[i], sizeof(ReceiveCircuitPos), 1, file);

		data.receivePos[i]._leftPos = data.receivePos[i]._leftPos + Share::GetInstance().GetMapCenter();
		data.receivePos[i]._rightPos = data.receivePos[i]._rightPos + Share::GetInstance().GetMapCenter();
	}

	fclose(file);

	plToVer.resize(vertexNumber);
	deg.resize(vertexNumber);
}

void Circuit::Update()
{
	playerPos = Share::GetInstance().GetPlayerPos();

	PolygonHitCheck(vertexNumber, data.receivePos.size());
}

void Circuit::Draw()
{
	auto t1 = data.receivePos[0]._leftPos / cutCnt;
	auto t2 = data.receivePos[0]._rightPos / cutCnt;
	auto t3 = data.receivePos[0]._leftPos / cutCnt;

	auto s1 = data.receivePos[0]._leftPos / cutCnt;
	auto s2 = data.receivePos[0]._rightPos / cutCnt;
	auto s3 = data.receivePos[0]._leftPos / cutCnt;

	auto offset = Share::GetInstance().GetMiniMapSize() - Share::GetInstance().GetMapOffset();
	auto block = VECTOR2(80 / cutCnt, 150 / cutCnt);
	auto circuitOfst = VECTOR2(100, 160);

	for (int i = 0; i + 1 < data.size; ++i)
	{
		if ((i + 1) >= data.size)
		{

		}
		else
		{
			t1 = data.receivePos[i]._leftPos / cutCnt;
			t2 = data.receivePos[i]._rightPos / cutCnt;
			t3 = data.receivePos[i + 1]._leftPos / cutCnt;

			s1 = data.receivePos[i + 1]._leftPos / cutCnt;
			s2 = data.receivePos[i + 1]._rightPos / cutCnt;
			s3 = data.receivePos[i]._rightPos / cutCnt;

		}

		DrawTriangle(t1.x - offset.x - block.x - circuitOfst.x,
			t1.y - offset.y + block.y - circuitOfst.y,
			t2.x - offset.x - block.x - circuitOfst.x,
			t2.y - offset.y + block.y - circuitOfst.y,
			t3.x - offset.x - block.x - circuitOfst.x,
			t3.y - offset.y + block.y - circuitOfst.y,
			0xff0000, true);

		DrawTriangle(s1.x - offset.x - block.x - circuitOfst.x,
			s1.y - offset.y + block.y - circuitOfst.y,
			s2.x - offset.x - block.x - circuitOfst.x,
			s2.y - offset.y + block.y - circuitOfst.y,
			s3.x - offset.x - block.x - circuitOfst.x,
			s3.y - offset.y + block.y - circuitOfst.y,
			0xff0000, true);

		/*DrawBox(leftPos.x - offset.x - block.x - circuitOfst.x,
			leftPos.y - offset.y + block.y - circuitOfst.y,
			rightPos.x - offset.x - block.x - circuitOfst.x,
			rightPos.y - offset.y + block.y - circuitOfst.y, 0xff0000, true);*/

	}
}

float Circuit::PolygonHitCheck(int verNum,int size)
{

	float totalDeg = 0.0f;

	// �v���C���[���W�Ɗe���_�̃x�N�g�������
	for (int i = 0; i < size - 1; i++)
	{
		plToVer[0] = data.receivePos[i]._leftPos - playerPos;
		plToVer[1] = data.receivePos[i + 1]._leftPos - playerPos;
		plToVer[2] = data.receivePos[i + 1]._rightPos - playerPos;
		plToVer[3] = data.receivePos[i]._rightPos - playerPos;
	}

	// �x�N�g���ƃx�N�g���̂Ȃ��p�����߂�
	float numerator;	// ���q
	float denominator;	// ����
	for (int i = 0; i < verNum - 1; i++)
	{
		numerator = (plToVer[i].x * plToVer[i + 1].x + plToVer[i].y * plToVer[i + 1].y);
		denominator = sqrt(pow(plToVer[i].x, 2) + pow(plToVer[i].y, 2)) * sqrt(pow(plToVer[i + 1].x, 2) + pow(plToVer[i + 1].y, 2));

		deg[i] = numerator / denominator;
	}

	// �ŏ��̔z��v�f�ƍŌ�̔z��v�f�̌v�Z
	numerator = (plToVer[0].x * plToVer[verNum - 1].x + plToVer[0].y * plToVer[verNum - 1].y);
	denominator = sqrt(pow(plToVer[0].x, 2) + pow(plToVer[0].y, 2)) * sqrt(pow(plToVer[verNum - 1].x, 2) + pow(plToVer[verNum - 1].y, 2));

	deg[verNum - 1] = numerator / denominator;

	for (int i = 0; i < verNum; i++)
	{
		deg[i] = acos(deg[i]) * (180 / PI);
		totalDeg += deg[i];
		DrawFormatString(SCREEN_SIZE_X - 200, 60 + 15 * i, 0xffffff, "deg[i]:%.1f", deg[i]);
	}

	// �����蔻��
	if (totalDeg > 355 && totalDeg < 365)
	{
		DrawFormatString(SCREEN_SIZE_X / 2, SCREEN_SIZE_Y - 50, 0xff0000, "hit!");
		return 0;
	}
	else
	{
		//PolygonHitCheck(verNum, size);
	}
}
