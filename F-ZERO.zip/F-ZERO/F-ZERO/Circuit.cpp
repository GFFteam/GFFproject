#include "Dxlib.h"
#include "Circuit.h"
#include "ResourceMng.h"
#include "Share.h"

Circuit::Circuit()
{
	Init();
}


Circuit::~Circuit()
{
}

void Circuit::Init()
{
	fopen_s(&file, "data/CircuitData/data.map", "rb");

	if (!file)
	{
		return;
	}
	fread(&data.size, sizeof(int), 1, file);

	int dummy = 0;
	for (int i = 0; i < 3; ++i)
	{
		fread(&dummy, sizeof(int), 1, file);
	}

	fclose(file);

	data.receivePos.resize(data.size);

	for (int i = 0; i < data.receivePos.size(); ++i)
	{
		fread(&data.receivePos[i], sizeof(ReceiveCircuitPos), 1, file);

		data.receivePos[i]._leftPos = data.receivePos[i]._leftPos + Share::GetInstance().GetMapCenter();
		data.receivePos[i]._rightPos = data.receivePos[i]._rightPos + Share::GetInstance().GetMapCenter();
	}

	plToVer.resize(4);
}

void Circuit::Update()
{
	playerPos = Share::GetInstance().GetPlayerPos();


}

void Circuit::Draw()
{

}

float Circuit::PolygonHitCheck()
{
	// �v���C���[���W�ƒ��_�̃x�N�g�������
	for (int i = 0; i < data.receivePos.size(); ++i)
	{
		plToVer[0] = data.receivePos[i]._leftPos - playerPos;
		plToVer[1] = data.receivePos[i + 1]._leftPos - playerPos;
		plToVer[3] = data.receivePos[i + 1]._rightPos - playerPos;
		plToVer[2] = data.receivePos[i]._rightPos - playerPos;
	}
	// �x�N�g���ƃx�N�g���̂Ȃ��p�����߂�

	// �����蔻��
	for (int i = 0; i < data.receivePos.size(); ++i)
	{
		float numerator;	// ���q
		float denominator;	// ����
	}
	return 0.0f;
}
