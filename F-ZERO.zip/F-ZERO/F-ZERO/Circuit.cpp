#include "Dxlib.h"
#include "Circuit.h"
#include "ResourceMng.h"
#include "Share.h"

Circuit::Circuit()
{
	Init();
}


Circuit::~Circuit()
{
}

void Circuit::Init()
{
	int r, g, b, a;
	int handle = LoadSoftImage("data/images/screenMap/screen00.png");

	width, height;
	GetGraphSize(IMAGE_ID("data/images/screenMap/screen00.png"), &width, &height);

	vv.resize(width);
	for (size_t i = 0; i < width; i++) {
		vv[i].resize(width);
	}

	for (int y = 0; y < width; y++)
	{
		for (int x = 0; x < height; x++)
		{
			vv[x][y].pos.x = x;
			vv[x][y].pos.y = y;
			vv[x][y].flag = false;
			GetPixelSoftImage(handle, x, y, &r, &g, &b, &a);

			if (a == 0)
			{
				vv[x][y].flag = true;
			}
		}
	}
}

void Circuit::Update()
{
	moveOneLoop.x = Share::GetInstance().GetMapMove().x - diff.x;
	moveOneLoop.y = Share::GetInstance().GetMapMove().y - diff.y;

	for (int y = 0; y < width; y++)
	{
		for (int x = 0; x < height; x++)
		{
			vv[x][y].pos.x += moveOneLoop.x;
			vv[x][y].pos.y += moveOneLoop.y;
		}
	}
	diff.x = Share::GetInstance().GetMapMove().x;
	diff.y = Share::GetInstance().GetMapMove().y;
}

void Circuit::Draw()
{
	//DrawFormatString(400, 100, 0xffffff, "x:%.1f\ny:%.1f", moveOneLoop.x, moveOneLoop.y);
}
