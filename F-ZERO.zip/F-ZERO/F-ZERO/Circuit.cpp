#include "Dxlib.h"
#include "Circuit.h"
#include "ResourceMng.h"

Circuit::Circuit()
{
	Init();
}


Circuit::~Circuit()
{
}

void Circuit::Init()
{
	int r, g, b, a;
	auto handle = LoadSoftImage("data/images/screenMap/screen00.png");

	int width, height;
	GetGraphSize(IMAGE_ID("data/images/screenMap/screen00.png"), &width, &height);

	for (int i = 0; i < width; i++)
	{
		for (int j = 0; j < height; j++)
		{
			GetPixelSoftImage(handle, i, j, &r, &g, &b, &a);

			if (a == 0)
			{

			}
		}
	}
}

void Circuit::Update()
{
}

void Circuit::Draw()
{

}
