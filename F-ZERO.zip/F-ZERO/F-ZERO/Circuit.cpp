#include "Dxlib.h"
#include "Circuit.h"
#include "ResourceMng.h"
#include "Share.h"

Circuit::Circuit()
{
	Init();
}


Circuit::~Circuit()
{
}

void Circuit::Init()
{
	fopen_s(&file, "data/CircuitData/data.map","rb");

	if (!file)
	{
		return;
	}
	fread(&data.size, sizeof(int), 1, file);

	int dummy = 0;
	for (int i = 0; i < 3; ++i)
	{
		fread(&dummy, sizeof(int), 1, file);
	}
	data.receivePos.resize(data.size);

	for (int i = 0; i < data.receivePos.size(); ++i)
	{
		fread(&data.receivePos[i], sizeof(ReceiveCircuitPos), 1, file);
	}

	fclose(file);
}

void Circuit::Update()
{
	//for (int i = 0; i < data.receivePos.size(); ++i)
	//{
	//	rcp.
	//}
}

void Circuit::Draw()
{
}
