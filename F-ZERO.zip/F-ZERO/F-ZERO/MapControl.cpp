#include "MapControl.h"
#include "DxLib.h"
#include "GameTask.h"
#include "ResourceMng.h"
#include "KeyMng.h"
#include "Player.h"
#include "VECTOR2.h"

MapControl::MapControl()
{
	Init();
}


MapControl::~MapControl()
{
}

void MapControl::Init()
{
	GetScreenState(&sw, &sh, &dep);
	map = IMAGE_ID("data/images/Tilemap4.png");
	GetGraphSize(map, &gw, &gh);
	base = MakeScreen(gw, gh);

	x = gw / 2;
	z = gh / 2;
	rotX = x;
	rotZ = z;
	theta = 0;
	angle = 0.0f;

	if (pl.empty())
	{
		pl.push_back(std::make_shared<Player>());
	}
}

void MapControl::Update()
{
	Perspective();
}

void MapControl::Draw()
{
	DrawBox(0, 0, sw, sh, GetColor(0,0,0), true);
	DrawFormatString(SCREEN_SIZE_X - 200, 0, 0xffffff, "angle:%.1f", angle);
	DrawFormatString(SCREEN_SIZE_X - 200, 15, 0xffffff, "theta:%.1f", theta);
	DrawFormatString(SCREEN_SIZE_X - 200, 30, 0xffffff, "x:%d", x);
	DrawFormatString(SCREEN_SIZE_X - 200, 45, 0xffffff, "z:%d", z);
	DrawFormatString(SCREEN_SIZE_X - 200, 60, 0xffffff, "perspectiveX:%.1f", perspectiveX);
	DrawFormatString(SCREEN_SIZE_X - 200, 75, 0xffffff, "perspectiveZ:%.1f", perspectiveZ);
	DrawFormatString(SCREEN_SIZE_X - 200, 100, 0xffffff, "az:%.1f", az);
}

void MapControl::Key()
{
	if (KeyMng::GetInstance().newKey[P1_LEFT])
	{
		angle++;
	}
	if (KeyMng::GetInstance().newKey[P1_RIGHT])
	{
		angle--;
	}

	if (KeyMng::GetInstance().newKey[P1_UP])
	{
		az--;
	}
	if (KeyMng::GetInstance().newKey[P1_DOWN])
	{
		az++;
	}	
}

void MapControl::Perspective()
{
	int y = sh / 3;
	int h = 1;
	int sy = 0;
	int alpha = 50;
	//az.y = az.y - z;
	
	theta = angle * (PI / 180);
	SetDrawScreen(base);
	DrawRotaGraph2(x, z + 200, x, z + 200 , 1, theta, map, false);
	SetDrawBlendMode(DX_BLENDMODE_ALPHA, 150);
	DrawRotaGraph(x, z + 200 + az, 0.05, 0, IMAGE_ID("data/images/shadow.png"), true);
	SetDrawBlendMode(DX_BLENDMODE_NOBLEND, alpha);
	DrawCircle(az, az, 10, 0xffffff);
	DrawCircle(x, z + 200 + az, 20, 0xff0000);
	//DrawLine(az.x, az.y, x, z + 200, 0xffffff, 10);
	SetDrawScreen(DX_SCREEN_BACK);

	while (y < sh)
	{
		float rate = ((40.0f - static_cast<float>(h)) / 40.0f) * 0.5f;
		perspectiveX = sw / 2;
		perspectiveZ = sy;
		perspectiveX *= rate;
		SetDrawBlendMode(DX_BLENDMODE_ALPHA, alpha);
		DrawRectExtendGraph(0, y, sw, y + h, x - perspectiveX, z + perspectiveZ + az, sw * rate, 10, base, true);
		SetDrawBlendMode(DX_BLENDMODE_NOBLEND, alpha);
		alpha += 10;
		y += h;
		h++;
		sy += 10;
	}

	// �����Ƀv���C���[��UI���̕`��

	for (auto i : pl)
	{
		(*i).Key();
		(*i).Update();
		(*i).Draw();
	}

	DrawRotaGraph(0.3 * gw / 2, 0.3 * gh / 2, 0.3, 0.0, base, true);		// �������ϯ��
	ScreenFlip();
	ClearDrawScreen();
}
