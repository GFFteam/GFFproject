#include "MapControl.h"
#include "DxLib.h"
#include "GameTask.h"
#include "ResourceMng.h"
#include "KeyMng.h"
#include "Player.h"
#include "UI.h"
#include "Circuit.h"
#include "Share.h"
#include "VECTOR2.h"

MapControl::MapControl()
{
	Init();
}


MapControl::~MapControl()
{
}

void MapControl::Init()
{
	GetScreenState(&sw, &sh, &dep);
	mapId.push_back(IMAGE_ID("data/images/underMapCenter.png"));
	mapId.push_back(IMAGE_ID("data/CircuitData/screen00.png"));
	mapId.push_back(IMAGE_ID("data/CircuitData/screen02.png"));
	GetGraphSize(mapId[1], &gw, &gh);
	GetGraphSize(mapId[0], &gw1, &gh1);
	GetGraphSize(mapId[2], &gw2, &gh2);
	//gw *= EX_RATE;
	//gh *= EX_RATE;
	base = MakeScreen(gw1, gh1);

	x = gw1 / 2;
	z = gh1 / 2;
	Share::GetInstance().SetMapCenter(x - (gw / 2), z - (gh / 2));
	theta = 0;
	angle = 0.0f;

	if (pl.empty())
	{
		pl.push_back(std::make_shared<Player>());
	}
	if (ui.empty())
	{
		ui.push_back(std::make_shared<UI>());
	}
	if (cir.empty())
	{
		cir.push_back(std::make_shared<Circuit>());
	}
}

void MapControl::Update()
{
	speed = Share::GetInstance().GetSpeed();

	Share::GetInstance().SetPlayerPos(x + ax, z + az + ROT_OFFSET);
}

void MapControl::Draw()
{
	DrawBox(0, 0, sw, sh, GetColor(0,0,0), true);
	DrawFormatString(SCREEN_SIZE_X - 200, 0, 0xffffff, "hit:%d", Share::GetInstance().GetHitCheck());
	DrawFormatString(SCREEN_SIZE_X - 200, 15, 0xffffff, "playerPos.x:%.1f", x + ax);
	DrawFormatString(SCREEN_SIZE_X - 200, 30, 0xffffff, "playerPos.z:%.1f", z + az + ROT_OFFSET);
}

void MapControl::Key()
{
	if (KeyMng::GetInstance().newKey[P1_LEFT])
	{
		angle += 1.5f;
	}
	if (KeyMng::GetInstance().newKey[P1_RIGHT])
	{
		angle -= 1.5f;
	}

	if (KeyMng::GetInstance().newKey[P1_UP])
	{
		auto theta = angle * (PI / 180);
	}

	ax -= sin(theta) * speed;
	az -= cos(theta) * speed;

	Share::GetInstance().SetMapMove(ax, az);
}

void MapControl::OtherControl()
{
	for (auto i : pl)
	{
		(*i).Key();
		(*i).Update();
		(*i).Draw();
	}

	for (auto i : ui)
	{
		(*i).Update();
		(*i).Draw();
	}

	for (auto i : cir)
	{
		(*i).Update();
		(*i).Draw();
	}
}

void MapControl::Perspective()
{
	int y = sh / 5;
	int h = 1;
	int sy = 0;
	int alpha = 150;
	
	theta = angle * (PI / 180);
	SetDrawScreen(base);
	// �u�e�̒��S�v�𒆐S�ɉ�]
	DrawRotaGraph2(x, z + ROT_OFFSET, x + ax, z + ROT_OFFSET + az, 2.0f, theta, mapId[0], false);
	DrawRotaGraph2(x, z + ROT_OFFSET, ax + (gw / 2), az + (gh / 2) + ROT_OFFSET, 2.0f, theta, mapId[1], true);
	DrawRotaGraph2(x, z + ROT_OFFSET, ax + (gw / 2), az + (gh / 2) + ROT_OFFSET, 2.0f, theta, mapId[2], true);

	SetDrawBlendMode(DX_BLENDMODE_ALPHA, 150);
	DrawRotaGraph(x, z + ROT_OFFSET, 0.08f, 0, IMAGE_ID("data/images/shadow.png"), true);
	DrawCircle(x, 0, 20, 0x0000ff, true);
	SetDrawBlendMode(DX_BLENDMODE_NOBLEND, 0);
	SetDrawScreen(DX_SCREEN_BACK);

	while (y < sh)
	{
		float rate = ((35.0f - static_cast<float>(h)) / 35.0f) * 1.0f;
		perspectiveX = sw / 2;
		perspectiveZ = sy;
		perspectiveX *= rate;
		SetDrawBlendMode(DX_BLENDMODE_ALPHA, alpha);
		DrawRectExtendGraph(0, y, sw, y + h, x - perspectiveX, z + perspectiveZ , sw * rate, 10, base, true);
		SetDrawBlendMode(DX_BLENDMODE_NOBLEND, alpha);
		alpha += 5;
		y += h;
		h++;
		sy += 10;
	}

	// �����Ƀv���C���[��UI���̕`��
	int BaseGw, BaseGh;
	GetGraphSize(IMAGE_ID("data/images/cockpitBase.png"), &BaseGw, &BaseGh);
	OtherControl();

	Share::GetInstance().SetMiniMapSize(gw2 / cutCnt, gh2 / cutCnt);

	//DrawRotaGraph(0.1f * (gw1 / 2), 0.1f * (gh1 / 2), 0.1f, 0.0, base, true);		// �������ϯ��
	ScreenFlip();
	ClearDrawScreen();
}
