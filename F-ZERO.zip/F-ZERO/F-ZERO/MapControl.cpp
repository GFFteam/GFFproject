#include "MapControl.h"
#include "DxLib.h"
#include "GameTask.h"
#include "ResourceMng.h"
#include "KeyMng.h"
#include "Player.h"
#include "Enemy.h"
#include "UI.h"
#include "Circuit.h"
#include "Share.h"
#include "VECTOR2.h"
#include <string>

constexpr unsigned int startDivY = 35;
constexpr unsigned int startBack = 108;
constexpr unsigned int changeDiv = 80;
constexpr unsigned int changeBack = -33;


MapControl::MapControl()
{
	Init();
}


MapControl::~MapControl()
{
}

void MapControl::Init()
{
	GetScreenState(&sw, &sh, &dep);
	mapId.push_back(IMAGE_ID("data/images/underMap.png"));
	mapId.push_back(IMAGE_ID("data/CircuitData/screen00.png"));
	mapId.push_back(IMAGE_ID("data/CircuitData/screen02.png"));
	GetGraphSize(mapId[1], &gw, &gh);
	GetGraphSize(mapId[0], &gw1, &gh1);
	//gw *= EX_RATE;
	//gh *= EX_RATE;
	base = MakeScreen(gw1, gh1);

	x = gw1 / 2;
	z = gh1 / 2;
	Share::GetInstance().SetMapCenter(x, z);
	theta = 0;
	angle = 0.0f;

	if (cir.empty())
	{
		cir.push_back(std::make_shared<Circuit>());
	}
	if (pl.empty())
	{
		pl.push_back(std::make_shared<Player>());
		pl.push_back(std::make_shared<Enemy>(Share::GetInstance().GetStartPos()));

	}
	if (ui.empty())
	{
		ui.push_back(std::make_shared<UI>());
	}

	GetGraphSize(mapId[2], &gw2, &gh2);
	ax = Share::GetInstance().GetStartPos().x;// gw1 / 2;
	az = Share::GetInstance().GetStartPos().y;// gh1 / 2;

}

void MapControl::Update()
{
	speed = Share::GetInstance().GetSpeed();
	Share::GetInstance().SetMapOffset(VECTOR2(ax, az + ROT_OFFSET));
	shadowOffsetLR = (Share::GetInstance().GetPlayerRollAngle() * 10);

}

void MapControl::Draw()
{
	DrawBox(0, 0, sw, sh, GetColor(0,0,0), true);
	DrawFormatString(SCREEN_SIZE_X - 200, 0, 0xffffff, "dis:%d", Share::GetInstance().GetRapCnt());
	DrawFormatString(SCREEN_SIZE_X - 200, 15, 0xffffff, "playerPos.x:%.1f", _playerPos.x/*x + ax*/);
	DrawFormatString(SCREEN_SIZE_X - 200, 30, 0xffffff, "playerPos.z:%.1f", _playerPos.y/*z + az + ROT_OFFSET*/);
	DrawFormatString(SCREEN_SIZE_X - 200, 45, 0xffffff, "div:%.1f backY:%d", _div,_backY);

	DrawFormatString(SCREEN_SIZE_X - 200, 70, 0xffffff, "curve:%d", Share::GetInstance().GetCurveCheck());

	auto check = Share::GetInstance().GetCurveCheck();

	std::string str;
	str = ((check == Curve::Straight) ? "����" : (check == Curve::Curve_Left) ? "���J�[�u" : (check == Curve::Curve_Right) ? "�E�J�[�u" : "�Ȃɂ��Ȃ�");
	DrawString(SCREEN_SIZE_X - 200, 90, str.c_str(), 0xffffff);

}

float Dot(const VECTOR2& va, const VECTOR2& vb)
{
	return va.x*vb.x + va.y*vb.y;
}

void MapControl::Key()
{

	auto reflectVec = [&](VECTOR2 n, VECTOR2& normal)
	{
		return n - normal * 2 * Dot(n, normal);
	};

	if (KeyMng::GetInstance().newKey[P1_LEFT])
	{
		angle += 1.5f;
	}
	if (KeyMng::GetInstance().newKey[P1_RIGHT])
	{
		angle -= 1.5f;
	}

	//�J�����̎��_�؂�ւ�
	if (KeyMng::GetInstance().newKey[P1_Z])
	{
		_div = changeDiv;
		_backY = changeBack;
		Share::GetInstance().SetChangeFlag(true);
	}
	else
	{
		_div = startDivY;
		_backY = startBack;
		Share::GetInstance().SetChangeFlag(false);
	}

	if (KeyMng::GetInstance().newKey[P1_UP])
	{
		auto theta = angle * (PI / 180);
	}

	/*if (Share::GetInstance().GetHitCheck())
	{*/
		ax -= sin(theta) * speed;
		az -= cos(theta) * speed;

	/*	_pPos = Share::GetInstance().GetPlayerPos();
	}
	else
	{
		auto norm = (_pPos - Share::GetInstance().GetPlayerPos()).Normalize();
		auto t = VECTOR2(sin(theta) * speed, cos(theta) * speed);
		auto i = reflectVec(t, norm);

		ax -= i.x * speed;
		az += i.y * speed;
	}*/
	

}

void MapControl::OtherControl()
{
	for (auto i : pl)
	{
		(*i).Key();
		(*i).Update();
		(*i).Draw();
		(*i).PositionDraw();
	}

	for (auto i : ui)
	{
		(*i).Update();
		(*i).Draw();
	}

	for (auto i : cir)
	{
		(*i).Update();
		(*i).Draw();
	}
}

void MapControl::Perspective()
{
	int y = _backY;// sh / 5;
	int h = 1;
	int sy = 0;
	int alpha = 150;
	//�e�̈ʒu�␳
	int shadowY = startDivY - _div;
	
	theta = angle * (PI / 180);
	SetDrawScreen(base);
	// �u�e�̒��S�v�𒆐S�ɉ�]
	DrawRotaGraph2(x, z + ROT_OFFSET, x + ax, z + ROT_OFFSET + az, 2.0f, theta, mapId[0], false);
	DrawRotaGraph2(x, z + ROT_OFFSET, ax + (gw / 2), az + (gh / 2) + ROT_OFFSET, 2.0f, theta, mapId[1], true);
	DrawRotaGraph2(x, z + ROT_OFFSET, ax + (gw / 2), az + (gh / 2) + ROT_OFFSET, 2.0f, theta, mapId[2], true);

	SetDrawBlendMode(DX_BLENDMODE_ALPHA, 150);

	_playerPos.x = x + ax;
	_playerPos.y = z + az;
	Share::GetInstance().SetPlayerPos(_playerPos.x, _playerPos.y);
	DrawRotaGraph(x - shadowOffsetLR, z + ROT_OFFSET - shadowY, 0.08f, 0, IMAGE_ID("data/images/p_shadow01.png"), true);
	DrawCircle(x, 0, 20, 0x0000ff, true);
	SetDrawBlendMode(DX_BLENDMODE_NOBLEND, 0);
	SetDrawScreen(DX_SCREEN_BACK);

	while (y < sh)
	{
		float rate = ((_div - static_cast<float>(h)) / _div) * 1.0f;
		perspectiveX = sw / 2;
		perspectiveZ = sy;
		perspectiveX *= rate;
		SetDrawBlendMode(DX_BLENDMODE_ALPHA, alpha);
		DrawRectExtendGraph(0, y, sw, y + h, x - perspectiveX, z + perspectiveZ , sw * rate, 10, base, true);
		SetDrawBlendMode(DX_BLENDMODE_NOBLEND, alpha);
		alpha += 5;
		y += h;
		h++;
		sy += 10;
	}
	// �����Ƀv���C���[��UI���̕`��
	int BaseGw, BaseGh;
	GetGraphSize(IMAGE_ID("data/images/cockpitBase.png"), &BaseGw, &BaseGh);

	//DrawRotaGraph(0.1f * (gw1 / 2), 0.1f * (gh1 / 2), 0.1f, 0.0, base, true);		// �������ϯ��
	SetDrawBlendMode(DX_BLENDMODE_ALPHA, 200);
	DrawExtendGraph(0, 0, (gw2 / cutCnt), (gh2 / cutCnt), mapId[2], true);
	SetDrawBlendMode(DX_BLENDMODE_NOBLEND, 0);

	Share::GetInstance().SetMapMove((gw2 / cutCnt),(gh2 / cutCnt));

	OtherControl();
	if (Share::GetInstance().GetRapCnt() > 5 || KeyMng::GetInstance().trgKey[P1_ENTER])
	{
		auto SaveGameResult = SaveDrawScreenToPNG(0, 0, SCREEN_SIZE_X, SCREEN_SIZE_Y, "data/images/result.png");

		GameTask::GetInstance().SetResultHandle(SaveGameResult);
		_clearCheck = true;
	}

	ScreenFlip();
	ClearDrawScreen();
}
