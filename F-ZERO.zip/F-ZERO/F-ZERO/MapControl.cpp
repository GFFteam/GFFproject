#include "MapControl.h"
#include "DxLib.h"
#include "GameTask.h"
#include "ImageMng.h"
#include "KeyMng.h"


MapControl::MapControl()
{
	Init();
}


MapControl::~MapControl()
{
}

void MapControl::Init()
{
	GetScreenState(&sw, &sh, &dep);
	map = IMAGE_ID("data/images/Tilemap4.png");
	GetGraphSize(map, &gw, &gh);
	base = MakeScreen(gw, gh);

	x = sw / 2;
	z = sh / 2;
	theta = 0;
	angle = 0.0f;
}

void MapControl::Update()
{
	Perspective();
}

void MapControl::Draw()
{
	DrawBox(0, 0, sw, sh, GetColor(0, 0, 0), true);
}

void MapControl::Key()
{
	if (KeyMng::GetInstance().newKey[P1_LEFT])
	{
		angle++;
	}
	if (KeyMng::GetInstance().newKey[P1_RIGHT])
	{
		angle--;
	}
	if (KeyMng::GetInstance().newKey[P1_UP])
	{
		z--;
	}
	if (KeyMng::GetInstance().newKey[P1_DOWN])
	{
		z++;
	}
}

void MapControl::Perspective()
{
	int y = sh / 3;
	int h = 1;
	int sy = 0;
	int alpha = 50;

	theta = angle * (PI / 180);
	SetDrawScreen(base);
	DrawRotaGraph2(x, z + 200, x, z + 200, 1, theta, map, false);
	DrawCircle(x, z + 200, 10, 0xff0000);
	SetDrawScreen(DX_SCREEN_BACK);
	while (y < sh)
	{
		float rate = ((40.0f - static_cast<float>(h)) / 40.0f) * 0.5f;
		float perspectiveX = sw / 2;
		float perspectiveZ = sy;
		perspectiveX *= rate;
		SetDrawBlendMode(DX_BLENDMODE_ALPHA, alpha);
		DrawRectExtendGraph(0, y, sw, y + h, x - perspectiveX, z + perspectiveZ, sw * rate, 10, base, true);
		SetDrawBlendMode(DX_BLENDMODE_NOBLEND, alpha);
		alpha += 15;
		y += h;
		h++;
		sy += 10;
	}
	DrawRotaGraph(0.3*gw / 2, 0.3*gh / 2, 0.3, 0.0, base, true);		// �������ϯ��
	ScreenFlip();
	ClearDrawScreen();
}
