#include <future>
#include "GameTask.h"
#include "DxLib.h"
#include "KeyMng.h"
#include "MapControl.h"
#include "Player.h"
#include "BgControl.h"
#include "Share.h"
#include "ResourceMng.h"
#include "Smoke.h"

GameTask* GameTask::s_Instance = nullptr;

GameTask::GameTask()
{
}

GameTask::~GameTask()
{
}

void GameTask::Create()
{
	if (!s_Instance)
	{
		s_Instance = new GameTask();
	}
}

int GameTask::SystemInit()
{
	SetWindowText("F-ZERO");
	SetGraphMode(SCREEN_SIZE_X, SCREEN_SIZE_Y, 16);
	ChangeWindowMode(true);
	if (DxLib_Init() == -1) {
		return -1;
	}
	SetDrawScreen(DX_SCREEN_BACK);
	GameInit();
	return 0;
}

void GameTask::Update()
{
	KeyMng::GetInstance().Update();
	
	if (updateMode != G_MAIN)
	{
		ClsDrawScreen();
		(this->*gtskPtr[updateMode])();
		ScreenFlip();
	}
	else
	{
		(this->*gtskPtr[updateMode])();
	}
}

void GameTask::GameInit()
{
	DrawString(10, 10, "INIT", 0xff0000);
	_raceStart._startFlag = false;
	_raceStart._startCnt = 3;
	_raceStart._raceCnt = 0;
	_raceStart._efectCnt = 0;
	_raceMode = RACE_MODE::NON;

	GetGraphSize(IMAGE_ID("data/images/player01_up.png"), &miniPlaneGw, &miniPlaneGh);

	updateMode = G_TITLE;
}


void GameTask::GameTitle()
{
	auto isPointCheck = [&](VECTOR2 p, VECTOR2 l1, VECTOR2 l2)
	{
		int d;
		if (l1.x > l2.x) {
			d = l1.x;
			l1.x = l2.x;
			l2.x = d;
			d = l1.y;
			l1.y = l2.y;
			l2.y = d;
		}
		auto check1 = l1.x <= p.x && p.x <= l2.x;
		auto check2 = ((l1.y <= l2.y && l1.y <= p.y && p.y <= l2.y) || (l1.y > l2.y && l2.y <= p.y && p.y <= l1.y));
		auto check3 = (p.y - l1.y)*(l2.x - l1.x) == (l2.y - l1.y)*(p.x - l1.x);
		return check1 && check2 && check3;
	};

	auto getPoint = [&](float t, VECTOR2 v1, VECTOR2 v2, VECTOR2 v3) {
		float tp = 1 - t;
		VECTOR2 vec;
		vec.x = t * t*v3.x + 2 * t*tp*v2.x + tp * tp*v1.x;
		vec.y = t * t*v3.y + 2 * t*tp*v2.y + tp * tp*v1.y;
		return vec;
	};

	(Bswitch ? --timeCnt : ++timeCnt);

	int Mx, My;
	GetMousePoint(&Mx, &My);

	VECTOR2 line1 = { 100,300 };
	VECTOR2 line2 = { 400,230 };

	VECTOR2 p = { (float)Mx,(float)My };

	auto vec = (p - line1) / 100;

	auto vecP = (line2 - p) / 100;

	auto pos = line1;
	auto posP = p;
	auto posB = pos;

	pos = pos + (vec * timeCnt);
	posP = posP + (vecP * timeCnt);

	auto vecB = (posP - pos) / 100;
	posB = posB + (vecB * timeCnt);

	if (timeCnt > 100)
	{
		/*pos = line1;
		posP = p;
		timeCnt = 0;*/
		Bswitch = true;
	}

	if (timeCnt < 0)
	{
		Bswitch = false;
	}

	float t = timeCnt * 0.01f;
	VECTOR2 point = { 0,0 };
	point = getPoint(t, line1, p, line2);


	DrawLine(line1.x, line1.y, line2.x, line2.y, 0xffffff);

	DrawCircle(pos.x, pos.y, 5, 0xffffff);
	DrawCircle(posP.x, posP.y, 5, 0xffffff);

	DrawCircle(point.x, point.y, 5, 0x0000ff);


	auto color = 0xff0000;

	if (isPointCheck(VECTOR2(Mx, My), line1, line2))
	{
		color = 0x0000ff;
	}
	DrawCircle(Mx, My, 5, color);


	if (KeyMng::GetInstance().trgKey[P1_ENTER])
	{
		updateMode = G_MENU;
	}
	DrawBox(0, 0, SCREEN_SIZE_X, SCREEN_SIZE_Y, 0x000000,true);
	DrawRotaGraph(SCREEN_SIZE_X / 2, SCREEN_SIZE_Y / 2, 1, 0, IMAGE_ID("data/images/titleLogoWLong.png"),true);
	DrawString(SCREEN_SIZE_X / 2 - 75, SCREEN_SIZE_Y / 2 + 150, "PRESS START BUTTON",0xffffff,0x777777);
}

void GameTask::GameMenu()
{
	DrawString(10, 10, "MENU", 0xffffff);

	auto reset = [&]()
	{
		mode = 0;
		nextMode = 0;
		taLogoSize = 0.7f;
		taSize = 0.4f;
		rcLogoSize = 0.7f;
		rcSize = 0.4f;
		backSize = 0.7f;
		flashFlag = false;
		flashCnt = 0;
		miniPlaneAngle = 0.0f;
		miniPlanePos = VECTOR2(SCREEN_SIZE_X / 2, -50.0f);
		smokeCount = 0;
		startPoint = VECTOR2(0.0f, 0.0f);
		nextPoint = VECTOR2(0.0f, 0.0f);
		endPoint = VECTOR2(0.0f, 0.0f);
		pointCount = 0;
		miniToStartVec = VECTOR2(0.0f, 0.0f);
		miniToNextVec = VECTOR2(0.0f, 0.0f);
		moveFlag = false;
		beforeMode = 0;
		miniSize = VECTOR2(0.0f, 0.0f);
		lrdFlag = 0;
	};

	MenuCtrl();

	if (KeyMng::GetInstance().trgKey[P1_SPACE])
	{
		flashFlag = true;
	}

	if (flashFlag == true)
	{
		if (flashCnt > 60)
		{
			if (nextMode == 1)
			{
				_raceMode = RACE_MODE::TIME_ATTACK;
				updateMode = G_MAIN;

			}
			else if (nextMode == 2)
			{
				_raceMode = RACE_MODE::RACE;
				updateMode = G_MAIN;
			}
			else if (nextMode == 3)
			{
				updateMode = G_TITLE;
			}

			reset();
		}
	}
}

void GameTask::GameMain()
{	
	//����(Obj�Ƃ��ł܂Ƃ߂�)
	if (mc.empty())
	{
		mc.push_back(std::make_shared <MapControl>());
	}
	if (bg.empty())
	{
		bg.push_back(std::make_shared <BgControl>());
	}

	//�X�^�[�g�O�̃J�E���g
	RaceStartCount();
	//


	for (auto i : mc)
	{
		(*i).Perspective();
		if (GetRaceStart()._startFlag)
		{
			(*i).Key();
			(*i).Update();
		}
		(*i).Draw();

		if ((*i).GetClearCheck())
		{

			updateMode = G_RESULT;
		}
	}

	for (auto i : bg)
	{
		(*i).Update();
		(*i).Draw();
	}
}

void GameTask::GameResult()
{
	_result.timeCnt++;

	auto efect = (_result.timeCnt <= 100 ? _result.timeCnt : 100);

	SetDrawBlendMode(DX_BLENDMODE_ALPHA, 255 - efect);

	int handle = LoadGraph("data/images/Result/result.png");
	DrawGraph(0, 0, handle, true);

	SetDrawBlendMode(DX_BLENDMODE_NOBLEND, 0);

	if (_raceMode == RACE_MODE::TIME_ATTACK)
	{
		if (efect == 100 && _result.timeCnt > 150)
		{
			DrawRotaGraph(SCREEN_SIZE_X / 2, SCREEN_SIZE_Y / 4, 0.6f, 0, IMAGE_ID("data/images/lapTime.png"), true);

			if (_result.timeCnt > 200)
			{
				auto m = mc.begin();
				(*m)->ResultDraw();
			}
		}
	}
	if (KeyMng::GetInstance().trgKey[P1_ENTER])
	{
		mc.pop_back();
		_result.timeCnt = 0;

		updateMode = G_INIT;
	}
}


void GameTask::MenuCtrl()
{
	DrawRotaGraph(SCREEN_SIZE_X / 2, SCREEN_SIZE_Y / 2, 0.9f, 0, IMAGE_ID("data/images/modeSelect/mode_select.png"), true);

	bta.D = LOGO_CENTER_Y + 160;
	bta.L = (LOGO_CENTER_X + 150) - 100;
	bta.R = (LOGO_CENTER_X + 150) + 100;
	bta.U = LOGO_CENTER_Y - 100;

	brc.D = LOGO_CENTER_Y + 160;
	brc.L = (LOGO_CENTER_X - 150) - 100;
	brc.R = (LOGO_CENTER_X - 150) + 100;
	brc.U = LOGO_CENTER_Y - 100;

	box[0] = VECTOR2(brc.L, brc.U);
	box[1] = VECTOR2(brc.L, brc.D);
	box[2] = VECTOR2(brc.R, brc.D);
	box[3] = VECTOR2(brc.R, brc.U);

	box[4] = VECTOR2(bta.L, bta.D);
	box[5] = VECTOR2(bta.R, bta.D);
	box[6] = VECTOR2(bta.R, bta.U);
	box[7] = VECTOR2(bta.L, bta.U);

	miniSize = VECTOR2(miniPlaneGw * 0.1f, miniPlaneGh * 0.1f);

	auto hitCheck = [&](VECTOR2 start, VECTOR2 mini, float miniGw,float miniGh)
	{
		if (start.x - 1.5f < mini.x + miniGw / 2 && start.x + 1.5f > mini.x - miniGw / 2 &&
			start.y - 1.5f < mini.y + miniGh / 2 && start.y + 1.5f > mini.y - miniGh / 2)
		{
			return true;
		}
		return false;
	};

	auto miniPlaneCtrl = [&]()
	{
		smokeCount++;
		if (smokeCount % 2 == 0)
		{
			sm.push_back(std::make_shared<Smoke>());
		}

		for (auto i : sm)
		{
			(*i).Update();
			(*i).MenuSmoke();
		}

		for (auto i : sm)
		{
			if ((*i).GetAlpha() < 0)
			{
				sm.pop_front();
				break;
			}
		}

		DrawRotaGraph(miniPlanePos.x, miniPlanePos.y, 0.1f, miniPlaneAngle * (PI / 180), IMAGE_ID("data/images/player01_up.png"), true);

		if (beforeMode != mode)
		{
			moveFlag = true;
		}

		if (moveFlag)
		{
			miniToStartVec = startPoint - miniPlanePos;
			miniToStartVec = miniToStartVec.Normalize();

			miniPlanePos.x += miniToStartVec.x * 5.0f;
			miniPlanePos.y += miniToStartVec.y * 5.0f;

			if (hitCheck(startPoint,miniPlanePos,miniSize.x, miniSize.y))
			{
				moveFlag = false;
			}
		}
		beforeMode = mode;
	};

	if (flashFlag == false)
	{
		DrawRotaGraph(LOGO_CENTER_X + 150, LOGO_CENTER_Y, taLogoSize, 0, IMAGE_ID("data/images/modeSelect/timeLogo.png"), true);
		DrawRotaGraph(LOGO_CENTER_X + 150, LOGO_CENTER_Y + 110, taSize, 0, IMAGE_ID("data/images/modeSelect/time.png"), true);
		DrawRotaGraph(LOGO_CENTER_X - 150, LOGO_CENTER_Y, rcLogoSize, 0, IMAGE_ID("data/images/modeSelect/raceLogo.png"), true);
		DrawRotaGraph(LOGO_CENTER_X - 150, LOGO_CENTER_Y + 110, rcSize, 0, IMAGE_ID("data/images/modeSelect/race.png"), true);

		DrawRotaGraph(SCREEN_SIZE_X - 70, SCREEN_SIZE_Y - 20, backSize, 0, IMAGE_ID("data/images/modeSelect/back2.png"), true);

		if (KeyMng::GetInstance().trgKey[P1_RIGHT])
		{
			nextMode = 1;
			if (lrdFlag == 0)
			{
				mode = 1;
				lrdFlag = mode;
			}
			else
			{
				lrdFlag = 1;
			}
		}
		if (KeyMng::GetInstance().trgKey[P1_LEFT])
		{
			nextMode = 2;
			if (lrdFlag == 0)
			{
				mode = 2;
				lrdFlag = mode;
			}
			else
			{
				lrdFlag = 2;
			}
		}
		if (KeyMng::GetInstance().trgKey[P1_DOWN])
		{
			nextMode = 3;
			if (lrdFlag == 0)
			{
				mode = 3;
				lrdFlag = mode;
			}
			else
			{
				lrdFlag = 3;
			}
		}

		if (lrdFlag != mode)
		{
			if (hitCheck(endPoint, miniPlanePos, 1.0f, 1.0f))
			{
				mode = lrdFlag;
			}
		}

		if (beforeMode != mode)
		{
			if (mode == 1)
			{
				pointCount = 4;
			}
			if (mode == 2)
			{
				pointCount = 0;
			}
			if (mode == 3)
			{

			}
		}
	}
	else
	{
		flashCnt++;
		if (mode == 1)
		{
			if ((flashCnt / 5) % 2 == 0)
			{
				DrawRotaGraph(LOGO_CENTER_X + 150, LOGO_CENTER_Y, taLogoSize, 0, IMAGE_ID("data/images/modeSelect/timeLogo.png"), true);
				DrawRotaGraph(LOGO_CENTER_X + 150, LOGO_CENTER_Y + 110, taSize, 0, IMAGE_ID("data/images/modeSelect/time.png"), true);
			}

			DrawRotaGraph(LOGO_CENTER_X - 150, LOGO_CENTER_Y, rcLogoSize, 0, IMAGE_ID("data/images/modeSelect/raceLogo.png"), true);
			DrawRotaGraph(LOGO_CENTER_X - 150, LOGO_CENTER_Y + 110, rcSize, 0, IMAGE_ID("data/images/modeSelect/race.png"), true);

			DrawRotaGraph(SCREEN_SIZE_X - 70, SCREEN_SIZE_Y - 20, backSize, 0, IMAGE_ID("data/images/modeSelect/back2.png"), true);
		}
		else if (mode == 2)
		{
			if ((flashCnt / 5) % 2 == 0)
			{
				DrawRotaGraph(LOGO_CENTER_X - 150, LOGO_CENTER_Y, rcLogoSize, 0, IMAGE_ID("data/images/modeSelect/raceLogo.png"), true);
				DrawRotaGraph(LOGO_CENTER_X - 150, LOGO_CENTER_Y + 110, rcSize, 0, IMAGE_ID("data/images/modeSelect/race.png"), true);
			}
			DrawRotaGraph(LOGO_CENTER_X + 150, LOGO_CENTER_Y, taLogoSize, 0, IMAGE_ID("data/images/modeSelect/timeLogo.png"), true);
			DrawRotaGraph(LOGO_CENTER_X + 150, LOGO_CENTER_Y + 110, taSize, 0, IMAGE_ID("data/images/modeSelect/time.png"), true);

			DrawRotaGraph(SCREEN_SIZE_X - 70, SCREEN_SIZE_Y - 20, backSize, 0, IMAGE_ID("data/images/modeSelect/back2.png"), true);
		}
		else if (mode == 3)
		{
			if ((flashCnt / 5) % 2 == 0)
			{
				DrawRotaGraph(SCREEN_SIZE_X - 70, SCREEN_SIZE_Y - 20, backSize, 0, IMAGE_ID("data/images/modeSelect/back2.png"), true);
			}
			DrawRotaGraph(LOGO_CENTER_X - 150, LOGO_CENTER_Y, rcLogoSize, 0, IMAGE_ID("data/images/modeSelect/raceLogo.png"), true);
			DrawRotaGraph(LOGO_CENTER_X - 150, LOGO_CENTER_Y + 110, rcSize, 0, IMAGE_ID("data/images/modeSelect/race.png"), true);
			DrawRotaGraph(LOGO_CENTER_X + 150, LOGO_CENTER_Y, taLogoSize, 0, IMAGE_ID("data/images/modeSelect/timeLogo.png"), true);
			DrawRotaGraph(LOGO_CENTER_X + 150, LOGO_CENTER_Y + 110, taSize, 0, IMAGE_ID("data/images/modeSelect/time.png"), true);
		}
	}

	miniPlaneCtrl();
	if (nextMode == 1)
	{
		taLogoSize = 0.8f;
		taSize = 0.5f;
		rcLogoSize = 0.7f;
		rcSize = 0.4f;
		backSize = 0.7f;
	}
	else if (nextMode == 2)
	{
		rcLogoSize = 0.8f;
		rcSize = 0.5f;
		taLogoSize = 0.7f;
		taSize = 0.4f;
		backSize = 0.7f;
	}
	else if(nextMode == 3)
	{
		rcLogoSize = 0.7f;
		rcSize = 0.4f;
		taLogoSize = 0.7f;
		taSize = 0.4f;
		backSize = 0.78f;
	}

	if (mode == 1)
	{
		startPoint = VECTOR2(box[4].x , box[4].y);
		endPoint = VECTOR2(box[7].x , box[7].y);

		DrawBox(miniPlanePos.x - miniSize.x / 2, miniPlanePos.y - miniSize.y / 2, miniPlanePos.x + miniSize.x / 2, miniPlanePos.y + miniSize.y / 2, 0xff0000, false);

		if (!moveFlag)
		{
			nextPoint = box[pointCount];
			miniToNextVec = nextPoint - miniPlanePos;
			miniToNextVec = miniToNextVec.Normalize();

			miniPlanePos.x += miniToNextVec.x * 5.0f;
			miniPlanePos.y += miniToNextVec.y * 5.0f;

			if (hitCheck(nextPoint, miniPlanePos, 1.0f, 1.0f))
			{
				if (!beforeHitFlag)
				{
					beforeHitFlag = true;
					pointCount++;

					if (pointCount >= 8)
					{
						pointCount = 4;
					}
				}
			}
			else
			{
				beforeHitFlag = false;
			}
		}
	}
	else if (mode == 2)
	{
		startPoint = VECTOR2(box[0].x , box[0].y);
		endPoint = VECTOR2(box[2].x , box[2].y);

		if (!moveFlag)
		{
			nextPoint = box[pointCount];
			miniToNextVec = nextPoint - miniPlanePos;
			miniToNextVec = miniToNextVec.Normalize();

			miniPlanePos.x += miniToNextVec.x * 5.0f;
			miniPlanePos.y += miniToNextVec.y * 5.0f;

			if (hitCheck(nextPoint, miniPlanePos, 1.0f, 1.0f))
			{
				if (!beforeHitFlag)
				{
					beforeHitFlag = true;
					pointCount++;

					if (pointCount >= 4)
					{
						pointCount = 0;
					}
				}
			}
			else
			{
				beforeHitFlag = false;
			}
		}
	}
	else if (mode == 3)
	{
		startPoint = VECTOR2(SCREEN_SIZE_X / 2, -50.0f);
	}
	Share::GetInstance().SetMenuPos(miniPlanePos);
	Share::GetInstance().SetMenuAngle(miniPlaneAngle);
}

void GameTask::RaceStartCount()
{

	if (_raceStart._startFlag)
	{
		return;
	}
	else
	{
		if (_raceStart._startCnt > 0)
		{
			_raceStart._efectCnt += (_raceStart._efectCnt < 255 ? 1 : 0);

			if (_raceStart._efectCnt >= 255)
			{
				_raceStart._raceCnt++;

				if (_raceStart._raceCnt % 3 == 2)
				{
					_raceStart._startCnt -= (_raceStart._startCnt > 0 ? 1 : 0);
					_raceStart._efectCnt = 0;
				}
			}
		}

	}
	if (_raceStart._startCnt <= 0)
	{
		_raceStart._efectCnt -= (_raceStart._efectCnt > 0 ? 1 : 0);
		_raceStart._startFlag = true;
	}
}