#include <future>
#include "GameTask.h"
#include "DxLib.h"
#include "KeyMng.h"
#include "MapControl.h"
#include "Player.h"

GameTask* GameTask::s_Instance = nullptr;

GameTask::GameTask()
{
}

GameTask::~GameTask()
{
}

void GameTask::Create()
{
	if (!s_Instance)
	{
		s_Instance = new GameTask();
	}
}

int GameTask::SystemInit()
{
	SetWindowText("F-ZERO");
	SetGraphMode(SCREEN_SIZE_X, SCREEN_SIZE_Y, 16);
	ChangeWindowMode(true);
	if (DxLib_Init() == -1) {
		return -1;
	}
	SetDrawScreen(DX_SCREEN_BACK);
	GameInit();
	return 0;
}

void GameTask::Update()
{
	KeyMng::GetInstance().Update();
	
	if (updateMode != G_MAIN)
	{
		ClsDrawScreen();
		(this->*gtskPtr[updateMode])();
		ScreenFlip();
	}
	else
	{
		(this->*gtskPtr[updateMode])();
	}
}

void GameTask::GameInit()
{
	DrawString(10, 10, "INIT", 0xff0000);
	updateMode = G_TITLE;
}

void GameTask::GameTitle()
{
	DrawString(10, 10, "TITLE", 0xffffff);
	if (KeyMng::GetInstance().trgKey[P1_ENTER])
	{
		updateMode = G_MENU;
	}
}

void GameTask::GameMenu()
{
	DrawString(10, 10, "MENU", 0xffffff);
	if (KeyMng::GetInstance().trgKey[P1_ENTER])
	{
		updateMode = G_MAIN;
	}
}

void GameTask::GameMain()
{	
	//����(Obj�Ƃ��ł܂Ƃ߂�)
	if (mc.empty())
	{
		mc.push_back(std::make_shared <MapControl>());
	}

	for (auto i : mc)
	{
		(*i).Key();
		(*i).Perspective();
		(*i).Draw();
	}

	DrawString(10, 10, "MAIN", 0xffffff);

	if (KeyMng::GetInstance().trgKey[P1_ENTER])
	{
		updateMode = G_RESULT;
	}
}

void GameTask::GameResult()
{
	DrawString(10, 10, "RESULT", 0xffffff);
	if (KeyMng::GetInstance().trgKey[P1_ENTER])
	{
		updateMode = G_INIT;
	}
}
