#include <future>
#include "GameTask.h"
#include "DxLib.h"
#include "KeyMng.h"
#include "MapControl.h"
#include "Player.h"
#include "BgControl.h"
#include "Share.h"
#include "VECTOR2.h"

GameTask* GameTask::s_Instance = nullptr;

GameTask::GameTask()
{
}

GameTask::~GameTask()
{
}

void GameTask::Create()
{
	if (!s_Instance)
	{
		s_Instance = new GameTask();
	}
}

int GameTask::SystemInit()
{
	SetWindowText("F-ZERO");
	SetGraphMode(SCREEN_SIZE_X, SCREEN_SIZE_Y, 16);
	ChangeWindowMode(true);
	if (DxLib_Init() == -1) {
		return -1;
	}
	SetDrawScreen(DX_SCREEN_BACK);
	GameInit();
	return 0;
}

void GameTask::Update()
{
	KeyMng::GetInstance().Update();
	
	if (updateMode != G_MAIN)
	{
		ClsDrawScreen();
		(this->*gtskPtr[updateMode])();
		ScreenFlip();
	}
	else
	{
		(this->*gtskPtr[updateMode])();

	}
}

void GameTask::GameInit()
{
	DrawString(10, 10, "INIT", 0xff0000);
	updateMode = G_TITLE;
}


void GameTask::GameTitle()
{
	DrawString(10, 10, "TITLE", 0xffffff);

	auto isPointCheck = [&](VECTOR2 p, VECTOR2 l1, VECTOR2 l2)
	{
		int d;
		if (l1.x > l2.x) {
			d = l1.x;
			l1.x = l2.x;
			l2.x = d;
			d = l1.y;
			l1.y = l2.y;
			l2.y = d;
		}
		auto check1 = l1.x <= p.x && p.x <= l2.x;
		auto check2 = ((l1.y <= l2.y && l1.y <= p.y && p.y <= l2.y) || (l1.y > l2.y && l2.y <= p.y && p.y <= l1.y));
		auto check3 = (p.y - l1.y)*(l2.x - l1.x) == (l2.y - l1.y)*(p.x - l1.x);
		return check1 && check2 && check3;
	};

	auto getPoint = [&](float t, VECTOR2 v1, VECTOR2 v2, VECTOR2 v3) {
		float tp = 1 - t;
		VECTOR2 vec;
		vec.x = t * t*v3.x + 2 * t*tp*v2.x + tp * tp*v1.x;
		vec.y = t * t*v3.y + 2 * t*tp*v2.y + tp * tp*v1.y;
		return vec;
	};

	(Bswitch ? --timeCnt : ++timeCnt);

	int Mx, My;
	GetMousePoint(&Mx, &My);

	VECTOR2 line1 = { 100,300 };
	VECTOR2 line2 = { 400,230 };

	VECTOR2 p = { (float)Mx,(float)My };

	auto vec = (p - line1) / 100;

	auto vecP = (line2 - p) / 100;

	auto pos = line1;
	auto posP = p;
	auto posB = pos;

	pos = pos + (vec * timeCnt);
	posP = posP + (vecP * timeCnt);

	auto vecB = (posP - pos) / 100;
	posB = posB + (vecB * timeCnt);

	if (timeCnt > 100)
	{
		/*pos = line1;
		posP = p;
		timeCnt = 0;*/
		Bswitch = true;
	}

	if (timeCnt < 0)
	{
		Bswitch = false;
	}

	float t = timeCnt * 0.01f;
	VECTOR2 point = { 0,0 };
	point = getPoint(t, line1, p, line2);


	DrawLine(line1.x, line1.y, line2.x, line2.y, 0xffffff);

	DrawCircle(pos.x, pos.y, 5, 0xffffff);
	DrawCircle(posP.x, posP.y, 5, 0xffffff);

	DrawCircle(point.x, point.y, 5, 0x0000ff);


	auto color = 0xff0000;

	if (isPointCheck(VECTOR2(Mx, My), line1, line2))
	{
		color = 0x0000ff;
	}
	DrawCircle(Mx, My, 5, color);


	if (KeyMng::GetInstance().trgKey[P1_ENTER])
	{
		updateMode = G_MENU;
	}
}

void GameTask::GameMenu()
{
	DrawString(10, 10, "MENU", 0xffffff);
	if (KeyMng::GetInstance().trgKey[P1_ENTER])
	{
		updateMode = G_MAIN;
	}
}

void GameTask::GameMain()
{	
	//����(Obj�Ƃ��ł܂Ƃ߂�)
	if (mc.empty())
	{
		mc.push_back(std::make_shared <MapControl>());
	}
	if (bg.empty())
	{
		bg.push_back(std::make_shared <BgControl>());
	}

	for (auto i : mc)
	{
		(*i).Key();
		(*i).Perspective();
		(*i).Update();
		(*i).Draw();

		if ((*i).GetClearCheck())
		{
			updateMode = G_RESULT;
		}
	}

	for (auto i : bg)
	{
		(*i).Update();
		(*i).Draw();
	}

	DrawString(10, 10, "MAIN", 0xffffff);

	/*if (KeyMng::GetInstance().trgKey[P1_ENTER])
	{
		updateMode = G_RESULT;
	}*/
}

void GameTask::GameResult()
{
	DrawString(10, 10, "RESULT", 0xffffff);

	DrawGraph(0, 0, _resultHandle, true);
	if (KeyMng::GetInstance().trgKey[P1_ENTER])
	{
		updateMode = G_INIT;
	}
}
