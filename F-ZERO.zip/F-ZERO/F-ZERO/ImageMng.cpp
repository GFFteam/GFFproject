#include "DxLib.h"
#include "ImageMng.h"
#include <assert.h>
#include "VECTOR3.h"
const int& ImageMng::SetImage(string imagePath)
{
	// �摜������
	if (mp.find(imagePath) == mp.end())
	{
		mp[imagePath] = LoadGraph(imagePath.c_str());
	}
	return mp[imagePath];
}


const std::vector<int>& ImageMng::SetImage(string imagePath, VECTOR3 divSize, VECTOR3 divNum)
{
	if (_imgDivMap.find(imagePath) == _imgDivMap.end())
	{
		//���I�ȗv�f����ݒ�(vector�^�z��)
		_imgDivMap[imagePath].resize(divNum.x*divNum.y);

		LoadDivGraph(imagePath.c_str(), divNum.x*divNum.y,
			divNum.x, divNum.y,
			divSize.x, divSize.y,
			&_imgDivMap[imagePath][0], true);
	}
	return _imgDivMap[imagePath];
}

const map<string, std::vector<int>>& ImageMng::GetDivMap()
{
	return _imgDivMap;
}

