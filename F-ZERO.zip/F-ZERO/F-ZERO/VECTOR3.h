#pragma once
#include <cmath>
#include <vector>
class VECTOR3
{
public:
	float x, y, z;

	std::vector<float> vec;
	VECTOR3();
	VECTOR3(float x1, float y1) : x(x1), y(y1)
	{
		vec.emplace_back(x);
		vec.emplace_back(y);
	};
	VECTOR3(float x1, float y1, float z1) : x(x1), y(y1), z(z1)
	{
		vec.emplace_back(x);
		vec.emplace_back(y);
		vec.emplace_back(z);
	};

	~VECTOR3();

	VECTOR3 operator+=(const VECTOR3&);
	VECTOR3 operator-=(const VECTOR3&);
	VECTOR3 operator*=(const float&);

	// �Εӂ����߂�
	float Magnitude()const
	{
		return sqrt(x * x + y * y + z * z);
	}

	//���K��
	VECTOR3 Normalize()const
	{
		auto len = Magnitude();
		return VECTOR3(x / len, y / len, z / len);
	}

};
VECTOR3 operator*(const VECTOR3&, const float&);
VECTOR3 operator/(const VECTOR3&, const float&);
VECTOR3 operator-(const VECTOR3&, const VECTOR3&);
VECTOR3 operator+(const VECTOR3&, const VECTOR3&);


