#include "Button.h"
#include "DxLib.h"


Button::Button()
{
}

Button::Button(std::string name, VECTOR2 pos, VECTOR2 size) : _pos(pos), _size(size)
{
	_name = name;
}


Button::~Button()
{
}

void Button::Update()
{
}

void Button::Draw(unsigned int color)
{
	DrawBox(_pos.x, _pos.y, _pos.x + _size.x, _pos.y + _size.y, color, true);
	DrawString(_pos.x,_pos.y, _name.c_str(), 0x000000);
}

void Button::AddPos(VECTOR2 vec)
{
	_pos.x += vec.x;
	_pos.y += vec.y;
}

void Button::SetPos(VECTOR2 pos)
{
	_pos = pos;
}

void Button::SetPosForX(int x, int size)
{
	_pos.x = x - size;
}

bool Button::GetHitCheck(VECTOR2 pos)
{
	if (pos.x > _pos.x && pos.x < _pos.x + _size.x)
	{
		if (pos.y > _pos.y && pos.y < _pos.y + _size.y)
		{
			return true;
		}
	}

	return false;
}

const std::string & Button::GetString()
{
	return _name;
}

const VECTOR2 & Button::GetPos()
{
	return _pos;
}
