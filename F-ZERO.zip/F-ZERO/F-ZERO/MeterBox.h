#pragma once
#include <vector>
#include <memory>

#include "VECTOR2.h"

class Button;

class MeterBox
{
public:
	MeterBox();
	MeterBox(VECTOR2 p, VECTOR2 s, float l);

	~MeterBox();

	bool Init();
	void Update(VECTOR2 pos);
	void Draw();

	const int& GetCnt()const;

private:
	VECTOR2 _pos;
	VECTOR2 _size;

	float _length;
	int _setCnt = 0;
	int _standardCnt = 0;

	std::vector<std::shared_ptr<Button>> _button;
};

