#pragma once
#include "VECTOR2.h"
#include "GameTask.h"
class Player
{
public:
	Player();
	~Player();
	void Init();
	void Update();
	void Draw();

private:

	struct player {
		float angle = 0.0f;
		float size = 0.25f;
		VECTOR2 pos = { SCREEN_SIZE_X / 2,SCREEN_SIZE_Y / 2 };
	};
	player pl;

	int base;
	int gw, gh;
};

