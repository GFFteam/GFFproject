#pragma once
#include "VECTOR2.h"

class Share
{
public:
	Share();
	~Share();

	static void Create();
	static Share& GetInstance()
	{
		Create();
		return *s_Instance;
	}

	int GetLRFlag();
	void SetLRFlag(int);

	float GetSpeed();
	void SetSpeed(float);

	float GetThrottleParcent();
	void SetThrottleParcent(float);

	float GetBrakeParcent();
	void SetBrakeParcent(float);

	float GetYawPercent();
	void SetYawPercent(float);

	float GetFuel();
	void SetFuel(float);
	
	VECTOR2 GetMapMove();
	void SetMapMove(float,float);

private:
	static Share* s_Instance;
	
	int lrFlag;
	float speed;

	float throttle;
	float brake;
	float fuel;

	float yaw;

	VECTOR2 mapMove;
};

