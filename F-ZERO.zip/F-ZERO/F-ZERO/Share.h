#pragma once
#include "VECTOR2.h"

constexpr unsigned int cutCnt = 4;

enum class Curve
{
	NON,
	Straight,
	Curve_Left,
	Curve_Right,
	Curve_MAX,
};

enum class AI
{
	NON,
	NORMAL,
	WEEK,
	STRONG,
};

class Share
{
public:
	Share();
	~Share();

	static void Create();
	static Share& GetInstance()
	{
		Create();
		return *s_Instance;
	}

	int GetLRFlag();
	void SetLRFlag(int);

	float GetSpeed();
	void SetSpeed(float);

	float GetThrottleParcent();
	void SetThrottleParcent(float);

	float GetBrakeParcent();
	void SetBrakeParcent(float);

	float GetYawPercent();
	void SetYawPercent(float);

	float GetFuel();
	void SetFuel(float);

	VECTOR2 GetMapMove();
	void SetMapMove(float, float);

	VECTOR2 GetPlayerPos();
	void SetPlayerPos(float, float);

	VECTOR2 GetEnemyPos();
	void SetEnemyPos(float, float);

	VECTOR2 GetEnemyVec();
	void SetEnemyVec(VECTOR2);

	bool GetHitCheck();
	void SetHitCheck(bool);

	bool GetEnemyHitCheck();
	void SetEnemyHitCheck(bool);


	VECTOR2 GetMapCenter();
	void SetMapCenter(float,float);

	const bool& GetChangeFlag();
	void SetChangeFlag(bool flag);

	const VECTOR2& GetMapOffset();
	void SetMapOffset(VECTOR2 size);

	const VECTOR2& GetMiniPos();
	void SetMiniPos(VECTOR2 pos);

	const VECTOR2& GetStartPos();
	void SetStartPos(VECTOR2 pos);

	const int& GetRapCnt();
	void SetRapCnt(int pos);

	const Curve& GetCurveCheck();
	void SetCurveCheck(Curve curve);

	const AI& GetAICheck();
	void SetAICheck(AI ai);

	float GetPlayerRollAngle();

	void SetPlayerRollAngle(float rot);

	bool GetEnemyImageCheck();
	void SetEnemyImageCheck(bool flag);

	float GetDistance();
	void SetDistance(float d);

	VECTOR2 GetDistanceXY();
	void SetDistanceXY(VECTOR2 v);

	const float& GetAngle();
	void SetAngle(float a);

	const VECTOR2& GetVelocity();
	void SetVelocity(VECTOR2 vel);

	const VECTOR2& GetReflect();
	void SetReflect(VECTOR2 ref);

	float GetMapRotAngle();
	void SetMapRotAngle(float);

	VECTOR2 GetScreenPlayerPos();
	void SetScreenPlayerPos(VECTOR2);

	int GetBackGroundYPos();
	void SetBackGroundYpos(int);

	VECTOR2 GetScreenEnemyPos();
	void SetScreenEnemyPos(VECTOR2);

	VECTOR2 GetHitReactionMove();
	void SetHitReactionMove(VECTOR2);

	VECTOR2 GetMenuPos();
	void SetMenuPos(VECTOR2);

	float GetMenuAngle();
	void SetMenuAngle(float);

private:
	static Share* s_Instance;

	int lrFlag;
	float speed;

	float throttle;
	float brake;
	float fuel;
	float yaw;
	float rotate;

	VECTOR2 mapMove;

	VECTOR2 playerPos;
	VECTOR2 enemyPos;
	VECTOR2 enemyVec;
	VECTOR2 _startPos;
	VECTOR2 _miniPlayerPos;

	bool check = false;
	bool _eHitCheck = false;

	bool _changeFlag = false;
	int _rapCnt = 0;
	VECTOR2 _mapOffset = { 0,0 };

	VECTOR2 mapCenter;
	VECTOR2 plVelocity;
	VECTOR2 plReflect;
	VECTOR2 distanceXY;

	VECTOR2 screenPlayerPos;

	VECTOR2 screenEnemyPos;

	VECTOR2 reactionMove;

	VECTOR2 menuPos;
	float menuAngle;
	int smokeAlpha;

	Curve _curve;
	AI _ai;

	bool enemyImageCheck = false;
	float distance = 0.0f;
	float angle = 0.0f;

	float rotMapAngle;

	int bgYPos;
};

