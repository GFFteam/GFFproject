#pragma once
#include "VECTOR2.h"

constexpr unsigned int cutCnt = 4;

class Share
{
public:
	Share();
	~Share();

	static void Create();
	static Share& GetInstance()
	{
		Create();
		return *s_Instance;
	}

	int GetLRFlag();
	void SetLRFlag(int);

	float GetSpeed();
	void SetSpeed(float);

	float GetThrottleParcent();
	void SetThrottleParcent(float);

	float GetBrakeParcent();
	void SetBrakeParcent(float);

	float GetYawPercent();
	void SetYawPercent(float);

	float GetFuel();
	void SetFuel(float);

	VECTOR2 GetMapMove();
	void SetMapMove(float, float);

	VECTOR2 GetPlayerPos();
	void SetPlayerPos(float, float);

	bool GetHitCheck();
	void SetHitCheck(bool);

	VECTOR2 GetMapCenter();
	void SetMapCenter(float,float);

	VECTOR2 GetMiniMapSize();
	void SetMiniMapSize(float,float);

	const VECTOR2& GetMiniMapPos();
	void SetMiniMapPos(VECTOR2 pos);

private:
	static Share* s_Instance;

	int lrFlag;
	float speed;

	float throttle;
	float brake;
	float fuel;
	float yaw;

	VECTOR2 mapMove;

	VECTOR2 playerPos;
	VECTOR2 _miniPlayerPos;

	bool check = false;

	VECTOR2 mapCenter;

	VECTOR2 miniMap;
};

