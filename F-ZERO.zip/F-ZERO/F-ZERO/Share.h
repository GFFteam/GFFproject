#pragma once

class Share
{
public:
	Share();
	~Share();

	static void Create();
	static Share& GetInstance()
	{
		Create();
		return *s_Instance;
	}

	int GetLRFlag();
	void SetLRFlag(int);

private:
	static Share* s_Instance;
	
	int lrFlag;
};

