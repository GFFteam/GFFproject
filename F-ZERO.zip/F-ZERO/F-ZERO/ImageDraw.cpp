#include "ImageDraw.h"
#include "GameTask.h"
#include <DxLib.h>
#include "AffineTransformation.h"

ImageDraw::ImageDraw(VECTOR3 pos, VECTOR3 offset, VECTOR3 size, int handle)
{
	//auto M = Matrix(VECTOR3(5, 1, 6), VECTOR3(7, 7, 7), VECTOR3(5, 4, 6));

	_image.pos.x = pos.x;
	_image.pos.y = pos.y;
	_image.pos.z = pos.z;
	_startPos = _image.pos;
	_image.size = size;
	_offset = offset;

	_image.handle = LoadGraph("image/TestMap.png");
	/*for (int y = 0; y < 16; y++)
	{

		for (int x = 0; x < 16; x++)
		{

			_image.handle.emplace_back(handle);
		}
	}*/

	_mat = std::make_unique<AffineTransformation>(_image.pos);
	/*mat->Translation(10.0f, 5.0f);
	mat->TranslationAdd(2.0f, 2.0f);
	auto v = mat->GetVector();*/

}


ImageDraw::~ImageDraw()
{
}

void ImageDraw::Key()
{
	//�ړ�
	if (CheckHitKey(KEY_INPUT_UP))
	{
		_mat->TranslationAdd(0, -2.0f);
	}
	if (CheckHitKey(KEY_INPUT_DOWN))
	{
		_mat->TranslationAdd(0, 2.0f);
	}
	if (CheckHitKey(KEY_INPUT_LEFT))
	{
		_mat->TranslationAdd(-2.0f, 0);
		//_offset.x -= 2;
	}
	if (CheckHitKey(KEY_INPUT_RIGHT))
	{

		_mat->TranslationAdd(2.0f, 0);
		//_offset.x += 2;
	}
	if (CheckHitKey(KEY_INPUT_R))
	{
		_image.angle += 2.0f;
	}
	//�g�k
	if (CheckHitKey(KEY_INPUT_X))
	{
		_image.size.x++;
		_image.size.y++;
	}
	if (CheckHitKey(KEY_INPUT_C))
	{
		(_image.size.x > 0 ? _image.size.x-- : _image.size.x -= 0);
		(_image.size.y > 0 ? _image.size.y-- : _image.size.y -= 0);

	}
}

void ImageDraw::Update()
{
	_image.pos = _mat->GetVector();
	Key();
}

void ImageDraw::Draw()
{
	auto posValue = [&](const VECTOR3& pos, const float& angle) {
		VECTOR3 p;
		p = _mat->Rotation(VECTOR3(0,pos.y,pos.z),angle);
		p.x = pos.x;
		//p = _mat->GetVector();
		//p.x = pos.x;// *cos(angle) - pos.z * sin(angle);
		//p.y = pos.z * sin(angle) + pos.y * cos(angle);
		//p.z = pos.z;
		return p;
	};


	//���� 
	auto leftUp = posValue(VECTOR3(_image.pos.x - _image.size.x / 2 , _image.pos.y - _image.size.y / 2, _image.pos.z), _image.angle);
	auto leftUpAngle = atan2(leftUp.x, leftUp.y) + 1.5f;

	//�E��
	auto rightUp = posValue(VECTOR3(_image.pos.x + _image.size.x / 2, _image.pos.y - _image.size.y / 2, _image.pos.z), _image.angle);
	auto rightUpAngle = atan2(rightUp.x, rightUp.y) + 1.5f;

	//�E��
	auto rightDown = posValue(VECTOR3(_image.pos.x + _image.size.x / 2, _image.pos.y + _image.size.y /2, _image.pos.z), _image.angle);
	auto rightDownAngle = atan2(rightDown.x, rightDown.y) + 1.5f;

	//����
	auto leftDown = posValue(VECTOR3(_image.pos.x - _image.size.x / 2, _image.pos.y + _image.size.y / 2, _image.pos.z), _image.angle);
	auto leftDownAngle = atan2(leftDown.x, leftDown.y) + 1.5f;


	auto p1 = leftUp;
	auto p2 = rightUp;
	auto p3 = rightDown;
	auto p4 = leftDown;

	//for (int y = 0; y < 4; ++y)
	//{
	//	auto v1 = posValue(_image.size, _image.angle);
	//	auto v2 = posValue(_image.size, _image.angle);
	//	auto v3 = posValue(_image.size, _image.angle);
	//	auto v4 = posValue(_image.size, _image.angle);

	//	for (int x = 0; x < 4; ++x)
	//	{
	//		DrawModiGraph(p1.x + _offset.x, p1.y + _offset.y,//����
	//			p2.x + _offset.x, p2.y + _offset.y,//�E��
	//			p3.x + _offset.x, p3.y + _offset.y,//�E��
	//			p4.x + _offset.x, p4.y + _offset.y,//����
	//			_image.handle[(y + 1) * x], true);

	//		p1.x += v1.x;
	//		p2.x += v2.x;
	//		p3.x += v3.x;
	//		p4.x += v4.x;

	//	}
	//	p1.x = leftUp.x;
	//	p2.x = rightUp.x;
	//	p3.x = rightDown.x;
	//	p4.x = leftDown.x;

	//	p1.y += v1.y;
	//	p2.y += v2.y;
	//	p3.y += v3.y;
	//	p4.y += v4.y;


	//}


	//�`����E�ʒu�Ȃ�`�悹��������
	if ((_image.size.x <= 0 && _image.size.y <= 0) || (_image.size.x >= 600 && _image.size.y >= 600))
	{
		return;
	}
	//DrawModiGraph(leftUp.x + _offset.x, leftUp.y + _offset.y,//����
	//	rightUp.x + _offset.x, rightUp.y + _offset.y,//�E��
	//	rightDown.x*2 + _offset.x, rightDown.y + _offset.y,//�E��
	//	leftDown.x*2 + _offset.x, leftDown.y + _offset.y,//����
	//	_image.handle, true);


	//DrawRotaGraph(_image.pos.x - _offset.x, _image.pos.y - _offset.y, _image.size, 0, _image.handle, true);
	//DrawRectRotaGraph(_image.pos.x + corX - _offset.x/2, _image.pos.y + corY - _offset.y/2, 0, 0, 64, 64, _image.size, 0, _image.handle, true);
}
