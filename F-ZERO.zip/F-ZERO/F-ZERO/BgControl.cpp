#include "BgControl.h"
#include "DxLib.h"
#include "GameTask.h"
#include "ResourceMng.h"
#include "Share.h"

BgControl::BgControl()
{
	GetGraphSize(IMAGE_ID("data/images/BackGround.png"),&gw,&gh);
}


BgControl::~BgControl()
{
}

void BgControl::Update()
{
	if (Share::GetInstance().GetLRFlag() == -1)
	{
		sclX++;
	}
	else if (Share::GetInstance().GetLRFlag() == 1)
	{
		sclX--;
	}
}

void BgControl::Draw()
{
	auto alpha = 255;
	for (int i = (SEP_NUM / 2); i < SEP_NUM; i++)
	{
		alpha -= 15;
		SetDrawBlendMode(DX_BLENDMODE_ALPHA, alpha);
		DrawRectGraph(-(gw / 2) + sclX, ((gh / SEP_NUM) * i) - 72, 0, (gh / SEP_NUM) * i, gw, (gh / SEP_NUM), IMAGE_ID("data/images/BackGround.png"), true,false);
	}
	SetDrawBlendMode(DX_BLENDMODE_NOBLEND, alpha);
}
