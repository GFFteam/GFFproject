#pragma once
#include "VECTOR2.h"
#include "GameTask.h"


constexpr int SPEED_CIRCLE_SCALE = 13;
constexpr int LEFT_TACHO_CENTER_X = SCREEN_SIZE_X / 2 - 95;
constexpr int LEFT_TACHO_CENTER_Y = SCREEN_SIZE_Y - 60;
constexpr int RIGHT_L_TACHO_CENTER_X = SCREEN_SIZE_X / 2 + 82;
constexpr int RIGHT_L_TACHO_CENTER_Y = SCREEN_SIZE_Y - 70;
constexpr int RIGHT_S_TACHO_CENTER_X = SCREEN_SIZE_X / 2 + 160;
constexpr int RIGHT_S_TACHO_CENTER_Y = SCREEN_SIZE_Y - 20;

class UI
{
public:
	UI();
	~UI();
	void Init();
	void Update();
	void RapTimeUpdate();
	void Draw();
	void RapTimeDraw();
private:
	int num[10];
	int speedNum[5];
	float speed;
	float circleSpeed = 0.0f;
	float throttlePct = 0.0f;
	float brakePct = 0.0f;
	float gBrake = 0.0f;
	float fuel;
	VECTOR2 gRand = { 0.0f,0.0f };
	VECTOR2 gSensor = { 0.0f ,0.0f };
	VECTOR2 gPos = { RIGHT_L_TACHO_CENTER_X ,RIGHT_L_TACHO_CENTER_Y};
	float gOffset = 0.7f;
	float gReturnCount = 0.0f;
	int sp1, sp10, sp100;
	int rap1_1, rap1_10;
	int rap10_1, rap10_10;
	int rap100_1, rap100_10;

	float rap1 = 0.0f;

	int _rapTime = 0;
	int lrFlag = 0;
	unsigned int _numberSize = 25;
};

