#pragma once
#include "VECTOR2.h"
#include "GameTask.h"


constexpr int SPEED_CIRCLE_SCALE = 13;
constexpr int LEFT_TACHO_CENTER_X = SCREEN_SIZE_X / 2 - 95;
constexpr int LEFT_TACHO_CENTER_Y = SCREEN_SIZE_Y - 60;
constexpr int RIGHT_L_TACHO_CENTER_X = SCREEN_SIZE_X / 2 + 82;
constexpr int RIGHT_L_TACHO_CENTER_Y = SCREEN_SIZE_Y - 70;
constexpr int RIGHT_S_TACHO_CENTER_X = SCREEN_SIZE_X / 2 + 160;
constexpr int RIGHT_S_TACHO_CENTER_Y = SCREEN_SIZE_Y - 20;

class UI
{
public:
	UI();
	~UI();
	void Init();
	void Update();
	void RapTimeUpdate();
	void Draw();
	void RapTimeDraw();
	void OutPutDraw();
	void HighScoreDraw();
	void SetRapValue();
	void StartUIDraw();
	void ResultUIDraw();
	const bool& GetSetValueFlag()
	{
		return _setValueFlag;
	}

private:
	int num[10];
	int speedNum[5];
	float speed;
	float circleSpeed = 0.0f;
	float throttlePct = 0.0f;
	float brakePct = 0.0f;
	float gBrake = 0.0f;
	float fuel;
	VECTOR2 gRand = { 0.0f,0.0f };
	VECTOR2 gSensor = { 0.0f ,0.0f };
	VECTOR2 gPos = { RIGHT_L_TACHO_CENTER_X ,RIGHT_L_TACHO_CENTER_Y};
	float gOffset = 0.7f;
	float gReturnCount = 0.0f;
	int sp1, sp10, sp100;

	struct RapTime
	{
		int rap1_1, rap1_10;
		int rap10_1, rap10_10;
		int rap100_1, rap100_10;
		float rap1 = 0.0f;
		int _rapTime = 0;
		int _setRapCnt = 1;
	};

	struct OutPutTime
	{
		//�~��
		float setCntm1 = 0.0f;
		float setCntm10 = 0.0f;
		//�b
		float setCnts1 = 0.0f;
		float setCnts10 = 0.0f;
		//��
		float setCntM1 = 0.0f;
		float setCntM10 = 0.0f;
		float _rapTimeValue = 0.0f; //���v�l

		std::vector<float> _rapValue;//�^�C���i�[

	};

	bool _setValueFlag = false;
	OutPutTime _output;
	OutPutTime _getData;

	RapTime _rap;
	int lrFlag = 0;
	unsigned int _numberSize = 25;
};

