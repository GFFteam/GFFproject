#pragma once
#include "GameTask.h"

constexpr int SPEED_CIRCLE_SCALE = 13;
constexpr int LEFT_TACHO_CENTER_X = SCREEN_SIZE_X / 2 - 95;
constexpr int LEFT_TACHO_CENTER_Y = SCREEN_SIZE_Y - 60;

class UI
{
public:
	UI();
	~UI();
	void Init();
	void Update();
	void Draw();
private:
	int num[10];
	int speedNum[5];
	float speed;
	float circleSpeed = 0.0f;
	int sp1, sp10, sp100;
};

