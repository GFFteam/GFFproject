#pragma once
#include <string>
#include <map>

#define IMAGE_ID(X) ResourceMng::GetInstance().SetImage(X)
#define SOUND_ID(X) ResourceMng::GetInstance().SetSound(X)

using namespace std;

class ResourceMng
{
public:
	static ResourceMng& GetInstance() {
		static ResourceMng resInst;
		return resInst;
	}
	const int& SetImage(string);		// �摜�o�^�AID��Ԃ�
	const int& SetSound(string);		// ���o�^�AID��Ԃ�
private:
	map<string,int>mp;
};

