#include "Share.h"

Share* Share::s_Instance = nullptr;

Share::Share()
{
	_curve = Curve::NON;
	_ai = AI::NORMAL;
}


Share::~Share()
{
}

void Share::Create()
{
	if (!s_Instance)
	{
		s_Instance = new Share();
	}
}

int Share::GetLRFlag()
{
	return lrFlag;
}

void Share::SetLRFlag(int flag)
{
	lrFlag = flag;
}

float Share::GetSpeed()
{
	return speed;
}

void Share::SetSpeed(float sp)
{
	speed = sp;
}

float Share::GetThrottleParcent()
{
	return throttle;
}

void Share::SetThrottleParcent(float th)
{
	throttle = th;
}

float Share::GetBrakeParcent()
{
	return brake;
}

void Share::SetBrakeParcent(float br)
{
	brake = br;
}

float Share::GetYawPercent()
{
	return yaw;
}

void Share::SetYawPercent(float y)
{
	yaw = y;
}

float Share::GetFuel()
{
	return fuel;
}

void Share::SetFuel(float fu)
{
	fuel = fu;
}

VECTOR2 Share::GetMapMove()
{
	return mapMove;
}

void Share::SetMapMove(float x,float y)
{
	mapMove.x = x;
	mapMove.y = y;
}

VECTOR2 Share::GetPlayerPos()
{
	return playerPos;
}

void Share::SetPlayerPos(float x, float y)
{
	playerPos.x = x;
	playerPos.y = y;
}

VECTOR2 Share::GetEnemyPos()
{
	return enemyPos;
}

void Share::SetEnemyPos(float x, float y)
{
	enemyPos.x = x;
	enemyPos.y = y;
}

VECTOR2 Share::GetEnemyVec()
{
	return enemyVec;
}

void Share::SetEnemyVec(VECTOR2 vec)
{
	enemyVec = vec;
}

bool Share::GetHitCheck()
{
	return check;
}

void Share::SetHitCheck(bool c)
{
	check = c;
}

bool Share::GetEnemyHitCheck()
{
	return _eHitCheck;
}

void Share::SetEnemyHitCheck(bool flag)
{
	_eHitCheck = flag;
}

VECTOR2 Share::GetMapCenter()
{
	return mapCenter;
}

void Share::SetMapCenter(float x, float z)
{
	mapCenter.x = x;
	mapCenter.y = z;
}

const bool & Share::GetChangeFlag()
{
	return _changeFlag;
}

void Share::SetChangeFlag(bool flag)
{
	_changeFlag = flag;
}

const VECTOR2 & Share::GetMapOffset()
{
	return _mapOffset;
}

void Share::SetMapOffset(VECTOR2 size)
{
	_mapOffset = size;
}

const VECTOR2 & Share::GetMiniPos()
{
	return _miniPlayerPos;
}

void Share::SetMiniPos(VECTOR2 pos)
{
	_miniPlayerPos = pos;
}

const VECTOR2 & Share::GetStartPos()
{
	return _startPos;
}

void Share::SetStartPos(VECTOR2 pos)
{
	_startPos = pos;
}

const int & Share::GetRapCnt()
{
	return _rapCnt;
}

void Share::SetRapCnt(int pos)
{
	_rapCnt = pos;
}

const Curve & Share::GetCurveCheck()
{
	return _curve;
}

void Share::SetCurveCheck(Curve curve)
{
	_curve = curve;
}

const AI & Share::GetAICheck()
{
	return _ai;
}

void Share::SetAICheck(AI ai)
{
	_ai = ai;
}

float Share::GetPlayerRollAngle()
{
	return rotate;
}

void Share::SetPlayerRollAngle(float rot)
{
	rotate = rot;
}

bool Share::GetEnemyImageCheck()
{
	return enemyImageCheck;
}

void Share::SetEnemyImageCheck(bool flag)
{
	enemyImageCheck = flag;
}

float Share::GetDistance()
{
	return distance;
}

void Share::SetDistance(float d)
{
	distance = d;
}

VECTOR2 Share::GetDistanceXY()
{
	return distanceXY;
}

void Share::SetDistanceXY(VECTOR2 v)
{
	distanceXY = v;
}

const float & Share::GetAngle()
{
	return angle;
}

void Share::SetAngle(float a)
{
	angle = a;
}

const VECTOR2 & Share::GetVelocity()
{
	return plVelocity;
}

void Share::SetVelocity(VECTOR2 vel)
{
	plVelocity = vel;
}

const VECTOR2 & Share::GetReflect()
{
	return plReflect;
}

void Share::SetReflect(VECTOR2 ref)
{
	plReflect = ref;
}

float Share::GetMapRotAngle()
{
	return rotMapAngle;
}

void Share::SetMapRotAngle(float angle)
{
	rotMapAngle = angle;
}

VECTOR2 Share::GetScreenPlayerPos()
{
	return screenPlayerPos;
}

void Share::SetScreenPlayerPos(VECTOR2 pos)
{
	screenPlayerPos = pos;
}

int Share::GetBackGroundYPos()
{
	return bgYPos;
}

void Share::SetBackGroundYpos(int y)
{
	bgYPos = y;
}

VECTOR2 Share::GetScreenEnemyPos()
{
	return screenEnemyPos;
}

void Share::SetScreenEnemyPos(VECTOR2 v)
{
	screenEnemyPos = v;
}

VECTOR2 Share::GetHitReactionMove()
{
	return reactionMove;
}

void Share::SetHitReactionMove(VECTOR2 v)
{
	reactionMove = v;
}

VECTOR2 Share::GetMenuPos()
{
	return menuPos;
}

void Share::SetMenuPos(VECTOR2 pos)
{
	menuPos = pos;
}

float Share::GetMenuAngle()
{
	return menuAngle;
}

void Share::SetMenuAngle(float angle)
{
	menuAngle = angle;
}

