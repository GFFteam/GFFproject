#include "Share.h"

Share* Share::s_Instance = nullptr;

Share::Share()
{
}


Share::~Share()
{
}

void Share::Create()
{
	if (!s_Instance)
	{
		s_Instance = new Share();
	}
}

int Share::GetLRFlag()
{
	return lrFlag;
}

void Share::SetLRFlag(int flag)
{
	lrFlag = flag;
}

float Share::GetSpeed()
{
	return speed;
}

void Share::SetSpeed(float sp)
{
	speed = sp;
}

float Share::GetThrottleParcent()
{
	return throttle;
}

void Share::SetThrottleParcent(float th)
{
	throttle = th;
}

float Share::GetBrakeParcent()
{
	return brake;
}

void Share::SetBrakeParcent(float br)
{
	brake = br;
}

float Share::GetYawPercent()
{
	return yaw;
}

void Share::SetYawPercent(float y)
{
	yaw = y;
}

float Share::GetFuel()
{
	return fuel;
}

void Share::SetFuel(float fu)
{
	fuel = fu;
}

VECTOR2 Share::GetMapMove()
{
	return mapMove;
}

void Share::SetMapMove(float x,float y)
{
	mapMove.x = x;
	mapMove.y = y;
}

VECTOR2 Share::GetPlayerPos()
{
	return playerPos;
}

void Share::SetPlayerPos(float x, float y)
{
	playerPos.x = x;
	playerPos.y = y;
}

bool Share::GetHitCheck()
{
	return check;
}

void Share::SetHitCheck(bool c)
{
	check = c;
}

VECTOR2 Share::GetMapCenter()
{
	return mapCenter;
}

void Share::SetMapCenter(float x, float z)
{
	mapCenter.x = x;
	mapCenter.y = z;
}
