#include "Share.h"

Share* Share::s_Instance = nullptr;

Share::Share()
{
}


Share::~Share()
{
}

void Share::Create()
{
	if (!s_Instance)
	{
		s_Instance = new Share();
	}
}

int Share::GetLRFlag()
{
	return lrFlag;
}

void Share::SetLRFlag(int flag)
{
	lrFlag = flag;
}

float Share::GetSpeed()
{
	return speed;
}

void Share::SetSpeed(float sp)
{
	speed = sp;
}
