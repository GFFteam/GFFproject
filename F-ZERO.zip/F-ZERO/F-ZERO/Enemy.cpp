#include "Enemy.h"
#include "Share.h"
#include "Circuit.h"
#include "ResourceMng.h"
#include "GameTask.h"
#include <cmath>
#include <DxLib.h>

Enemy::Enemy()
{
}

Enemy::Enemy(VECTOR2 pos): _pos(pos)
{
}


Enemy::~Enemy()
{
}

void Enemy::Init()
{
}

void Enemy::Update()
{
	if (!lpGameTask.GetRaceStart()._startFlag)
	{
		return;
	}

	auto vec = Share::GetInstance().GetEnemyVec();

	//DrawFormatString(SCREEN_SIZE_X - 200, 50, 0xffffff, "enemyVec.x:%.1f\nebemyVec.y:%.1f", vec.x, vec.y);

	// �Ǔ����蔻�肱������ //
	if (_hitFlag)
	{
		_hitTime++;
		Share::GetInstance().SetAICheck(AI::NON);

		if (_hitTime / 3 > 3)
		{
			_hitTime = 0;
			_hitFlag = false;
		}
	}
	else
	{
		_hitNonTime++;

		if (_hitNonTime / 6 > 6)
		{
			_hitNonTime = 0;
			//Share::GetInstance().SetAICheck(AI::NORMAL);

		}
	}

	if (vec.x > -100 && vec.y > -100)
	{
		float speed = 0.95f;

		if (!Share::GetInstance().GetEnemyHitCheck())
		{
			_hitFlag = true;
			speed *= 0.95f;

		}

		_pos.x += vec.x * speed;// *(!_hitFlag ? 1 : -1);
		_pos.y += vec.y * speed;// *(!_hitFlag ? 1 : -1);
		Share::GetInstance().SetEnemyPos(_pos.x, _pos.y);

	}
	Share::GetInstance().SetEnemyPos(_pos.x, _pos.y);
	// �Ǔ����蔻�肱���܂� //
}

void Enemy::Draw()
{
	
	DrawCircle(_pos.x, _pos.y, 3, 0xff0000, true);
}

void Enemy::PositionDraw()
{
	if (lpGameTask.GetRaceMode() == RACE_MODE::TIME_ATTACK)
	{
		return;
	}

	//++cnt;
	//if (Share::GetInstance().GetEnemyImageCheck())
	//{
	//	auto distance = Share::GetInstance().GetDistance();

	//	auto max = 100 + distance;
	//	auto e = max / 120;

	//	auto eSize = 0.0f;

	//	if (distance < 20 && distance > -9.5f)
	//	{
	//		eSize = 0.3f + (distance * 0.01f);
	//	}
	//	auto y = _imagePos.y + (distance * 10);
	//	//DrawRotaGraph(_imagePos.x, y, (eSize > 0 ? eSize : 0), 0.0, IMAGE_ID("data/images/player01.png"), true);
	//}
	//else
	//{
	//	sizeCnt = 0.0f;
	//}

	auto Clamp = [&](float value, float inDataMax, float inDataMin, float max, float min)
	{
		if (value < inDataMax && value > inDataMin)
		{
			auto clmp = ((value - inDataMin) / (inDataMax - inDataMin)) * (max - min) + min;
			return clmp;
		}
		return -2.0f;
	};

	auto rotAngle = Share::GetInstance().GetMapRotAngle();
	auto theta = rotAngle * (PI / 180);

	//DrawBox(SCREEN_SIZE_X - 200, 0, SCREEN_SIZE_X, SCREEN_SIZE_Y, 0x000000, true);
	auto distanceVec = Share::GetInstance().GetDistanceXY();
	//DrawFormatString(SCREEN_SIZE_X - 200, 200, 0xffffff, "distance.x:%.1f\ndistance.y:%.1f", distanceVec.x, distanceVec.y);

	auto distanceVecNorm = distanceVec.Normalize();
	//DrawFormatString(SCREEN_SIZE_X - 200, 230, 0xffffff, "distanceN.x:%.1f\ndistanceN.y:%.1f", distanceVecNorm.x, distanceVecNorm.y);

	//DrawFormatString(SCREEN_SIZE_X - 200, 275, 0xffffff, "rotAngle:%.1f\nrotAngleTheta:%.1f", rotAngle, theta);

	VECTOR2 rotDistanceVec;
	rotDistanceVec.x = distanceVec.x * cos(theta) - distanceVec.y * sin(theta);
	rotDistanceVec.y = distanceVec.x * sin(theta) + distanceVec.y * cos(theta);

	auto rotDistanceVecNorm = rotDistanceVec.Normalize();

	Share::GetInstance().SetRotDistanceVec(rotDistanceVecNorm);

	//DrawFormatString(SCREEN_SIZE_X - 200, 315, 0xffffff, "rotDistanceVec.x:%.1f\nrotDistanceVec.y:%.1f", rotDistanceVecNorm.x, rotDistanceVecNorm.y);

	auto distance = hypot(distanceVec.x, distanceVec.y);

	if (rotDistanceVecNorm.y > 0)
	{
		distance = -distance;
	}

	//DrawFormatString(SCREEN_SIZE_X - 200, 345, 0xffffff, "Distance:%.1f", distance);

	// �N�����v(-1~1)
	auto clmpDist = Clamp(distance,25.0f,-25.0f,1.0f, -1.0f);
	//DrawFormatString(SCREEN_SIZE_X - 200, 360, 0xffffff, "clmpDist:%.1f", clmpDist);

	auto screenPlayerPos = Share::GetInstance().GetScreenPlayerPos();

	if (clmpDist <= 1.0f && clmpDist >= -1.0f)
	{
		clmpDist = 1.0f - abs(clmpDist);

		auto size = 0.25f * clmpDist;
		auto backSize = 0.27f * clmpDist;

		if (distance < 0)
		{
			if (size < 0.24f)
			{
				size = 0.24f;
			}
		}

		
		float angle = 0.0f;
		if (rotDistanceVecNorm.x < 0.8f && rotDistanceVecNorm.x > -0.8f)
		{
			angle = 0.0f;
		}
		else
		{
			angle = (rotDistanceVecNorm.x * 10) * (PI / 180);
		}

		count++;
		auto removeLimitPosY = Share::GetInstance().GetBackGroundYPos();
		auto posX = screenPlayerPos.x + (rotDistanceVec.x * 12);
		auto posY = screenPlayerPos.y + (rotDistanceVec.y * 20) + sin(PI * 2 / cycle * count);
		VECTOR2 screenPos = { posX,posY };
		Share::GetInstance().SetScreenEnemyPos(screenPos);

		//auto hitReactionMove = Share::GetInstance().GetHitReactionMove();
		//posX += -hitReactionMove.x;
		//posY += -hitReactionMove.y;
		if (SCREEN_SIZE_Y / 2 <= posY)
		{	
			SetDrawBlendMode(DX_BLENDMODE_ALPHA, 150);
			DrawRotaGraph(posX, posY + 20, size, 0, IMAGE_ID("data/images/p_shadow01.png"), true);
			SetDrawBlendMode(DX_BLENDMODE_NOBLEND, 0);
			DrawRotaGraph(posX, posY, size, angle, IMAGE_ID("data/images/enemy01.png"), true);
		}
		else if (SCREEN_SIZE_Y / 2 > posY && removeLimitPosY < posY)
		{
			SetDrawBlendMode(DX_BLENDMODE_ALPHA, 150);
			DrawRotaGraph(posX, posY + 20, backSize, 0, IMAGE_ID("data/images/p_shadow01.png"), true);
			SetDrawBlendMode(DX_BLENDMODE_NOBLEND, 0);
			DrawRotaGraph(posX, posY, backSize, angle, IMAGE_ID("data/images/enemy01_back1.png"), true);
		}
		else
		{
			DrawRotaGraph(posX, removeLimitPosY, backSize, angle, IMAGE_ID("data/images/enemy01_back2.png"), true);
		}
	}
}

void Enemy::Key()
{
}
