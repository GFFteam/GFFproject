#include "Enemy.h"
#include "KeyMng.h"

#include "DxLib.h"

Enemy::Enemy()
{
}

Enemy::Enemy(VECTOR2 p): _pos(p)
{
}

Enemy::Enemy(VECTOR2 p, VECTOR2 startPos): _pos(p), _startPos(startPos)
{
}

Enemy::Enemy(VECTOR2 p, VECTOR2 startPos, VECTOR2 endPos) : _pos(p), _startPos(startPos), _endPos(endPos)
{
}

Enemy::~Enemy()
{
}

void Enemy::SetVector(std::vector<std::vector<VECTOR2>> vec)
{
	_vec = vec;
}

void Enemy::SetPos(VECTOR2 pos)
{
	_pos = pos;
}

void Enemy::SetStartPos(VECTOR2 vec)
{
	_startPos = vec;
}

const VECTOR2& Enemy::GetStartPos()
{
	return _startPos;
}

void Enemy::PushLineStart(VECTOR2 vec)
{
	_lineStart.emplace_back(vec);
}

void Enemy::SetLinePos(int j, VECTOR2 vec)
{
	_lineStart[j] = vec;
}

void Enemy::Update()
{
	_gameCnt++;
	unsigned int speed = 5;
	if (!_timeFlag && KeyMng::GetInstance().trgKey[P1_SPACE])
	{
		_timeFlag = true;
	}
	else if (_timeFlag && KeyMng::GetInstance().trgKey[P1_SPACE])
	{
		_timeFlag = false;
	}

	if (_timeFlag)
	{
		_pos = _lineStart[_vecCnt - 1];
		_time++;

		if (_time < _vec[_vecCnt + 1].size())
		{
			_pos = _pos + _vec[_vecCnt + 1][_time];
		}
		else
		{
			_time = 0;
			if (_vecCnt + 2 < _vec.size())
			{
				_pos = _lineStart[_vecCnt];
				_vecCnt++;
			}
			else
			{
				_vecCnt = 1;
				_pos = _lineStart[0];

			}
		}
	}
}

void Enemy::Draw()
{
	DrawCircle(_pos.x, _pos.y, 10, 0xff0000);
}
