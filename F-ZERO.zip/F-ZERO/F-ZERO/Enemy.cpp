#include "Enemy.h"
#include "Share.h"
#include "Circuit.h"
#include "ResourceMng.h"
#include <cmath>
#include <DxLib.h>

Enemy::Enemy()
{
}

Enemy::Enemy(VECTOR2 pos): _pos(pos)
{
}


Enemy::~Enemy()
{
}

void Enemy::Init()
{
}

void Enemy::Update()
{
	Share::GetInstance().SetEnemyPos(_pos.x, _pos.y);
}

void Enemy::Draw()
{
	auto vec = Share::GetInstance().GetEnemyVec();

	if (_hitFlag)
	{
		_hitTime++;
		Share::GetInstance().SetAICheck(AI::NON);

		if (_hitTime / 3 > 3)
		{
			_hitTime = 0;
			_hitFlag = false;
		}
	}
	else
	{
		_hitNonTime++;

		if (_hitNonTime / 6 > 6)
		{
			_hitNonTime = 0;
			//Share::GetInstance().SetAICheck(AI::NORMAL);

		}
	}

	if (vec.x > -100 && vec.y > -100)
	{
		auto speed = 0.8f;

		if (!Share::GetInstance().GetEnemyHitCheck())
		{
			_hitFlag = true;
			speed *= 0.95f;

		}

		_pos.x += vec.x * speed;// *(!_hitFlag ? 1 : -1);
		_pos.y += vec.y * speed;// *(!_hitFlag ? 1 : -1);
		Share::GetInstance().SetEnemyPos(_pos.x, _pos.y);

	}
	DrawCircle(_pos.x, _pos.y, 3, 0xff0000, true);
}

void Enemy::PositionDraw()
{
	++cnt;
	if (Share::GetInstance().GetEnemyImageCheck())
	{
		auto distance = Share::GetInstance().GetDistance();

		auto max = 100 + distance;
		auto e = max / 120;

		auto eSize = 0.0f;

		if (distance < 20 && distance > -9.5f)
		{
			eSize = 0.3f + (distance * 0.01f);
		}
		auto y = _imagePos.y + (distance * 10);
		//DrawRotaGraph(_imagePos.x, y, (eSize > 0 ? eSize : 0), 0.0, IMAGE_ID("data/images/player01.png"), true);
	}
	else
	{
		sizeCnt = 0.0f;
	}
}

void Enemy::Key()
{
}
