#pragma once
#include <string>
#include <map>

#define IMAGE_ID(X) ImageMng::GetInstance().SetImage(X)

using namespace std;

class ImageMng
{
public:
	static ImageMng& GetInstance() {
		static ImageMng imgInst;
		return imgInst;
	}
	const int& SetImage(string);		// �摜�o�^�AID��Ԃ�

private:
	map<string,int>mp;
};

