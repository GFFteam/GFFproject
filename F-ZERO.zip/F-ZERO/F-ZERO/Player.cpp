#include "Player.h"
#include "DxLib.h"
#include "ImageMng.h"

Player::Player()
{
}


Player::~Player()
{
}

void Player::Init()
{
}

void Player::Update()
{

}

void Player::Draw()
{
	DrawRotaGraph(pl.pos.x, pl.pos.y, pl.size, pl.angle, IMAGE_ID("data/images/player.png"),true);
}
