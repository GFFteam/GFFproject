#include "Player.h"
#include "DxLib.h"
#include "ResourceMng.h"
#include "KeyMng.h"
#include <cmath>
#include "Share.h"

Player::Player()
{
}


Player::~Player()
{
}

void Player::Init()
{
}

void Player::Update()
{	
	count++;
	pl.theta = pl.angle * (PI / 180);

	if (pl.lrFlag == -1)
	{
		pl.angle -= 3;
		if (pl.angle < -15)
		{
			pl.angle = -15;
		}
	}
	else if (pl.lrFlag == 1)
	{
		pl.angle += 3;
		if (pl.angle > 15)
		{
			pl.angle = 15;
		}
	}
	else
	{
		if (pl.angle < 0)
		{
			pl.angle += 3;
			if (pl.angle > 0)
			{
				pl.angle = 0;
			}
		}
		else if (pl.angle > 0)
		{
			pl.angle -= 3;
			if (pl.angle < 0)
			{
				pl.angle = 0;
			}
		}
	}
	Share::GetInstance().SetLRFlag(pl.lrFlag);
	Share::GetInstance().SetSpeed(pl.speed);
	Share::GetInstance().SetThrottleParcent(pl.throttleParcent);
	Share::GetInstance().SetBrakeParcent(pl.brakeParcent);
	Share::GetInstance().SetFuel(pl.fuel);
	Share::GetInstance().SetYawPercent(pl.yawPercent);
}

void Player::PositionDraw()
{
	auto plpos = Share::GetInstance().GetMiniMapPlayerPos() / cutCnt;
	auto offset = Share::GetInstance().GetMiniMapSize();
	auto block = VECTOR2(80 / cutCnt, 150 / cutCnt);
	DrawCircle(plpos.x - offset.x - block.x, plpos.y - offset.y + block.y, 5, 0x0000ff, true);
	//setting
	Share::GetInstance().SetMiniMapPos(VECTOR2(plpos.x - offset.x - block.x, plpos.y - offset.y + block.y));
}

void Player::Draw()
{
	//sin( PI*2 / ���� * Count ) * �U��
	DrawRotaGraph(pl.pos.x, pl.pos.y + sin(PI * 2 / pl.cycle * count) * pl.swing, pl.size, pl.theta, IMAGE_ID("data/images/player.png"),true);
	PositionDraw();
}

void Player::Key()
{
	if (KeyMng::GetInstance().newKey[P1_LEFT])
	{
		pl.lrFlag = -1;

		pl.yawPercent = -50.0f;
	}
	else if (KeyMng::GetInstance().newKey[P1_RIGHT])
	{
		pl.lrFlag = 1;

		pl.yawPercent = 50.0f;
	}
	else
	{
		pl.lrFlag = 0;

		pl.yawPercent = 0.0f;
	}

	if (KeyMng::GetInstance().newKey[P1_UP])
	{
		if (pl.fuel != 0.0f)
		{
			if (pl.speed < 3.9f)
			{
				pl.speed += 0.05f;
			}
			else
			{
				pl.speed = 3.9f;
			}

			if (pl.fuel > 0.0f)
			{
				pl.fuel -= 0.05f;
			}
			else
			{
				pl.fuel = 0.0f;
			}
		}
		else
		{
			if (pl.speed > 1.0f)
			{
				pl.speed -= 0.01f;
			}

			if (pl.speed <= 1.0f)
			{
				pl.speed += 0.05f;
			}
		}
		pl.throttleParcent = 50.0f;
	}
	else
	{
		if (pl.speed > 0.0f)
		{
			pl.speed -= 0.01f;
		}
		else
		{
			pl.speed = 0.0f;
		}
		pl.throttleParcent = 0.0f;
	}

	if (KeyMng::GetInstance().newKey[P1_DOWN])
	{
		if (pl.speed > 0.0f)
		{
			pl.speed -= 0.03f;
		}
		else
		{
			pl.speed = 0.0f;
		}
		pl.brakeParcent = 50.0f;
	}
	else
	{
		pl.brakeParcent = 0.0f;
	}
}
