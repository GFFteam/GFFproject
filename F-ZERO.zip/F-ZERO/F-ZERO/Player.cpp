#include "Player.h"
#include "DxLib.h"
#include "ResourceMng.h"
#include "KeyMng.h"
#include <cmath>
#include "Share.h"

Player::Player()
{
}


Player::~Player()
{
}

void Player::Init()
{
}

void Player::Update()
{	
	count++;
	pl.theta = pl.angle * (PI / 180);

	if (!Share::GetInstance().GetHitCheck())
	{
		pl.speed *= 0.95f;
	}

	pl.angle += 3.0f * ctl.rotate;
	if (pl.angle > 21.0f)
	{
		pl.angle = 21.0f;
	}
	else if (pl.angle < -21.0f)
	{
		pl.angle = -21.0f;
	}

	if (pl.lrFlag == 0)
	{
		if (pl.angle > 0)
		{
			pl.angle -= 3.0f;
		}
		else
		{
			pl.angle += 3.0f;
		}

		if (pl.angle < 4.0f && pl.angle > -4.0f)
		{
			pl.angle = 0;
		}
	}

	Share::GetInstance().SetLRFlag(pl.lrFlag);
	Share::GetInstance().SetSpeed(pl.speed);
	Share::GetInstance().SetThrottleParcent(ctl.accel);
	Share::GetInstance().SetBrakeParcent(ctl.brake);
	Share::GetInstance().SetYawPercent(ctl.rotate);
	Share::GetInstance().SetFuel(pl.fuel);
	Share::GetInstance().SetPlayerRollAngle(pl.theta);

	if (IsHitEnemy())
	{
		//DrawFormatString(pl.pos.x, pl.pos.y - 50, 0xff0000, "hit");
		pl.hitReactionMove = HitReaction() * 3.0f;

		Share::GetInstance().SetHitReactionMove(pl.hitReactionMove);
	}
	else
	{
		back_vec = pl.initialPos - pl.pos;
		back_vecNorm = back_vec.Normalize();

		if (back_vec.x < 2.0f && back_vec.x > -2.0f)
		{
			back_vec.x = 0.0f;
			pl.hitReactionMove.x = 0.0f;
			pl.pos.x = pl.initialPos.x;
		}
		else
		{
			pl.hitReactionMove.x = back_vecNorm.x * 2.0f;
		}

		if (back_vec.y < 2.0f && back_vec.y > -2.0f)
		{
			back_vec.y = 0.0f;
			pl.hitReactionMove.y = 0.0f;
			pl.pos.y = pl.initialPos.y;
		}
		else
		{
			pl.hitReactionMove.y = back_vecNorm.y * 2.0f;
		}

		Share::GetInstance().SetHitReactionMove(pl.hitReactionMove);
	}

	pl.pos.x += pl.hitReactionMove.x;
	pl.pos.y += pl.hitReactionMove.y;

	DrawFormatString(0, 0, 0xff00ff, "x:%.1f\ny:%.1f\n", pl.hitReactionMove.x, pl.hitReactionMove.y);
	DrawFormatString(0, 30, 0xff00ff, "x:%.1f\ny:%.1f", back_vec.x, back_vec.y);
}

void Player::Draw()
{
	//sin( PI*2 / ���� * Count ) * �U��

	DrawRotaGraph(pl.pos.x, pl.pos.y + sin(PI * 2 / pl.cycle * count) * pl.swing, 
		pl.size, pl.theta, IMAGE_ID("data/images/player01.png"), true);

	Share::GetInstance().SetScreenPlayerPos(pl.initialPos);
}

void Player::PositionDraw()
{
	auto plpos = Share::GetInstance().GetPlayerPos() / cutCnt;
	auto offset = Share::GetInstance().GetMapMove();
	auto block = VECTOR2((80 / cutCnt), (150 / cutCnt));

	DrawCircle(plpos.x - offset.x - block.x, plpos.y - offset.y + block.y, 5, 0x0000ff, true);
	//setting

	vel = VECTOR2(plpos.x - offset.x - block.x, plpos.y - offset.y + block.y);
	auto preVel = (vel - velOld);
	Share::GetInstance().SetVelocity(preVel);

	velOld = vel;
	Share::GetInstance().SetMiniPos(VECTOR2(plpos.x - offset.x - block.x, plpos.y - offset.y + block.y));
}

void Player::Key()
{
	if (GetJoypadNum() == 0)
	{
		if (KeyMng::GetInstance().newKey[P1_LEFT])
		{
			pl.lrFlag = -1;

			pl.yawPercent = -50.0f;
		}
		else if (KeyMng::GetInstance().newKey[P1_RIGHT])
		{
			pl.lrFlag = 1;

			pl.yawPercent = 50.0f;
		}
		else
		{
			pl.lrFlag = 0;

			pl.yawPercent = 0.0f;
		}

		if (KeyMng::GetInstance().newKey[P1_UP])
		{
			if (pl.fuel != 0.0f)
			{
				if (pl.speed < 3.9f)
				{
					pl.speed += 0.05f;
				}
				else
				{
					pl.speed = 3.9f;
				}

				if (pl.fuel > 0.0f)
				{
					pl.fuel -= 0.02f;
				}
				else
				{
					pl.fuel = 0.0f;
				}
			}
			else
			{
				if (pl.speed > 1.0f)
				{
					pl.speed -= 0.01f;
				}

				if (pl.speed <= 1.0f)
				{
					pl.speed += 0.05f;
				}
			}
			pl.throttleParcent = 50.0f;
		}
		else
		{
			if (pl.speed > 0.0f)
			{
				pl.speed -= 0.01f;
			}
			else
			{
				pl.speed = 0.0f;
			}
			pl.throttleParcent = 0.0f;
		}

		if (KeyMng::GetInstance().newKey[P1_DOWN])
		{
			if (pl.speed > 0.0f)
			{
				pl.speed -= 0.03f;
				pl.fuel += 0.05f;
			}
			else
			{
				pl.speed = 0.0f;
			}
			pl.brakeParcent = 50.0f;
		}
		else
		{
			pl.brakeParcent = 0.0f;
		}
	}
	else // Xbox
	{
		GetJoypadXInputState(DX_INPUT_PAD1, &input);
		ctl.accel = input.RightTrigger;
		ctl.brake = input.LeftTrigger;
		ctl.rotate = input.ThumbLX;

		pl.throttleParcent = 1.0f / 255.0f;
		ctl.accel *= pl.throttleParcent;

		pl.brakeParcent = 1.0f / 255.0f;
		ctl.brake *= pl.brakeParcent;

		pl.yawPercent = 1.0f / 32767;
		ctl.rotate *= pl.yawPercent;

		//DrawFormatString(SCREEN_SIZE_X - 400, 200, 0xffffff, "LeftTrigger:%d RightTrigger:%d",
		//	input.LeftTrigger, input.RightTrigger);
		//DrawFormatString(SCREEN_SIZE_X - 400, 215, 0xffffff, "ThumbLX:%d ThumbLY:%d",
		//	input.ThumbLX, input.ThumbLY);

		if (KeyMng::GetInstance().newKey[P1_LEFT])
		{
			pl.lrFlag = -1;
		}
		else if (KeyMng::GetInstance().newKey[P1_RIGHT])
		{
			pl.lrFlag = 1;
		}
		else
		{
			pl.lrFlag = 0;
		}

		if (KeyMng::GetInstance().newKey[P1_UP])
		{
			if (pl.fuel != 0.0f)
			{
				if (pl.speed < 3.9f)
				{
					pl.speed += 0.05f * ctl.accel;
				}
				else
				{
					pl.speed = 3.9f;
				}

				if (pl.fuel > 0.0f)
				{
					pl.fuel -= 0.02f;
				}
				else
				{
					pl.fuel = 0.0f;
				}
			}
			else
			{
				if (pl.speed > 1.0f)
				{
					pl.speed -= 0.01f;
				}

				if (pl.speed <= 1.0f)
				{
					pl.speed += 0.05f;
				}
			}
		}
		

		else if (KeyMng::GetInstance().newKey[P1_DOWN])
		{
			if (pl.speed > 0.0f)
			{
				pl.speed -= 0.03f * ctl.brake;
				pl.fuel += 0.05f;
			}
			else
			{
				pl.speed = 0.0f;
			}
		}
		else
		{
			if (pl.speed > 0.0f)
			{
				pl.speed -= 0.01f;
			}
			else
			{
				pl.speed = 0.0f;
			}
		}
	}
}

//
bool Player::IsHitEnemy()
{
	enemyPos = Share::GetInstance().GetScreenEnemyPos();
	int gw, gh;
	auto adjust = 0.05f;

	GetGraphSize(IMAGE_ID("data/images/player01.png"), &gw, &gh);

	VECTOR2 boxSize;
	boxSize.x = gw * (pl.size - adjust);
	boxSize.y = gh * (pl.size - adjust);
	
	pBox.L = pl.pos.x - boxSize.x / 2;
	pBox.R = pl.pos.x + boxSize.x / 2;
	pBox.U = pl.pos.y - boxSize.y / 2;
	pBox.D = pl.pos.y + boxSize.y / 2;
	DrawBox(pBox.L, pBox.U, pBox.R, pBox.D, 0xff0000, false);

	eBox.L = enemyPos.x - boxSize.x / 2;
	eBox.R = enemyPos.x + boxSize.x / 2;
	eBox.U = enemyPos.y - boxSize.y / 2;
	eBox.D = enemyPos.y + boxSize.y / 2;

	if (eBox.D > SCREEN_SIZE_Y / 2 + (gh * (pl.size) / 2) && eBox.D < SCREEN_SIZE_Y - (gh * (pl.size * 1.5f)))
	{
		DrawBox(eBox.L, eBox.U, eBox.R, eBox.D, 0x0000ff, false);
		if (pBox.L < eBox.R && pBox.R > eBox.L &&
			pBox.U < eBox.D && pBox.D > eBox.U)
		{
			return true;
		}
	}

	return false;
}

VECTOR2 Player::HitReaction()
{
	pl.hitReactionVec = VECTOR2(pl.pos.x - enemyPos.x, pl.pos.y - enemyPos.y);

	pl.hitReactionVec = pl.hitReactionVec.Normalize();

	return pl.hitReactionVec;
}
