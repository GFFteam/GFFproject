#include "Player.h"
#include "DxLib.h"
#include "ResourceMng.h"
#include "KeyMng.h"
#include <cmath>
#include "Share.h"

Player::Player()
{
}


Player::~Player()
{
}

void Player::Init()
{
}

void Player::Update()
{	
	count++;
	pl.theta = pl.angle * (PI / 180);

	if (!Share::GetInstance().GetHitCheck())
	{
		pl.speed *= 0.95f;
	}

	pl.angle += 3.0f * ctl.rotate;
	if (pl.angle > 21.0f)
	{
		pl.angle = 21.0f;
	}
	else if (pl.angle < -21.0f)
	{
		pl.angle = -21.0f;
	}

	if (pl.lrFlag == 0)
	{
		if (pl.angle > 0)
		{
			pl.angle -= 3.0f;
		}
		else
		{
			pl.angle += 3.0f;
		}

		if (pl.angle < 4.0f && pl.angle > -4.0f)
		{
			pl.angle = 0;
		}
	}

	Share::GetInstance().SetLRFlag(pl.lrFlag);
	Share::GetInstance().SetSpeed(pl.speed);
	Share::GetInstance().SetThrottleParcent(ctl.accel);
	Share::GetInstance().SetBrakeParcent(ctl.brake);
	Share::GetInstance().SetYawPercent(ctl.rotate);
	Share::GetInstance().SetFuel(pl.fuel);
	Share::GetInstance().SetPlayerRollAngle(pl.theta);

}

void Player::Draw()
{
	//sin( PI*2 / ���� * Count ) * �U��

	DrawRotaGraph(pl.pos.x, pl.pos.y + sin(PI * 2 / pl.cycle * count) * pl.swing, pl.size, pl.theta, IMAGE_ID("data/images/player01.png"), true);
}

void Player::PositionDraw()
{
	auto plpos = Share::GetInstance().GetPlayerPos() / cutCnt;
	auto offset = Share::GetInstance().GetMapMove();
	auto block = VECTOR2(80 / cutCnt, 150 / cutCnt);
	DrawCircle(plpos.x - offset.x - block.x, plpos.y - offset.y + block.y, 5, 0x0000ff, true);
	//setting
	Share::GetInstance().SetMiniPos(VECTOR2(plpos.x - offset.x - block.x, plpos.y - offset.y + block.y));
}

void Player::Key()
{
	if (GetJoypadNum() == 0)
	{
		if (KeyMng::GetInstance().newKey[P1_LEFT])
		{
			pl.lrFlag = -1;

			pl.yawPercent = -50.0f;
		}
		else if (KeyMng::GetInstance().newKey[P1_RIGHT])
		{
			pl.lrFlag = 1;

			pl.yawPercent = 50.0f;
		}
		else
		{
			pl.lrFlag = 0;

			pl.yawPercent = 0.0f;
		}

		if (KeyMng::GetInstance().newKey[P1_UP])
		{
			if (pl.fuel != 0.0f)
			{
				if (pl.speed < 3.9f)
				{
					pl.speed += 0.05f;
				}
				else
				{
					pl.speed = 3.9f;
				}

				if (pl.fuel > 0.0f)
				{
					pl.fuel -= 0.02f;
				}
				else
				{
					pl.fuel = 0.0f;
				}
			}
			else
			{
				if (pl.speed > 1.0f)
				{
					pl.speed -= 0.01f;
				}

				if (pl.speed <= 1.0f)
				{
					pl.speed += 0.05f;
				}
			}
			pl.throttleParcent = 50.0f;
		}
		else
		{
			if (pl.speed > 0.0f)
			{
				pl.speed -= 0.01f;
			}
			else
			{
				pl.speed = 0.0f;
			}
			pl.throttleParcent = 0.0f;
		}

		if (KeyMng::GetInstance().newKey[P1_DOWN])
		{
			if (pl.speed > 0.0f)
			{
				pl.speed -= 0.03f;
				pl.fuel += 0.05f;
			}
			else
			{
				pl.speed = 0.0f;
			}
			pl.brakeParcent = 50.0f;
		}
		else
		{
			pl.brakeParcent = 0.0f;
		}
	}
	else // Xbox
	{
		GetJoypadXInputState(DX_INPUT_PAD1, &input);
		ctl.accel = input.RightTrigger;
		ctl.brake = input.LeftTrigger;
		ctl.rotate = input.ThumbLX;

		pl.throttleParcent = 1.0f / 255.0f;
		ctl.accel *= pl.throttleParcent;

		pl.brakeParcent = 1.0f / 255.0f;
		ctl.brake *= pl.brakeParcent;

		pl.yawPercent = 1.0f / 32767;
		ctl.rotate *= pl.yawPercent;

		DrawFormatString(SCREEN_SIZE_X - 400, 200, 0xffffff, "LeftTrigger:%d RightTrigger:%d",
			input.LeftTrigger, input.RightTrigger);
		DrawFormatString(SCREEN_SIZE_X - 400, 215, 0xffffff, "ThumbLX:%d ThumbLY:%d",
			input.ThumbLX, input.ThumbLY);

		if (KeyMng::GetInstance().newKey[P1_LEFT])
		{
			pl.lrFlag = -1;
		}
		else if (KeyMng::GetInstance().newKey[P1_RIGHT])
		{
			pl.lrFlag = 1;
		}
		else
		{
			pl.lrFlag = 0;
		}

		if (KeyMng::GetInstance().newKey[P1_UP])
		{
			if (pl.fuel != 0.0f)
			{
				if (pl.speed < 3.9f)
				{
					pl.speed += 0.05f * ctl.accel;
				}
				else
				{
					pl.speed = 3.9f;
				}

				if (pl.fuel > 0.0f)
				{
					pl.fuel -= 0.02f;
				}
				else
				{
					pl.fuel = 0.0f;
				}
			}
			else
			{
				if (pl.speed > 1.0f)
				{
					pl.speed -= 0.01f;
				}

				if (pl.speed <= 1.0f)
				{
					pl.speed += 0.05f;
				}
			}
		}
		

		else if (KeyMng::GetInstance().newKey[P1_DOWN])
		{
			if (pl.speed > 0.0f)
			{
				pl.speed -= 0.03f * ctl.brake;
				pl.fuel += 0.05f;
			}
			else
			{
				pl.speed = 0.0f;
			}
		}
		else
		{
			if (pl.speed > 0.0f)
			{
				pl.speed -= 0.01f;
			}
			else
			{
				pl.speed = 0.0f;
			}
		}
	}
}
