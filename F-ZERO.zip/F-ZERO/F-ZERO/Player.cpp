#include "Player.h"
#include "DxLib.h"
#include "ResourceMng.h"
#include "KeyMng.h"
#include <cmath>
#include "Share.h"

Player::Player()
{
}


Player::~Player()
{
}

void Player::Init()
{
}

void Player::Update()
{	
	count++;
	pl.theta = pl.angle * (PI / 180);

	if (pl.lrFlag == -1)
	{
		pl.angle -= 3;
		if (pl.angle < -15)
		{
			pl.angle = -15;
		}
	}
	else if (pl.lrFlag == 1)
	{
		pl.angle += 3;
		if (pl.angle > 15)
		{
			pl.angle = 15;
		}
	}
	else
	{
		if (pl.angle < 0)
		{
			pl.angle += 3;
			if (pl.angle > 0)
			{
				pl.angle = 0;
			}
		}
		else if (pl.angle > 0)
		{
			pl.angle -= 3;
			if (pl.angle < 0)
			{
				pl.angle = 0;
			}
		}
	}
	Share::GetInstance().SetLRFlag(pl.lrFlag);
}

void Player::Draw()
{
	//sin( PI*2 / ���� * Count ) * �U��
	DrawRotaGraph(pl.pos.x, pl.pos.y + sin(PI * 2 / pl.cycle * count) * pl.swing, pl.size, pl.theta, IMAGE_ID("data/images/player.png"),true);
}

void Player::Key()
{
	if (KeyMng::GetInstance().newKey[P1_LEFT])
	{
		pl.lrFlag = -1;
	}
	else if (KeyMng::GetInstance().newKey[P1_RIGHT])
	{
		pl.lrFlag = 1;
	}
	else
	{
		pl.lrFlag = 0;
	}
	//if (KeyMng::GetInstance().newKey[P1_UP])
	//{
	//	z--;
	//}
	//if (KeyMng::GetInstance().newKey[P1_DOWN])
	//{
	//	z++;
	//}
}
