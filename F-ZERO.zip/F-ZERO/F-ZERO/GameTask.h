#pragma once
#include <memory>
#include <vector>

#define lpGameTask GameTask::GetInstance()
constexpr int SCREEN_SIZE_X = 960;
constexpr int SCREEN_SIZE_Y = 540;
constexpr float PI = 3.14159265;

enum GAME_MODE {
	G_INIT,
	G_TITLE,
	G_MENU,
	G_MAIN,
	G_RESULT,
	G_MAX
};

class MapControl;
class BgControl;

class GameTask
{
public:
	GameTask();
	~GameTask();
	static void Create();
	static GameTask& GetInstance()
	{
		Create();
		return *s_Instance;
	}
	int SystemInit();
	void Update();

	void GameInit();
	void GameTitle();
	void GameMenu();
	void GameMain();
	void GameResult();

	const bool& GetRaceFlag()
	{
		return _raceStart;
	}
	const int& GetStartCnt()
	{
		return _startCnt;
	}
	const int& GetEfectCnt()
	{
		return _efectCnt;
	}

	void SetResultHandle(int handle)
	{
		_resultHandle = handle;
	}

private:
	static GameTask* s_Instance;
	void(GameTask::*gtskPtr[G_MAX])() = { &GameTask::GameInit,&GameTask::GameTitle,&GameTask::GameMenu,&GameTask::GameMain,&GameTask::GameResult };
	int updateMode = 0;

	std::vector<std::shared_ptr<MapControl>>mc;
	std::vector <std::shared_ptr<BgControl>>bg;

	int _resultHandle = 0;
	int timeCnt = 0;
	bool Bswitch = false;
	bool _raceStart = false;
	int _startCnt = 3;
	int _raceCnt = 0;
	int _efectCnt = 0;

};

