#pragma once
#include <memory>
#include <vector>
#include <list>
#include <array>
#include "VECTOR2.h"

#define lpGameTask GameTask::GetInstance()
constexpr int SCREEN_SIZE_X = 960;
constexpr int SCREEN_SIZE_Y = 540;
constexpr float PI = 3.14159265;

constexpr int LOGO_CENTER_X = (SCREEN_SIZE_X / 3 * 1.75f);
constexpr int LOGO_CENTER_Y = SCREEN_SIZE_Y / 2;

enum GAME_MODE {
	G_INIT,
	G_TITLE,
	G_MENU,
	G_MAIN,
	G_RESULT,
	G_MAX
};

struct BoxRC
{
	float L, R, U, D;
};

struct BoxTA
{
	float L, R, U, D;
};

class MapControl;
class BgControl;
class Smoke;

class GameTask
{
public:
	GameTask();
	~GameTask();
	static void Create();
	static GameTask& GetInstance()
	{
		Create();
		return *s_Instance;
	}
	int SystemInit();
	void Update();

	void GameInit();
	void GameTitle();
	void GameMenu();
	void GameMain();
	void GameResult();

	void MenuCtrl();

	const bool& GetRaceFlag()
	{
		return _raceStart;
	}
	const int& GetStartCnt()
	{
		return _startCnt;
	}
	const int& GetEfectCnt()
	{
		return _efectCnt;
	}

	void SetResultHandle(int handle)
	{
		_resultHandle = handle;
	}

private:
	static GameTask* s_Instance;
	void(GameTask::*gtskPtr[G_MAX])() = { &GameTask::GameInit,&GameTask::GameTitle,&GameTask::GameMenu,&GameTask::GameMain,&GameTask::GameResult };
	int updateMode = 0;

	std::vector<std::shared_ptr<MapControl>>mc;
	std::vector <std::shared_ptr<BgControl>>bg;

	std::list<std::shared_ptr<Smoke>>sm;

	std::array<VECTOR2, 8>box;

	BoxRC brc;
	BoxTA bta;

	int _resultHandle = 0;
	int timeCnt = 0;
	bool Bswitch = false;
	bool _raceStart = true;
	int _startCnt = 3;
	int _raceCnt = 0;
	int _efectCnt = 0;

	int mode = 0;	// 0:���� 1:TA 2:RC 3:�߂�
	int nextMode = 0;	// 0:���� 1:TA 2:RC 3:�߂�
	float rcLogoSize = 0.7f;
	float taLogoSize = 0.7f;
	float rcSize = 0.4f;
	float taSize = 0.4f;
	float backSize = 0.7f;
	bool flashFlag = false;
	int flashCnt = 0;

	VECTOR2 miniPlanePos = { SCREEN_SIZE_X / 2,-50.0f };
	float miniPlaneAngle = 0.0f;
	int smokeCount = 0;
	VECTOR2 startPoint = { 0.0f,0.0f };
	VECTOR2 nextPoint = { 0.0f,0.0f };
	VECTOR2 endPoint = { 0.0f,0.0f };
	int pointCount = 0;

	VECTOR2 miniToStartVec = { 0.0f,0.0f };
	VECTOR2 miniToNextVec = { 0.0f,0.0f };
	int miniPlaneGw = 0;
	int miniPlaneGh = 0;
	VECTOR2 miniSize = { 0.0f,0.0f };
	int beforeMode = 0;
	bool moveFlag = false;
	bool beforeHitFlag = false;
	int lrdFlag = 0; //  0:���� 1:TA 2:RC 3:�߂�
};

