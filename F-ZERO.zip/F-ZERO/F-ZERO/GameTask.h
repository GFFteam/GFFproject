#pragma once
#include <string>
#include <vector>
#include <memory>
#include "VECTOR2.h"

#define  lpGameTask GameTask::GetInstance()

constexpr int SCREEN_SIZE_X = 1280;
constexpr int SCREEN_SIZE_Y = 800;
constexpr int GAME_SIZE_X = 800;
constexpr int GAME_SIZE_Y = 800;
constexpr int SCREEN_CENTER_X = GAME_SIZE_X / 2;
constexpr int SCREEN_CENTER_Y = GAME_SIZE_Y / 2;

enum G_MODE {
	G_INIT,
	G_MAIN,
	G_MAX
};

class GameTask
{
public:
	// �ݸ����
	static void Create(void);
	static GameTask &GetInstance(void)
	{
		Create();
		return *s_Instance;
	}


	int SystemInit();		// �V�X�e��������
	void GameUpdate();		// �Q�[�����[�v
	void GameInit();		// �Q�[�����e�̐���ϐ��ȂǏ�����
	void GameMain();		// �Q�[����

	void Upload();
	void ExternUpload();

private:
	static GameTask *s_Instance;

	void (GameTask::*gMode[G_MAX])() = { &GameTask::GameInit,&GameTask::GameMain };	


	int currentMode = -1;		// ���݂̃��[�h
	bool _popFlag = false;
	bool _checkFlag = false;
	int _lineCnt = 0;
	bool _finishFlag = false;
	bool _UICheckFlag = false;
	bool extendFlag = false;

	int handle = 0;
	VECTOR2 _startPos = { 0,0 };
	VECTOR2 _enemyStart = { 0,0 };

	std::vector<std::vector<VECTOR2>> _enemyVec;

};


