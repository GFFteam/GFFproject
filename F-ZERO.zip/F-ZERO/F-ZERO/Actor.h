#pragma once
#include "VECTOR2.h"

class Actor
{
public:
	Actor();
	~Actor();

	virtual void Init() = 0;
	virtual void Update() = 0;
	virtual void Draw() = 0;
	virtual void PositionDraw() = 0;
	virtual void Key() = 0;

};

