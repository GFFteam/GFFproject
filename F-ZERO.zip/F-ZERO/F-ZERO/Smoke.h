#pragma once
#include "VECTOR2.h"
class Smoke
{
public:
	Smoke();
	~Smoke();

	void Init();
	void Update();
	void MenuSmoke();

	int GetAlpha() { return alphaCount; }
private:
	VECTOR2 menuSmokePos = { 0.0f,0.0f };
	float alphaCount = 255.0f;
	float size = 1.0f;
};

