#pragma once
#include "Actor.h"
#include "GameTask.h"
class Enemy :
	public Actor
{
public:
	Enemy();
	Enemy(VECTOR2 pos);

	~Enemy();
	void Init();
	void Update();
	void Draw();
	void PositionDraw();
	void Key();


private:
	VECTOR2 _pos;
	VECTOR2 _imagePos = { SCREEN_SIZE_X / 2,SCREEN_SIZE_Y / 2 + 70 };
	int cntY = SCREEN_SIZE_Y / 2;
	float sizeCnt = 0.0f;
	int cnt = 0;
	bool _hitFlag = false;
	int _hitTime = 0;
	int _hitNonTime = 0;
};

