#pragma once
#include "VECTOR2.h"
#include <vector>
class Enemy
{
public:
	Enemy();
	Enemy(VECTOR2 p);
	Enemy(VECTOR2 p, VECTOR2 startPos);
	Enemy(VECTOR2 p, VECTOR2 startPos, VECTOR2 endPos);

	~Enemy();

	void SetVector(std::vector<std::vector<VECTOR2>> vec);
	void SetPos(VECTOR2 pos);
	void SetStartPos(VECTOR2 vec);
	const VECTOR2& GetStartPos();
	void PushLineStart(VECTOR2 vec);
	void SetLinePos(int j, VECTOR2 vec);

	void Update();
	void Draw();

private:
	//���S�_
	VECTOR2 _pos;
	VECTOR2 _startPos;
	VECTOR2 _endPos;

	int _gameCnt = 0;
	int _time = 0; 
	int _vecCnt = 1;
	bool _timeFlag = false;

	std::vector<std::vector<VECTOR2>> _vec;

	std::vector<VECTOR2> _lineStart;
};

