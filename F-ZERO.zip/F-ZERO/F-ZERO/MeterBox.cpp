#include "MeterBox.h"
#include "DxLib.h"
#include "Button.h"
#include "MouseMng.h"

MeterBox::MeterBox()
{
}

MeterBox::MeterBox(VECTOR2 p, VECTOR2 s, float l): _pos(p), _size(s), _length(l)
{
	Init();
}


MeterBox::~MeterBox()
{
}

bool MeterBox::Init()
{
	_button.emplace_back(std::make_shared<Button>("", VECTOR2(_pos.x + _length / 2, _pos.y - _size.y / 4), VECTOR2(_size.x / 8, _size.y / 2)));
	_standardCnt = _button[0]->GetPos().x;
	return true;
}

void MeterBox::Update(VECTOR2 pos)
{
	_setCnt = 0;

	for (auto& b : _button)
	{
		if (MouseMng::GetInstance().newKey[P1_PUSH] && b->GetHitCheck(VECTOR2(pos.x, pos.y)))
		{
			if (pos.x > _pos.x && pos.x < _pos.x + _length)
			{
				b->SetPosForX(pos.x, (_size.x / 8) / 2);
				_setCnt = b->GetPos().x - _standardCnt;
			}
		}
	}

	DrawFormatString(_pos.x, _pos.y, 0xffffff, "%d", _setCnt);
}

void MeterBox::Draw()
{
	DrawLine(_pos.x, _pos.y, _pos.x + _length, _pos.y, 0xffffff, true);

	for (auto& b : _button)
	{
		b->Draw();
	}
}

const int & MeterBox::GetCnt() const
{
	return _setCnt;
}
