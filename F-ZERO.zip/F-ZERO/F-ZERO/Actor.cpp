#include "Actor.h"



Actor::Actor()
{
}


Actor::~Actor()
{
}
