#include "Smoke.h"
#include "Share.h"
#include "DxLib.h"

Smoke::Smoke()
{
	Init();
}

Smoke::~Smoke()
{
}

void Smoke::Init()
{
	menuSmokePos = Share::GetInstance().GetMenuPos();
}

void Smoke::Update()
{
	alphaCount -= 1.4f;
	size += 0.05f;
}

void Smoke::MenuSmoke()
{
	SetDrawBlendMode(DX_BLENDMODE_ALPHA, alphaCount);
	DrawCircle(menuSmokePos.x, menuSmokePos.y, size, 0xffffff, true);
	SetDrawBlendMode(DX_BLENDMODE_NOBLEND, alphaCount);
}
