#include "DxLib.h"
#include "ResourceMng.h"
#include <assert.h>

const int& ResourceMng::SetImage(string imagePath)
{
	// �摜������
	if (mp.find(imagePath) == mp.end())
	{
		mp[imagePath] = LoadGraph(imagePath.c_str());
	}
	return mp[imagePath];
}

const int & ResourceMng::SetSound(string soundPath)
{
	// ��������
	if (mp.find(soundPath) == mp.end())
	{
		mp[soundPath] = LoadSoundMem(soundPath.c_str());
	}
	return mp[soundPath];
}
