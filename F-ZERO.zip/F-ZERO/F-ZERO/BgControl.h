#pragma once

constexpr int SEP_NUM = 20;

class BgControl
{
public:
	BgControl();
	~BgControl();

	void Update();
	void Draw();

private:
	float sclX = 0.0f;
	int gw,gh;
};

