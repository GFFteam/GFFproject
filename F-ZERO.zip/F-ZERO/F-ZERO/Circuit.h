#pragma once
#include <vector>
#include "VECTOR2.h"

struct ReceiveCircuitPos
{
	VECTOR2 _rightPos = {0,0};
	VECTOR2 _leftPos = {0,0};
};

struct Data
{
	int size;
	std::vector<ReceiveCircuitPos>receivePos;
};

class Circuit
{
public:
	Circuit();
	virtual ~Circuit();

	void Init();
	void Update();
	void Draw();

private:

	Data data;
	FILE* file;
};

