#pragma once
#include <vector>
#include "VECTOR2.h"
struct circuitInfo
{
	bool flag;
	VECTOR2 pos;
};

class Circuit
{
public:
	Circuit();
	virtual ~Circuit();

	void Init();
	void Update();
	void Draw();

private:
	std::vector<std::vector<circuitInfo>> vv;
	int width, height;

	VECTOR2 diff;
	VECTOR2 moveOneLoop;
};

