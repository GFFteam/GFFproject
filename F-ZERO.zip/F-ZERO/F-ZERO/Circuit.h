#pragma once
#include "MapControl.h"

class Circuit : public MapControl
{
public:
	Circuit();
	virtual ~Circuit();

	void Init();
	void Update();
	void Draw();
};

