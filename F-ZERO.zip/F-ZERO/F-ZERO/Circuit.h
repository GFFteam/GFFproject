#pragma once
#include <vector>
#include "VECTOR2.h"

struct ReceiveCircuitPos
{
	VECTOR2 _rightPos = {0,0};
	VECTOR2 _leftPos = {0,0};
};

struct Data
{
	int size;
	std::vector<ReceiveCircuitPos>receivePos;
};

class Circuit
{
public:
	Circuit();
	virtual ~Circuit();

	void Init();
	void Update();
	void Draw();

	bool CollisionCheck(VECTOR2 s1, VECTOR2 s2, VECTOR2 s3, VECTOR2 s4, VECTOR2 p);
	bool PointCheck(VECTOR2 p, VECTOR2 l1, VECTOR2 l2);

	void EnemyVecSet();

private:
	float CallCrossCheck(VECTOR2 a, VECTOR2 b, VECTOR2 p);

	Data data;
	FILE* file;

	VECTOR2 _startPos;
	bool pointCheck = false;
	int _rapCnt = 0;
	bool lrcheck = false;

	bool rFlag = false;
	VECTOR2 checkPos = { 0,0 };
	VECTOR2 aa = { 0,0 };
	VECTOR2 bb = { 0,0 };
	VECTOR2 cc = { 0,0 };
	VECTOR2 dd = { 0,0 };

};

