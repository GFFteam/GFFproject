#pragma once
#include <vector>
#include <memory>
#include"VECTOR2.h"

constexpr float EX_RATE = 4.0f;
constexpr int ROT_OFFSET = 230;

class Actor;
class Player;
class VECTOR2;
class UI;
class Circuit;

class MapControl
{
public:
	MapControl();
	virtual ~MapControl();
	void Init();
	void Update();
	void Draw();
	void Key();				// �N���X��ʂɍ�邩��
	void OtherControl();	// ���Ńv���C���[�̊֐������

	void Perspective();	// ���ߖ@

	const bool& GetClearCheck()
	{
		return _clearCheck;
	}

private:

	int sw, sh, dep;	// �X�N���[�����擾�p
	int base;			// ��ʒǉ��p
	int gw, gh;			// �O���t�B�b�N�T�C�Y
	int gw1, gh1;			// underMap�O���t�B�b�N�T�C�Y


	int gw2, gh2;

	int x = 0;
	int z = 0;
	float speed = 0.0f;
	float angle = 0.0f;
	float perspectiveX, perspectiveZ;

	std::vector<std::shared_ptr<Actor>>pl;
	std::vector<std::shared_ptr<UI>>ui;
	std::vector<std::shared_ptr<Circuit>>cir;
	std::vector<int>mapId;

	bool _clearCheck = false;

protected:
	float ax = 0;
	float az = 0;

	float theta = 0.0f;

	int _backY = 108;
	float _div = 35.0f;
	float shadowOffsetLR = 0;

	VECTOR2 _playerPos = { 0,0 };

	VECTOR2 _pPos = { 0,0 };

	bool _pushButtom = false;
	int pushCnt = 0;
	float push = 0.0f;

	VECTOR2 hitReactionMove = { 0.0f,0.0f };

};

