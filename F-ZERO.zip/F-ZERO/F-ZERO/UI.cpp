#include "UI.h"
#include "DxLib.h"
#include "ResourceMng.h"
#include "KeyMng.h"
#include "Share.h"

UI::UI()
{
	Init();
}

UI::~UI()
{
}

void UI::Init()
{
	DIV_IMAGE_ID("data/images/number.png", 10, 10, 1, 0, 0, 50, 50, num);
	DIV_IMAGE_ID("data/images/speedNumR.png", 5, 2, 3, 0, 0, 110, 50, speedNum);
}

void UI::Update()
{
	speed = Share::GetInstance().GetSpeed() * 100;
	circleSpeed = Share::GetInstance().GetSpeed() * SPEED_CIRCLE_SCALE;

	throttlePct = Share::GetInstance().GetThrottleParcent() * 50;
	brakePct = Share::GetInstance().GetBrakeParcent() * 50;

	fuel = Share::GetInstance().GetFuel();

	lrFlag = Share::GetInstance().GetLRFlag();

	sp1 = (int)speed % 10;
	sp10 = ((int)speed / 10) % 10;
	sp100 = (int)speed / 100;

	if (KeyMng::GetInstance().newKey[P1_UP])
	{
		gReturnCount -= 0.15;
		if (gReturnCount < -50.0f)
		{
			gReturnCount = -50.0f;
		}
	}
	else if (KeyMng::GetInstance().newKey[P1_DOWN] && speed != 0.0f)
	{
		gReturnCount += 0.8f;
		if (gReturnCount > 50.0f)
		{
			gReturnCount = 50.0f;
		}
	}
	else
	{
		gReturnCount = 0.0f;
	}

	gSensor.x = -(Share::GetInstance().GetYawPercent() * gOffset) + gRand.x;

	gRand.x = GetRand(abs(lrFlag) * 2);
	gRand.y = GetRand(sp100 + abs(lrFlag)) - (sp100 + abs(lrFlag));

	if (speed != 0.0f)
	{
		gBrake = brakePct;
	}
	else
	{
		gBrake = 0.0f;
	}

	gSensor.y = ((throttlePct - gBrake + gReturnCount) * gOffset) + gRand.y;
}

void UI::Draw()
{
	// �^�R���[�^�[�x�[�X
	DrawRotaGraph(LEFT_TACHO_CENTER_X, LEFT_TACHO_CENTER_Y, 1.0f, 0, IMAGE_ID("data/images/tachoCircleWsc1.2.png"), true);
	DrawRotaGraph(SCREEN_SIZE_X / 2 + 110, SCREEN_SIZE_Y - 55, 1.0f, 0, IMAGE_ID("data/images/tachoCircleW2.png"), true);
	DrawRotaGraph(SCREEN_SIZE_X / 2 - 70, SCREEN_SIZE_Y - 15, 0.5f, 0, IMAGE_ID("data/images/tachoUnitW.png"), true);

	// �X�s�[�h��
	DrawRotaGraph(LEFT_TACHO_CENTER_X + 35, LEFT_TACHO_CENTER_Y, 1, 0, num[sp1], true);
	DrawRotaGraph(LEFT_TACHO_CENTER_X, LEFT_TACHO_CENTER_Y, 1, 0, num[sp10], true);
	DrawRotaGraph(LEFT_TACHO_CENTER_X - 35, LEFT_TACHO_CENTER_Y, 1, 0, num[sp100], true);

	DrawRotaGraph(LEFT_TACHO_CENTER_X, LEFT_TACHO_CENTER_Y - 40, 0.25f, 0, IMAGE_ID("data/images/speed.png"), true);
	DrawCircleGauge(LEFT_TACHO_CENTER_X - 1, LEFT_TACHO_CENTER_Y + 1, 61.0f + circleSpeed, IMAGE_ID("data/images/greenCircle2.png"),61.0f);
	
	DrawRotaGraph(LEFT_TACHO_CENTER_X - 70, LEFT_TACHO_CENTER_Y, 0.2f, -90 * (PI / 180), speedNum[0], true);
	DrawRotaGraph(LEFT_TACHO_CENTER_X - 50, LEFT_TACHO_CENTER_Y - 45, 0.2f, -45 * (PI / 180), speedNum[1], true);
	DrawRotaGraph(LEFT_TACHO_CENTER_X, LEFT_TACHO_CENTER_Y - 70, 0.2f, 0, speedNum[2], true);
	DrawRotaGraph(LEFT_TACHO_CENTER_X + 50, LEFT_TACHO_CENTER_Y - 45, 0.2f, 45 * (PI / 180), speedNum[3], true);
	DrawRotaGraph(LEFT_TACHO_CENTER_X + 70, LEFT_TACHO_CENTER_Y, 0.2f, 90 * (PI / 180), speedNum[4], true);


	// �X���b�g���ƃu���[�L
	DrawRotaGraph(RIGHT_L_TACHO_CENTER_X - 50, RIGHT_L_TACHO_CENTER_Y, 0.20f, -90 * (PI / 180), IMAGE_ID("data/images/brake.png"), true);
	DrawRotaGraph(RIGHT_L_TACHO_CENTER_X + 50, RIGHT_L_TACHO_CENTER_Y, 0.3f, 90 * (PI / 180), IMAGE_ID("data/images/throttle.png"), true);

	DrawCircleGauge(RIGHT_L_TACHO_CENTER_X, RIGHT_L_TACHO_CENTER_Y - 1,100 + throttlePct, IMAGE_ID("data/images/gCircle2_L.png"),50.0f,1.0f, 0,50);
	DrawCircleGauge(RIGHT_L_TACHO_CENTER_X, RIGHT_L_TACHO_CENTER_Y, 50.0f + brakePct, IMAGE_ID("data/images/rCircle2_L.png"), 50.0f,1.0f);

	// ���̑�����
	DrawRotaGraph(RIGHT_L_TACHO_CENTER_X, RIGHT_L_TACHO_CENTER_Y, 0.15f, 0, IMAGE_ID("data/images/g.png"), true);
	DrawLine(RIGHT_L_TACHO_CENTER_X, RIGHT_L_TACHO_CENTER_Y - 40, RIGHT_L_TACHO_CENTER_X, RIGHT_L_TACHO_CENTER_Y + 40, 0xffffff, 2);
	DrawLine(RIGHT_L_TACHO_CENTER_X - 40, RIGHT_L_TACHO_CENTER_Y, RIGHT_L_TACHO_CENTER_X + 40, RIGHT_L_TACHO_CENTER_Y, 0xffffff, 2);

	DrawRotaGraph(RIGHT_S_TACHO_CENTER_X + 25, RIGHT_S_TACHO_CENTER_Y - 10, 0.07f, 0, IMAGE_ID("data/images/fuelLight.png"), true);
	DrawRotaGraph(RIGHT_S_TACHO_CENTER_X, RIGHT_S_TACHO_CENTER_Y - 35, 1.5f, 0, IMAGE_ID("data/images/fuelFull.png"), true);
	DrawRotaGraph(RIGHT_S_TACHO_CENTER_X + 35, RIGHT_S_TACHO_CENTER_Y + 15, 1.5f, 0, IMAGE_ID("data/images/fuelEmpty.png"), true);
	DrawRotaGraph(RIGHT_S_TACHO_CENTER_X, RIGHT_S_TACHO_CENTER_Y, 1.0f, (115 - (fuel * 1.15)) * (PI / 180), IMAGE_ID("data/images/fuelIndicator2.png"), true);

	DrawCircle(gPos.x + gSensor.x, gPos.y + gSensor.y, 4, 0xff0000, true);

	// ���b�v�n
	DrawRotaGraph(SCREEN_SIZE_X - 200, 25, 0.45f, 0, IMAGE_ID("data/images/position.png"), true);
	DrawRotaGraph(SCREEN_SIZE_X - 125, SCREEN_SIZE_Y / 4, 0.3f, 0, IMAGE_ID("data/images/lapTime.png"), true);
}
