#include "UI.h"
#include "DxLib.h"
#include "ResourceMng.h"
#include "KeyMng.h"
#include "Share.h"

UI::UI()
{
	Init();
}

UI::~UI()
{
}

void UI::Init()
{
	_rap.rap1_1 = _rap.rap1_10 = _rap.rap10_1 = _rap.rap10_10 = _rap.rap100_1 = _rap.rap100_10 = 0;
	DIV_IMAGE_ID("data/images/Number/number.png", 10, 10, 1, 0, 0, 50, 50, num);
	DIV_IMAGE_ID("data/images/speedNumR.png", 5, 2, 3, 0, 0, 110, 50, speedNum);
}

void UI::Update()
{
	if (lpGameTask.GetRaceStart()._startFlag)
	{
		RapTimeUpdate();
	}
	else
	{
		StartUIDraw();
	}

	speed = Share::GetInstance().GetSpeed() * 100;
	circleSpeed = Share::GetInstance().GetSpeed() * SPEED_CIRCLE_SCALE;

	throttlePct = Share::GetInstance().GetThrottleParcent() * 50;
	brakePct = Share::GetInstance().GetBrakeParcent() * 50;

	fuel = Share::GetInstance().GetFuel();

	lrFlag = Share::GetInstance().GetLRFlag();


	sp1 = (int)speed % 10;
	sp10 = ((int)speed / 10) % 10;
	sp100 = (int)speed / 100;

	if (KeyMng::GetInstance().newKey[P1_UP])
	{
		gReturnCount -= 0.15;
		if (gReturnCount < -50.0f)
		{
			gReturnCount = -50.0f;
		}
	}
	else if (KeyMng::GetInstance().newKey[P1_DOWN] && speed != 0.0f)
	{
		gReturnCount += 0.8f;
		if (gReturnCount > 50.0f)
		{
			gReturnCount = 50.0f;
		}
	}
	else
	{
		gReturnCount = 0.0f;
	}

	gSensor.x = -(Share::GetInstance().GetYawPercent() * gOffset) + gRand.x;

	gRand.x = GetRand(abs(lrFlag) * 2);
	gRand.y = GetRand(sp100 + abs(lrFlag)) - (sp100 + abs(lrFlag));

	if (speed != 0.0f)
	{
		gBrake = brakePct;
	}
	else
	{
		gBrake = 0.0f;
	}

	gSensor.y = ((throttlePct - gBrake + gReturnCount) * gOffset) + gRand.y;
}

void UI::RapTimeUpdate()
{
	_rap.rap1 += (100.0f / 60.0f);

	_rap.rap1_1 = _rap.rap1;


	if (_rap.rap1_1 >= 10)
	{
		_rap.rap1 = 0.0f;
		_rap.rap1_1 = 0;
		_rap.rap1_10++;
		if (_rap.rap1_10 >= 10)
		{
			_rap.rap1_10 = 0;
			_rap.rap10_1++;

			if (_rap.rap10_1 >= 10)
			{
				_rap.rap10_1 = 0;
				_rap.rap10_10++;

				if (_rap.rap10_10 >= 6)
				{
					_rap.rap10_10 = 0;
					_rap.rap100_1++;
					if (_rap.rap100_1 >= 10)
					{
						_rap.rap100_1 = 0;
						_rap.rap100_10++;

						if (_rap.rap100_10 >= 10)
						{
							_rap.rap100_10 = 0;
						}
					}
				}

			}
		}
	}
}

void UI::Draw()
{
	// �^�R���[�^�[�x�[�X
	DrawRotaGraph(LEFT_TACHO_CENTER_X, LEFT_TACHO_CENTER_Y, 1.0f, 0, IMAGE_ID("data/images/tachoCircleWsc1.2.png"), true);
	DrawRotaGraph(SCREEN_SIZE_X / 2 + 110, SCREEN_SIZE_Y - 55, 1.0f, 0, IMAGE_ID("data/images/tachoCircleW2.png"), true);
	DrawRotaGraph(SCREEN_SIZE_X / 2 - 70, SCREEN_SIZE_Y - 15, 0.5f, 0, IMAGE_ID("data/images/tachoUnitW.png"), true);

	// �X�s�[�h��
	// �G���W���X�s�[�h
	DrawRotaGraph(LEFT_TACHO_CENTER_X + 35, LEFT_TACHO_CENTER_Y, 1, 0, num[sp1], true);
	DrawRotaGraph(LEFT_TACHO_CENTER_X, LEFT_TACHO_CENTER_Y, 1, 0, num[sp10], true);
	DrawRotaGraph(LEFT_TACHO_CENTER_X - 35, LEFT_TACHO_CENTER_Y, 1, 0, num[sp100], true);

	DrawRotaGraph(LEFT_TACHO_CENTER_X, LEFT_TACHO_CENTER_Y - 40, 0.25f, 0, IMAGE_ID("data/images/speed.png"), true);
	DrawCircleGauge(LEFT_TACHO_CENTER_X - 1, LEFT_TACHO_CENTER_Y + 1, 61.0f + circleSpeed, IMAGE_ID("data/images/greenCircle2.png"),61.0f);
	
	DrawRotaGraph(LEFT_TACHO_CENTER_X - 70, LEFT_TACHO_CENTER_Y, 0.2f, -90 * (PI / 180), speedNum[0], true);
	DrawRotaGraph(LEFT_TACHO_CENTER_X - 50, LEFT_TACHO_CENTER_Y - 45, 0.2f, -45 * (PI / 180), speedNum[1], true);
	DrawRotaGraph(LEFT_TACHO_CENTER_X, LEFT_TACHO_CENTER_Y - 70, 0.2f, 0, speedNum[2], true);
	DrawRotaGraph(LEFT_TACHO_CENTER_X + 50, LEFT_TACHO_CENTER_Y - 45, 0.2f, 45 * (PI / 180), speedNum[3], true);
	DrawRotaGraph(LEFT_TACHO_CENTER_X + 70, LEFT_TACHO_CENTER_Y, 0.2f, 90 * (PI / 180), speedNum[4], true);


	// �X���b�g���ƃu���[�L
	DrawRotaGraph(RIGHT_L_TACHO_CENTER_X - 50, RIGHT_L_TACHO_CENTER_Y, 0.20f, -90 * (PI / 180), IMAGE_ID("data/images/brake.png"), true);
	DrawRotaGraph(RIGHT_L_TACHO_CENTER_X + 50, RIGHT_L_TACHO_CENTER_Y, 0.3f, 90 * (PI / 180), IMAGE_ID("data/images/throttle.png"), true);

	DrawCircleGauge(RIGHT_L_TACHO_CENTER_X, RIGHT_L_TACHO_CENTER_Y - 1,100 + throttlePct, IMAGE_ID("data/images/gCircle2_L.png"),50.0f,1.0f, 0,50);
	DrawCircleGauge(RIGHT_L_TACHO_CENTER_X, RIGHT_L_TACHO_CENTER_Y, 50.0f + brakePct, IMAGE_ID("data/images/rCircle2_L.png"), 50.0f,1.0f);

	// ���̑�����
	DrawRotaGraph(RIGHT_L_TACHO_CENTER_X, RIGHT_L_TACHO_CENTER_Y, 0.15f, 0, IMAGE_ID("data/images/g.png"), true);
	DrawLine(RIGHT_L_TACHO_CENTER_X, RIGHT_L_TACHO_CENTER_Y - 40, RIGHT_L_TACHO_CENTER_X, RIGHT_L_TACHO_CENTER_Y + 40, 0xffffff, 2);
	DrawLine(RIGHT_L_TACHO_CENTER_X - 40, RIGHT_L_TACHO_CENTER_Y, RIGHT_L_TACHO_CENTER_X + 40, RIGHT_L_TACHO_CENTER_Y, 0xffffff, 2);

	DrawRotaGraph(RIGHT_S_TACHO_CENTER_X + 25, RIGHT_S_TACHO_CENTER_Y - 10, 0.07f, 0, IMAGE_ID("data/images/fuelLight.png"), true);
	DrawRotaGraph(RIGHT_S_TACHO_CENTER_X, RIGHT_S_TACHO_CENTER_Y - 35, 1.5f, 0, IMAGE_ID("data/images/fuelFull.png"), true);
	DrawRotaGraph(RIGHT_S_TACHO_CENTER_X + 35, RIGHT_S_TACHO_CENTER_Y + 15, 1.5f, 0, IMAGE_ID("data/images/fuelEmpty.png"), true);
	DrawRotaGraph(RIGHT_S_TACHO_CENTER_X, RIGHT_S_TACHO_CENTER_Y, 1.0f, (115 - (fuel * 1.15)) * (PI / 180), IMAGE_ID("data/images/fuelIndicator2.png"), true);

	DrawCircle(gPos.x + gSensor.x, gPos.y + gSensor.y, 4, 0xff0000, true);

	// ���b�v�n
	DrawRotaGraph(SCREEN_SIZE_X - 200, 25, 0.45f, 0, IMAGE_ID("data/images/position.png"), true);
	DrawRotaGraph(SCREEN_SIZE_X - 125, SCREEN_SIZE_Y / 4, 0.3f, 0, IMAGE_ID("data/images/lapTime.png"), true);

	RapTimeDraw();
}

void UI::RapTimeDraw()
{
	_setValueFlag = false;
	//�_�P��
	DrawRotaGraph(SCREEN_SIZE_X - 125 + _numberSize * 4, 160, 0.5, 0, num[_rap.rap1_1], true);
	DrawRotaGraph(SCREEN_SIZE_X - 125 + _numberSize * 3, 160, 0.5, 0, num[_rap.rap1_10], true);

	//�b
	DrawRotaGraph(SCREEN_SIZE_X - 125 + _numberSize * 2 - 10, 160, 0.5, 0, num[_rap.rap10_1], true);
	DrawRotaGraph(SCREEN_SIZE_X - 125 + _numberSize * 1 - 10, 160, 0.5, 0, num[_rap.rap10_10], true);

	//��
	DrawRotaGraph(SCREEN_SIZE_X - 125 - 20, 160, 0.5, 0, num[_rap.rap100_1], true);
	DrawRotaGraph(SCREEN_SIZE_X - 125 - _numberSize - 20, 160, 0.5, 0, num[_rap.rap100_10], true);

	//:
	DrawRotaGraph(SCREEN_SIZE_X - 125 + _numberSize * 3 - 17, 160, 0.5, 0, IMAGE_ID("data/images/Number/numberT.png"), true);
	DrawRotaGraph(SCREEN_SIZE_X - 125 + _numberSize * 1 - 10 - 17, 160, 0.5, 0, IMAGE_ID("data/images/Number/numberT.png"), true);

	
	//raptime�o�͕`��
	OutPutDraw();

	if (lpGameTask.GetRaceMode() == RACE_MODE::TIME_ATTACK)
	{
		//�n�C�X�R�A�`��
		HighScoreDraw();
	}

	if (_rap._setRapCnt != 0 && (_rap._setRapCnt < Share::GetInstance().GetRapCnt()))
	{
		SetRapValue();
	}

	_rap._setRapCnt = Share::GetInstance().GetRapCnt();

}


void UI::OutPutDraw()
{

	//�o��
	//�_�P��
	DrawRotaGraph(SCREEN_SIZE_X - 125 + _numberSize * 4, 200, 0.4, 0, num[(int)_output.setCntm1], true);
	DrawRotaGraph(SCREEN_SIZE_X - 125 + _numberSize * 3 + 5, 200, 0.4, 0, num[(int)_output.setCntm10], true);


	//�b
	DrawRotaGraph(SCREEN_SIZE_X - 125 + _numberSize * 2 - 5, 200, 0.4, 0, num[(int)_output.setCnts1], true);
	DrawRotaGraph(SCREEN_SIZE_X - 125 + _numberSize * 1, 200, 0.4, 0, num[(int)_output.setCnts10], true);

	//��
	DrawRotaGraph(SCREEN_SIZE_X - 125 - 10, 200, 0.4, 0, num[(int)_output.setCntM1], true);
	DrawRotaGraph(SCREEN_SIZE_X - 125 - _numberSize - 5, 200, 0.4, 0, num[(int)_output.setCntM10], true);

	//:
	DrawRotaGraph(SCREEN_SIZE_X - 125 + _numberSize * 3 + 5 - 18, 200, 0.4, 0, IMAGE_ID("data/images/Number/numberT.png"), true);
	DrawRotaGraph(SCREEN_SIZE_X - 125 + _numberSize * 1 - 18, 200, 0.4, 0, IMAGE_ID("data/images/Number/numberT.png"), true);
}

void UI::HighScoreDraw()
{
	//�n�C�X�R�A
	//�_�P��
	DrawRotaGraph(SCREEN_SIZE_X - 125 + _numberSize * 4, 280, 0.5, 0, num[(int)_getData.setCntm1], true);
	DrawRotaGraph(SCREEN_SIZE_X - 125 + _numberSize * 3, 280, 0.5, 0, num[(int)_getData.setCntm10], true);

	//�b
	DrawRotaGraph(SCREEN_SIZE_X - 125 + _numberSize * 2 - 10, 280, 0.5, 0, num[(int)_getData.setCnts1], true);
	DrawRotaGraph(SCREEN_SIZE_X - 125 + _numberSize * 1 - 10, 280, 0.5, 0, num[(int)_getData.setCnts10], true);

	//��
	DrawRotaGraph(SCREEN_SIZE_X - 125 - 20, 280, 0.5, 0, num[(int)_getData.setCntM1], true);
	DrawRotaGraph(SCREEN_SIZE_X - 125 - _numberSize - 20, 280, 0.5, 0, num[(int)_getData.setCntM10], true);

	//:
	DrawRotaGraph(SCREEN_SIZE_X - 125 + _numberSize * 3 - 17, 280, 0.5, 0, IMAGE_ID("data/images/Number/numberT.png"), true);
	DrawRotaGraph(SCREEN_SIZE_X - 125 + _numberSize * 1 - 10 - 17, 280, 0.5, 0, IMAGE_ID("data/images/Number/numberT.png"), true);
}

void UI::SetRapValue()
{

	//�ۑ�
	//�~��
	_output.setCntm1 = _rap.rap1_1;
	_output.setCntm10 = _rap.rap1_10;
	//�b
	_output.setCnts1 = _rap.rap10_1;
	_output.setCnts10 = _rap.rap10_10;
	//��
	_output.setCntM1 = _rap.rap100_1;// *100;
	_output.setCntM10 = _rap.rap100_10;// *1000;

									   //�o�͗p�Ɍv�Z
	float setCntm1 = _output.setCntm1 * 0.01f;
	float setCntm10 = _output.setCntm10 * 0.1f;
	float setCnts1 = _output.setCnts1;
	float setCnts10 = _output.setCnts10 * 10;
	float setCntM1 = _output.setCntM1 * 100;
	float setCntM10 = _output.setCntM10 * 1000;


	//���v
	_output._rapTimeValue = setCntm1 + setCntm10 + setCnts1 + setCnts10 + setCntM1 + setCntM10;
	_output._rapValue.emplace_back(_output._rapTimeValue);
	_setValueFlag = true;
}

void UI::StartUIDraw()
{
	auto cnt = lpGameTask.GetRaceStart()._startCnt;
	auto efectCnt = lpGameTask.GetRaceStart()._efectCnt;
	SetDrawBlendMode(DX_BLENDMODE_ALPHA, efectCnt);
	DrawRotaGraph(SCREEN_SIZE_X / 2, SCREEN_SIZE_Y / 2 - SCREEN_SIZE_Y / 4, 1, 0, num[cnt], true);
	SetDrawBlendMode(DX_BLENDMODE_NOBLEND, 0);
}

void UI::ResultUIDraw()
{
	//�o��
	//�_�P��
	DrawRotaGraph(SCREEN_SIZE_X / 2 + _numberSize * 5 + 20, 220, 1.0f, 0, num[(int)_output.setCntm1], true);
	DrawRotaGraph(SCREEN_SIZE_X / 2 + _numberSize * 3 + 25, 220, 1.0f, 0, num[(int)_output.setCntm10], true);


	//�b
	DrawRotaGraph(SCREEN_SIZE_X / 2 + _numberSize, 220, 1.0f, 0, num[(int)_output.setCnts1], true);
	DrawRotaGraph(SCREEN_SIZE_X / 2 + _numberSize - 50, 220, 1.0f, 0, num[(int)_output.setCnts10], true);

	//��
	DrawRotaGraph(SCREEN_SIZE_X / 2 + _numberSize - 120, 220, 1.0f, 0, num[(int)_output.setCntM1], true);
	DrawRotaGraph(SCREEN_SIZE_X / 2 + _numberSize - 170, 220, 1.0f, 0, num[(int)_output.setCntM10], true);

	//:
	DrawRotaGraph(SCREEN_SIZE_X / 2 + _numberSize + 35, 220, 1.0f, 0, IMAGE_ID("data/images/Number/numberT.png"), true);
	DrawRotaGraph(SCREEN_SIZE_X / 2 + _numberSize - 86, 220, 1.0f, 0, IMAGE_ID("data/images/Number/numberT.png"), true);
}
