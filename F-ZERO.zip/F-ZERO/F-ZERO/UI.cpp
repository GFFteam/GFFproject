#include "UI.h"
#include "DxLib.h"
#include "ResourceMng.h"
#include "Share.h"

UI::UI()
{
	Init();
}

UI::~UI()
{
}

void UI::Init()
{
	DIV_IMAGE_ID("data/images/number.png", 10, 10, 1, 0, 0, 50, 50, num);
	DIV_IMAGE_ID("data/images/speedNumR.png", 5, 2, 3, 0, 0, 110, 50, speedNum);
}

void UI::Update()
{
	speed = Share::GetInstance().GetSpeed() * 100;

	sp1 = (int)speed % 10;
	sp10 = ((int)speed / 10) % 10;
	sp100 = (int)speed / 100;

	circleSpeed = Share::GetInstance().GetSpeed() * SPEED_CIRCLE_SCALE;
}

void UI::Draw()
{
	// �^�R���[�^�[�x�[�X
	DrawRotaGraph(LEFT_TACHO_CENTER_X, LEFT_TACHO_CENTER_Y, 1.0f, 0, IMAGE_ID("data/images/tachoCircleWsc1.2.png"), true);
	DrawRotaGraph(SCREEN_SIZE_X / 2 + 110, SCREEN_SIZE_Y - 55, 1.0f, 0, IMAGE_ID("data/images/tachoCircleW2.png"), true);
	DrawRotaGraph(SCREEN_SIZE_X / 2 - 70, SCREEN_SIZE_Y - 15, 0.5f, 0, IMAGE_ID("data/images/tachoUnitW.png"), true);

	// �X�s�[�h��
	DrawRotaGraph(LEFT_TACHO_CENTER_X + 35, LEFT_TACHO_CENTER_Y, 1, 0, num[sp1], true);
	DrawRotaGraph(LEFT_TACHO_CENTER_X, LEFT_TACHO_CENTER_Y, 1, 0, num[sp10], true);
	DrawRotaGraph(LEFT_TACHO_CENTER_X - 35, LEFT_TACHO_CENTER_Y, 1, 0, num[sp100], true);

	DrawRotaGraph(LEFT_TACHO_CENTER_X, LEFT_TACHO_CENTER_Y - 40, 0.25f, 0, IMAGE_ID("data/images/speedLight.png"), true);
	DrawCircleGauge(LEFT_TACHO_CENTER_X, LEFT_TACHO_CENTER_Y, 61.0f + circleSpeed, IMAGE_ID("data/images/greenCircle2.png"),61.0f);

	DrawRotaGraph(LEFT_TACHO_CENTER_X - 70, LEFT_TACHO_CENTER_Y, 0.2f, -90 * (PI / 180), speedNum[0], true);
	DrawRotaGraph(LEFT_TACHO_CENTER_X - 50, LEFT_TACHO_CENTER_Y - 45, 0.2f, -45 * (PI / 180), speedNum[1], true);
	DrawRotaGraph(LEFT_TACHO_CENTER_X, LEFT_TACHO_CENTER_Y - 70, 0.2f, 0, speedNum[2], true);
	DrawRotaGraph(LEFT_TACHO_CENTER_X + 50, LEFT_TACHO_CENTER_Y - 45, 0.2f, 45 * (PI / 180), speedNum[3], true);
	DrawRotaGraph(LEFT_TACHO_CENTER_X + 70, LEFT_TACHO_CENTER_Y, 0.2f, 90 * (PI / 180), speedNum[4], true);


	// �X���b�g���ƃu���[�L
	DrawRotaGraph((SCREEN_SIZE_X / 2 + 82) - 45, SCREEN_SIZE_Y - 70, 0.15f, -90 * (PI / 180), IMAGE_ID("data/images/brake.png"), true);
	DrawRotaGraph((SCREEN_SIZE_X / 2 + 82) + 45, SCREEN_SIZE_Y - 70, 0.22f, 90 * (PI / 180), IMAGE_ID("data/images/throttle.png"), true);

	// ���̑�����
	DrawRotaGraph(SCREEN_SIZE_X / 2 + 82, SCREEN_SIZE_Y - 70, 0.15f, 0, IMAGE_ID("data/images/g.png"), true);
	DrawLine(SCREEN_SIZE_X / 2 + 82, (SCREEN_SIZE_Y - 70) - 35, SCREEN_SIZE_X / 2 + 82, (SCREEN_SIZE_Y - 70) + 35, 0xffffff, 2);
	DrawLine((SCREEN_SIZE_X / 2 + 82) - 35, SCREEN_SIZE_Y - 70, (SCREEN_SIZE_X / 2 + 82) + 35, SCREEN_SIZE_Y - 70, 0xffffff, 2);

	DrawRotaGraph(SCREEN_SIZE_X / 2 + 160, SCREEN_SIZE_Y - 20, 0.08f, 0, IMAGE_ID("data/images/fuel.png"), true);
	
}
