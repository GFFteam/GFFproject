#include "DxLib.h"
#include "GameTask.h"
#include "ImageMng.h"
#include <iostream>
#include <memory>
#include <algorithm>

GameTask *GameTask::s_Instance = nullptr;

void GameTask::Create(void)
{
	if (!s_Instance)
	{
		s_Instance = new GameTask();
	}
}

int GameTask::SystemInit()
{
	SetWindowText("Template");
	SetGraphMode(SCREEN_SIZE_X, SCREEN_SIZE_Y, 16);
	ChangeWindowMode(true);
	if (DxLib_Init() == -1) {
		return -1;
	}
	SetDrawScreen(DX_SCREEN_BACK);
}

void GameTask::GameUpdate()
{
	// ���݂̃��[�h�ŉ�
	(this->*gMode[currentMode])();
}

void GameTask::GameInit()
{
	DrawString(10, 10, "INIT", 0xffffff);

	//--------------------------------------------------
	// ������
	//--------------------------------------------------
	currentMode = G_INIT;

	currentMode = G_MAIN;

	for (int x = 0; x < 20; x++)
	{
		for (int y = 0; y < 20; y++)
		{
			cir.push_back(make_shared<ControlCircle>());
		}
	}
}

void GameTask::GameMain()
{
	DrawString(10, 10, "MAIN", 0xffffff);

	for (itr = cir.begin(); itr != cir.end(); itr++)
	{
		(*itr)->Key();
		(*itr)->Calc();
	}

	// �������߂����̂���`��
	//std::sort(cir.begin(), cir.end());
	
	for (itr = cir.begin(); itr != cir.end(); itr++)
	{
		if (*itr == cir.front() || *itr == cir.back() || *itr == cir.operator[](19) || *itr == cir.operator[](399 - 19))
		{
			(*itr)->FirstEndDraw();
		}
		else
		{
			(*itr)->Draw();
		}
	}
}