#pragma once
#include "VECTOR3.h"
#include "VECTOR2.h"
#include <memory>

using namespace std;

class ControlCircle;

typedef shared_ptr<ControlCircle> clPtr;

class ControlCircle
{
public:
	ControlCircle();
	~ControlCircle();
	void Draw();
	void FirstEndDraw();
	void Calc();
	void Key();

	static int CntX;
	static int CntZ;

	// �`�揇�\�[�g�p
	friend bool operator<(const clPtr& c1, const clPtr& c2)
	{
		return c2->cm.distance < c1->cm.distance;
	}

private:
	struct circle
	{
		VECTOR3 pos;
		float size;
		VECTOR3 rotate;
		float theta;
		float rotateAngle;
		float fVecSpeed;
	};

	struct cam
	{
		VECTOR3 pos;
		float distance;
	};

	circle c;
	cam cm;

	float sx, sy, sz;
	float x, y, z;
	float screenDist;		// fov
};
