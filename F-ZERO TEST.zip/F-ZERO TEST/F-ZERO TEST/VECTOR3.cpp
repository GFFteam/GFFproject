#include "VECTOR3.h"

VECTOR3 operator*(const VECTOR3 & v3, const float & f)
{
	VECTOR3 tmp;
	tmp.x = v3.x * f;
	tmp.y = v3.y * f;
	tmp.z = v3.z * f;
	return tmp;
}

VECTOR3 operator/(const VECTOR3& v3, const float& f)
{
	VECTOR3 tmp;
	tmp.x = v3.x / f;
	tmp.y = v3.y / f;
	tmp.z = v3.z / f;
	return tmp;
}

VECTOR3 VECTOR3::operator*=(const float f)
{
	x *= f;
	y *= f;
	return *this;
}
