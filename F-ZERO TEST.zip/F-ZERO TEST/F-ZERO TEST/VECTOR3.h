#pragma once
class VECTOR3
{
public:
	VECTOR3() {};
	~VECTOR3() {};
	float x, y, z;

	VECTOR3 operator*=(const float);

};
VECTOR3 operator*(const VECTOR3&, const float&);
VECTOR3 operator/(const VECTOR3&, const float&);

