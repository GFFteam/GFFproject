#define _USE_MATH_DEFINES
#include "DxLib.h"
#include "ControlCircle.h"
#include "GameTask.h"
#include "ImageMng.h"
#include <cmath>
#include "VECTOR3.h"

int ControlCircle::CntX = 0;
int ControlCircle::CntZ = 20;

ControlCircle::ControlCircle()
{
	screenDist = 200;
	c.pos.x = 0;
	c.pos.y = SCREEN_CENTER_Y;
	c.pos.z = 0;
	c.rotate.x = 0;
	c.rotate.y = 0;
	c.rotate.z = 0;
	c.rotate.x = 0;
	c.rotate.y = 0;
	c.rotate.z = 0;
	c.rotateAngle = 0;
	c.fVecSpeed = 3.0f;

	cm.distance = 0.0f;
	cm.pos.x = 0.0f;
	cm.pos.y = 0.0f;
	cm.pos.z = 0.0f;

	// ���R��20����
	// �^�e��20����
	if (CntX % 20 == 0 && CntX != 0)
	{
		CntX = 0;
		CntZ--;
	}
	c.pos.x = CntX * 40.0f;		// x���W40�Ԋu�Ŕz�u
	c.pos.z = CntZ * 40.0f;		// z���W��40�Ԋu�Ŕz�u

	CntX++;
}

ControlCircle::~ControlCircle()
{
}

void ControlCircle::Draw()
{
	if (z > cm.pos.z)
	{
		DrawRotaGraphF(x, y, c.size, 0, IMAGE_ID("image/circleTest.png"), true);
	}
	DrawFormatString(10, 50, 0xffffff, "theta:%.1f\nrotateAngle:%.1f��", c.theta,c.rotateAngle);
	DrawFormatString(10, 90, 0xffffff, "sin(%.3f):%.3f\ncos(%.3f):%.3f", c.theta, sin(c.theta), c.theta, cos(c.theta));
}

void ControlCircle::FirstEndDraw()
{
	if (z > cm.pos.z)
	{
		DrawRotaGraphF(x, y, c.size, 0, IMAGE_ID("image/circleTestB.png"), true);
	}
}

void ControlCircle::Calc()
{
	// ���W�A���ϊ�
	c.theta = c.rotateAngle * (M_PI / 180.0f);

	// cm.pos(�J�������W)�����_�ɂ���y����](�A�t�B���ϊ�:https://algorithm.joho.info/image-processing/affine-transformation-rotation/#toc3)
	c.rotate.x = ((c.pos.x - cm.pos.x) * cos(c.theta)) - ((c.pos.z - cm.pos.z) * sin(c.theta));
	c.rotate.y = c.pos.y;
	c.rotate.z = ((c.pos.x - cm.pos.x) * sin(c.theta)) + ((c.pos.z - cm.pos.z) * cos(c.theta));

	// x,y,z�����߂�(http://blawat2015.no-ip.com/~mieki256/diary/201612221.html)
	sz =  screenDist / c.rotate.z;
	sx = c.rotate.x * sz;
	sy = c.rotate.y * sz;
	c.size = 2 * sz;
	x = sx + c.size / 2 + SCREEN_CENTER_X;
	y = sy + c.size / 2 + SCREEN_CENTER_Y;
	z = sz + c.size / 2;
}

void ControlCircle::Key()
{
	if (CheckHitKey(KEY_INPUT_UP))
	{
		c.pos.x -= c.fVecSpeed * sin(c.theta);
		c.pos.z -= c.fVecSpeed * cos(c.theta);
	}
	if (CheckHitKey(KEY_INPUT_DOWN))
	{
		c.pos.x += c.fVecSpeed * sin(c.theta);
		c.pos.z += c.fVecSpeed * cos(c.theta);
	}
	if (CheckHitKey(KEY_INPUT_LEFT))
	{
		c.rotateAngle -= 1.5f;
	}
	if (CheckHitKey(KEY_INPUT_RIGHT))
	{
		c.rotateAngle += 1.5f;
	}
}

