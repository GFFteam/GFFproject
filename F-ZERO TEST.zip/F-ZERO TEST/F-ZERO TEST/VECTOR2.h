#pragma once
class VECTOR2
{
public:
	VECTOR2();
	~VECTOR2();
	float x, z;
private:

};
VECTOR2 operator-(const VECTOR2&, const VECTOR2&);
