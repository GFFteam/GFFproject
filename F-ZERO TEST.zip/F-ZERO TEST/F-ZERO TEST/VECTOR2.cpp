#include "VECTOR2.h"

VECTOR2::VECTOR2()
{
}


VECTOR2::~VECTOR2()
{
}

VECTOR2 operator-(const VECTOR2 &a, const VECTOR2 &b)
{
	VECTOR2 tmp;
	tmp.x = a.x - b.x;
	tmp.z = a.z - b.z;
	return tmp;
}
